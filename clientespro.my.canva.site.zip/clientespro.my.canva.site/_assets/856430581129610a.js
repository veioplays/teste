(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [85862], {

        /***/
        914242: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                __c.E_ = function(a, b, c) {
                    return {
                        key: a,
                        JVa: b,
                        type: "string",
                        fL: c,
                        MSa: 0
                    }
                };
                __c.F_ = class {
                    get id() {
                        return this.config.id
                    }
                    map(a) {
                        return a(this.config)
                    }
                    constructor(a) {
                        this.config = { ...a
                        }
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/856430581129610a.js.map