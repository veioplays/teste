(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [26489], {

        /***/
        59534: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var vDb = function(a) {
                        var b = ["rgb(255, 255, 255)", "rgb(13, 18, 22)"];
                        try {
                            const c = __c.kt(a),
                                d = c instanceof __c.lt ? c.ws() : c;
                            return __c.as(b, e => {
                                e = __c.kt(e);
                                e = e instanceof __c.lt ? __c.OH(e, d) : e;
                                return Math.abs(__c.zt(e, d))
                            })
                        } catch (c) {
                            if (c instanceof Error && c.message === `unrecognized color: ${b[0]}`) return b[0];
                            throw c;
                        }
                    },
                    wDb = function(a) {
                        return a.trim().split(/\s+/, 2).map(b => __c.Bs(b)[0]).join("")
                    },
                    zDb = function(a = "") {
                        a = xDb(a);
                        a = Math.floor(a() * yDb.length);
                        return yDb[a]
                    },
                    ADb = __webpack_require__(875604),
                    BDb =
                    ADb.memo,
                    CDb = ADb.useId;
                var xDb = __webpack_require__(503216);
                var DDb = __webpack_require__(443763),
                    FY = DDb.jsx,
                    EDb = DDb.jsxs;
                var FDb = __webpack_require__,
                    GDb = FDb(993864),
                    GY = FDb.n_x(GDb)();
                __c.HDb = {
                    xxsmall: 2,
                    xsmall: 3,
                    small: 4,
                    medium: 5,
                    large: 6,
                    xlarge: 8,
                    xxlarge: 10,
                    xxxlarge: 20
                };
                var yDb = ["rgb(0, 126, 182)", "rgb(248, 72, 86)", "rgb(251, 190, 40)", "rgb(68, 133, 25)", "rgb(125, 42, 232)"].map(a => {
                    try {
                        return __c.mt(__c.ft(a))
                    } catch (b) {
                        return "#8e8e8e"
                    }
                });
                var IDb = BDb(a => {
                    const {
                        name: b,
                        borderColor: c,
                        backgroundColor: d,
                        IS: e,
                        role: f,
                        ariaLabel: g,
                        className: h,
                        style: k,
                        shape: l = "circle",
                        ...m
                    } = a;
                    if (d) {
                        a = __c.kt(d);
                        var n = a instanceof __c.lt ? __c.nt(a) : __c.mt(a)
                    } else n = e ? zDb(e) : "#8e8e8e";
                    var p = CDb();
                    switch (l) {
                        case "circle":
                            a = FY("defs", {
                                children: FY("clipPath", {
                                    id: p,
                                    children: FY("circle", {
                                        id: `${p}-path`,
                                        cx: "50%",
                                        cy: "50%",
                                        r: "50%"
                                    })
                                })
                            });
                            break;
                        case "square":
                            a = FY("defs", {
                                children: FY("clipPath", {
                                    id: p,
                                    children: FY("rect", {
                                        id: `${p}-path`,
                                        width: "100%",
                                        height: "100%"
                                    })
                                })
                            });
                            break;
                        default:
                            throw new __c.E(l);
                    }
                    switch (l) {
                        case "circle":
                            p = FY("circle", {
                                cx: "50%",
                                cy: "50%",
                                fill: n,
                                shapeRendering: "geometricPrecision",
                                clipPath: `url(#${p})`,
                                stroke: c,
                                className: GY("yCT70Q", {
                                    _2LVP_g: c
                                })
                            });
                            break;
                        case "square":
                            p = FY("rect", {
                                width: "100%",
                                height: "100%",
                                fill: n,
                                shapeRendering: "geometricPrecision",
                                clipPath: `url(#${p})`,
                                stroke: c,
                                className: GY("cUFFRA", {
                                    _2LVP_g: c
                                })
                            });
                            break;
                        default:
                            throw new __c.E(l);
                    }
                    n = vDb(n);
                    return FY("span", {
                        role: f,
                        "aria-label": g,
                        className: GY("VaW8_A", {
                            cUFFRA: l === "square"
                        }),
                        style: {
                            "--pDK9Gw": n
                        },
                        ...m,
                        children: EDb("svg", {
                            className: h,
                            style: k,
                            children: [a, p, FY("text", {
                                x: "50%",
                                y: "50%",
                                "aria-hidden": "true",
                                textAnchor: "middle",
                                fill: n,
                                fontWeight: "500",
                                fontSize: "50%",
                                dominantBaseline: "central",
                                letterSpacing: "0.01rem",
                                dy: "-0.04em",
                                children: wDb(b).toUpperCase()
                            })]
                        })
                    })
                });
                var JDb = __webpack_require__.p + "images/5c0e58707f218438bf0f73d47db2ce50.svg";
                var KDb = ({
                    borderColor: a,
                    uVa: b,
                    ariaLabel: c,
                    className: d,
                    style: e,
                    role: f,
                    ...g
                }) => FY("span", {
                    className: GY(d, {
                        JwH6AA: a,
                        QJpRHw: !a
                    }),
                    style: {
                        backgroundImage: `url(${b})`,
                        borderColor: a && `${a}`,
                        ...e
                    },
                    role: f,
                    "aria-label": f === "img" ? c : void 0,
                    ...g
                });
                __c.LDb = ({
                    name: a,
                    H6a: b,
                    ariaLabel: c,
                    IS: d,
                    backgroundColor: e,
                    borderColor: f,
                    Ur: g,
                    className: h,
                    style: k,
                    shape: l = "circle",
                    ...m
                }) => {
                    h = GY("n8XGZg", "f4qJng fs-hide", h, {
                        P3N3Pw: l === "square"
                    });
                    b = b || "presentation";
                    return g ? FY(KDb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        uVa: g,
                        ariaLabel: c,
                        role: b,
                        ...m
                    }) : a ? FY(IDb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        name: a,
                        shape: l,
                        IS: d,
                        backgroundColor: e,
                        role: b,
                        ariaLabel: c,
                        ...m
                    }) : FY(KDb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        uVa: JDb,
                        ariaLabel: c,
                        role: b,
                        ...m
                    })
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/248be4058f7dc307.js.map