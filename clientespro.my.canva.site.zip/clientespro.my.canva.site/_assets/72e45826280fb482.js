(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [70911], {

        /***/
        88780: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(878415);
            __web_req__(914242);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var Hf = __c.Hf;
                var E = __c.E;
                var v = __c.v;
                var IZb = function(a) {
                        return () => a
                    },
                    Y5 = function(a, b, c, d) {
                        return new JZb(a, b, c, d)
                    },
                    Z5 = function(a, b) {
                        return b(a)
                    },
                    KZb = function(a, b) {
                        return b(a)
                    },
                    $5 = function(a, b) {
                        return a === b || b.map(c => a.Isa(LZb(c)))
                    },
                    NZb = function(a, b) {
                        return a.Bua(b).map(c => new MZb(c, d => d.props[b]))
                    },
                    LZb = function(a) {
                        v(a instanceof a6);
                        return a
                    },
                    b6 = function(a, b) {
                        if (a === b) return !0;
                        switch (typeof a) {
                            case "string":
                            case "number":
                            case "boolean":
                            case "undefined":
                                return !1;
                            case "object":
                                if (typeof b !== "object" || a.kind !== b.kind) return !1;
                                switch (a.kind) {
                                    case "array":
                                        return b.kind ===
                                            "array" && OZb(a.items, b.items);
                                    case "set":
                                        var c;
                                        if (c = b.kind === "set") a = a.items, b = b.items, c = a === b ? !0 : a.size !== b.size ? !1 : OZb([...a], [...b]);
                                        return c;
                                    case "record":
                                        return b.kind === "record" && PZb(a.fields, b.fields);
                                    case "instance":
                                        return b.kind === "instance" && a.instance === b.instance;
                                    default:
                                        throw new E(a);
                                }
                            default:
                                throw new E(a);
                        }
                    },
                    OZb = function(a, b) {
                        if (a === b) return !0;
                        if (a.length !== b.length) return !1;
                        for (let c = 0; c < a.length; c++)
                            if (!b6(a[c], b[c])) return !1;
                        return !0
                    },
                    PZb = function(a, b) {
                        if (a === b) return !0;
                        const c =
                            Object.keys(a),
                            d = Object.keys(b),
                            e = new Set([...c, ...d]);
                        if (c.length !== e.size || d.length !== e.size) return !1;
                        for (const f of e)
                            if (!b6(a[f], b[f])) return !1;
                        return !0
                    },
                    c6 = function(a) {
                        return typeof a === "string" ? JSON.stringify(a) : String(a)
                    },
                    d6 = function(a, b, c) {
                        switch (c.kind) {
                            case 0:
                                return QZb(c.value);
                            case 1:
                                const e = d6(a, b, c.zw);
                                return RZb[c.name].map(q => e6(q, e));
                            case 2:
                                const f = d6(a, b, c.B6a),
                                    g = d6(a, b, c.C6a);
                                return SZb[c.name].map(q => TZb(q, f, g));
                            case 3:
                                const h = c.args.map(q => q.kind !== 12 ? new UZb(d6(a, b, q)) : new VZb(d6(a,
                                        b, q.DGb))),
                                    k = c.name;
                                switch (k) {
                                    case 0:
                                    case 1:
                                        var d = h.map(q => q.qqa(r => r.type, r => r.type.NO()));
                                        return Z5(d, q => {
                                            q = f6.union(...q);
                                            return WZb[k](q).map(r => XZb(r, h))
                                        });
                                    default:
                                        return YZb[k].map(q => XZb(q, h))
                                }
                            case 4:
                                return ZZb(d6(a, b, c.e$), (q, r) => $Zb(a, b, c.param, r, c.body).map(t => a_b[c.name](r, t.resultType).map(w => b_b(w, q, t))));
                            case 5:
                                const l = Hf(c.fields, q => d6(a, b, q));
                                d = Hf(l, q => q.type);
                                return KZb(d, q => c_b[0](q).map(r => d_b(r, l)));
                            case 6:
                                d = a.types.resolve(c.name);
                                if (!d) throw Error(`cannot instantiate unknown type: ${c.name}`);
                                const m = d6(a, b, {
                                    kind: 5,
                                    fields: c.args
                                });
                                return d.Tkb.map(q => e6(q, m, {
                                    Pr: !0
                                }));
                            case 7:
                                return d = d6(a, b, c.base), e_b(d, c.QKb);
                            case 8:
                                return f_b(b, c.name);
                            case 9:
                                return d = __c.Ad(c.defs, q => d6(a, b, q)), g_b(a, b, d, c.body);
                            case 10:
                                d = d6(a, b, c.test).as(f6.Ci);
                                const n = d6(a, b, c.kAb),
                                    p = d6(a, b, c.alternate);
                                return h_b(d, n, p);
                            case 11:
                                return d6(a, b, c.body).computed();
                            default:
                                throw new E(c);
                        }
                    },
                    $Zb = function(a, b, c, d, e) {
                        return d6(a, b.define(c, d), e).map(f => i_b.of(d, f.type, g => h => f.eval(g.define(c, h))))
                    },
                    QZb = function(a) {
                        switch (typeof a) {
                            case "string":
                                return g6(f6.string,
                                    a);
                            case "number":
                                return g6(f6.number, a);
                            case "boolean":
                                return g6(f6.Ci, a);
                            case "undefined":
                                return g6(f6.undefined, a);
                            default:
                                throw new E(a);
                        }
                    },
                    e_b = function(a, b) {
                        return a.map(c => NZb(c.type, b).map(({
                            type: d,
                            get: e
                        }) => e6(new h6(c.type, d, e), c)))
                    },
                    f_b = function(a, b) {
                        return a.resolve(b).map(c => i6.of(c, d => d.resolve(b)))
                    },
                    g_b = function(a, b, c, d) {
                        const e = __c.Ad(c, f => f.type);
                        return j_b(d6(a, new j6(new Map(e), b), d), f => {
                            const g = __c.Ad(c, h => h.eval(f));
                            return new j6(new Map(g), f)
                        })
                    },
                    h_b = function(a, b, c) {
                        return b.map(d =>
                            c.map(e => {
                                const f = f6.union(d.type, e.type);
                                return i6.of(f, g => {
                                    const h = a.eval(g),
                                        k = d.eval(g),
                                        l = e.eval(g);
                                    return () => h() ? k() : l()
                                })
                            }))
                    },
                    e6 = function({
                        Ula: a,
                        resultType: b,
                        apply: c
                    }, d, e) {
                        const f = d.as(a);
                        return new i6(b, g => {
                            const h = f.eval(g);
                            if (e === null || e === void 0 ? 0 : e.Pr) {
                                const k = k_b(c);
                                return () => k(h())
                            }
                            return () => c(h())
                        })
                    },
                    TZb = function({
                        Ula: a,
                        D6a: b,
                        resultType: c,
                        apply: d
                    }, e, f) {
                        const g = e.as(a),
                            h = f.as(b);
                        return new i6(c, k => {
                            const l = g.eval(k),
                                m = h.eval(k);
                            return () => d(l(), m())
                        })
                    },
                    XZb = function({
                        F6a: a,
                        resultType: b,
                        apply: c
                    }, d) {
                        let e;
                        const f = d.map(g => g.tma(h => h.as(a), h => h.as(e !== null && e !== void 0 ? e : e = f6.e$(a))));
                        return new i6(b, g => {
                            const h = l => l.eval(g),
                                k = f.map(l => l.tma(h, h));
                            return () => {
                                const l = [];
                                k.forEach(m => {
                                    m.qqa(n => l.push(n()), n => l.push(...n()))
                                });
                                return c(l)
                            }
                        })
                    },
                    b_b = function({
                        $6a: a,
                        resultType: b,
                        reduce: c
                    }, d, e) {
                        const f = l_b(e, a);
                        return i6.of(b, g => {
                            const h = d.eval(g),
                                k = f.eval(g),
                                l = k_b(m => {
                                    m = m.map(IZb);
                                    return [m, m.map(k)]
                                });
                            return () => {
                                const [m, n] = l(h());
                                return c(m, n)
                            }
                        })
                    },
                    d_b = function({
                            E6a: a,
                            resultType: b,
                            apply: c
                        },
                        d) {
                        const e = Object.keys(a).filter(g => !d.hasOwnProperty(g));
                        if (e.length) throw Error(`too few arguments (missing ${e})`);
                        const f = m_b(a, (g, h) => d[h].as(g));
                        return new i6(b, g => {
                            const h = n_b(f, k => k.eval(g));
                            return () => c(o_b(h, k => k()))
                        })
                    },
                    g6 = function(a, b) {
                        const c = IZb(b);
                        return new i6(a, () => c)
                    },
                    ZZb = function(a, b) {
                        return a.type.NO().map(c => b(a.as(f6.e$(c)), c))
                    },
                    j_b = function(a, b) {
                        return new i6(a.type, c => a.eval(b(c)))
                    },
                    l_b = function(a, b) {
                        if (!$5(a.resultType, b)) throw Error(`type ${a.resultType} is not assignable to expected type: ${b}`);
                        return a
                    },
                    k_b = function(a) {
                        let b;
                        return c => {
                            if (b && k6.Jh(b.u, c)) return b.v;
                            const d = a(c);
                            b = {
                                u: c,
                                v: d
                            };
                            return d
                        }
                    },
                    m_b = function(a, b) {
                        return Hf(a, b)
                    },
                    n_b = function(a, b) {
                        return Hf(a, b)
                    },
                    o_b = function(a, b) {
                        return Hf(a, b)
                    },
                    t_b = function(a) {
                        const b = a.types,
                            c = a.values;
                        class d {
                            optional() {
                                const H = this.via,
                                    K = this.oga,
                                    I = this.VDa,
                                    M = b.union(this.type, b.undefined);
                                return new d(M, O => O != null ? H(O) : void 0, (O, S, V) => V != null ? K(O, S, V) : void 0, (O, S, V, ba) => V != null ? I(O, S, V, ba) : ba.delete(S))
                            }
                            oD() {
                                return new d(this.type, this.via, this.oga,
                                    (H, K) => {
                                        throw H.error(K, "read-only field");
                                    })
                            }
                            q7(H) {
                                return H ? new d(this.type, this.via, (K, I, M) => {
                                    M = this.oga(K, I, M);
                                    M != null && H(K, I, M);
                                    return M
                                }, (K, I, M, O) => {
                                    M != null && H(K, I, M);
                                    this.VDa(K, I, M, O)
                                }) : this
                            }
                            wtb(H, K) {
                                const I = this.via,
                                    M = this.oga,
                                    O = this.VDa;
                                return p_b(this.type, S => {
                                    const V = () => M(H, K, S.ph.get(K));
                                    return {
                                        Teb: () => I(V()),
                                        aNa: V,
                                        crb: ba => O(H, K, ba, S.ph)
                                    }
                                })
                            }
                            constructor(H, K, I, M) {
                                this.type = H;
                                this.via = K;
                                this.oga = I;
                                this.VDa = M
                            }
                        }
                        a = new d(b.string, H => H, l6("string", H => H.value), m6("string"));
                        const e = new d(b.Ci,
                                H => H, l6("boolean", H => H.value), m6("boolean")),
                            f = (new d(b.number, H => H, l6("int32", H => H.value), m6("int32"))).q7(H => Number.isInteger(H)),
                            g = (new d(b.number, H => H, l6("double", H => H.value), m6("double"))).q7(H => Number.isFinite(H)),
                            h = new d(b.instance("Fill"), H => c.instance("Fill", H), l6("fill", H => H.value), m6("fill")),
                            k = a.optional(),
                            l = e.optional(),
                            m = f.optional(),
                            n = g.optional(),
                            p = h.optional(),
                            q = a.oD(),
                            r = e.oD(),
                            t = f.oD(),
                            w = g.oD(),
                            u = h.oD(),
                            x = k.oD(),
                            y = l.oD(),
                            A = m.oD(),
                            z = n.oD(),
                            B = p.oD(),
                            G = {
                                [0]: {
                                    [0]: {
                                        string: a,
                                        boolean: e,
                                        int32: f,
                                        double: g,
                                        fill: h
                                    },
                                    [1]: {
                                        string: q,
                                        boolean: r,
                                        int32: t,
                                        double: w,
                                        fill: u
                                    }
                                },
                                [1]: {
                                    [0]: {
                                        string: k,
                                        boolean: l,
                                        int32: m,
                                        double: n,
                                        fill: p
                                    },
                                    [1]: {
                                        string: x,
                                        boolean: y,
                                        int32: A,
                                        double: z,
                                        fill: B
                                    }
                                }
                            };
                        return (H, K) => {
                            const I = new q_b(H),
                                M = Hf(K, S => S.key),
                                O = Hf(K, S => {
                                    var V = S.JVa;
                                    const ba = S.MSa;
                                    switch (S.type) {
                                        case "string":
                                            V = G[V][ba].string.q7(r_b(S.fL));
                                            break;
                                        case "boolean":
                                            V = G[V][ba]["boolean"];
                                            break;
                                        case "double":
                                            V = G[V][ba]["double"].q7(s_b(S.range));
                                            break;
                                        case "int32":
                                            V = G[V][ba].int32.q7(s_b(S.range));
                                            break;
                                        case "fill":
                                            V =
                                                G[V][ba].fill;
                                            break;
                                        default:
                                            throw new E(S);
                                    }
                                    return V.wtb(I, S.key)
                                });
                            return {
                                S8a: new Map(Object.entries(O).map(([S, V]) => [M[S], V.type])),
                                eval: S => {
                                    const V = Hf(O, ma => ma.eval(S)),
                                        ba = Hf(V, ma => ({
                                            get: ma.aNa
                                        })),
                                        ka = Hf(V, ma => ({
                                            get: ma.aNa,
                                            set: ma.crb
                                        }));
                                    return {
                                        Wpb: new Map(Object.entries(V).map(([ma, ra]) => [M[ma], ra.Teb])),
                                        data: Object.create(null, ba),
                                        uIb: Object.create(null, ka)
                                    }
                                }
                            }
                        }
                    },
                    l6 = function(a, b) {
                        return (c, d, e) => {
                            if (e == null) throw c.error(d, "not found");
                            if (e.type !== a) throw c.error(d, `type error: expected ${a}, was ${e.type}`);
                            return b(e)
                        }
                    },
                    m6 = function(a) {
                        return (b, c, d, e) => {
                            if (d == null) throw b.error(a, "value is nullish");
                            if (a === "string" && typeof d === "string" || a === "boolean" && typeof d === "boolean" || a === "double" && typeof d === "number" || a === "int32" && typeof d === "number") b = {
                                type: a,
                                value: d
                            };
                            else {
                                if (a === "fill" && typeof d === "object") throw b.error(a, "Write for fill is not yet supported");
                                throw b.error(a, `type error: expected ${a}, but received ${typeof d}`);
                            }
                            e.set(c, b)
                        }
                    },
                    s_b = function(a) {
                        if (a) {
                            var b = a.min,
                                c = a.max;
                            v(b == null || c == null || b <=
                                c);
                            return (d, e, f) => {
                                if (b != null && f < b) throw d.error(e, `value below min ${b}: ${f}`);
                                if (c != null && f > c) throw d.error(e, `value above max ${b}: ${f}`);
                            }
                        }
                    },
                    r_b = function(a) {
                        if (a) return (b, c, d) => {
                            if (!a.test(d)) throw b.error(c, `value does not match regex ${a}: '${d}'`);
                        }
                    },
                    p_b = function(a, b) {
                        return {
                            type: a,
                            eval: b
                        }
                    },
                    v_b = function() {
                        return (new u_b({})).add((a, b) => ({
                            Fill: new a("Fill", {
                                color: b.string
                            }, c => __c.UO.create({ ...__c.Kv,
                                color: c.color
                            }))
                        })).add((a, b) => ({
                            RectElement: new a("RectElement", {
                                top: b.number,
                                left: b.number,
                                width: b.number,
                                height: b.number,
                                rotation: b.union(b.number, b.undefined),
                                fill: b.instance("Fill"),
                                X: b.union(b.array(b.number), b.undefined)
                            }, c => {
                                var d, e, f;
                                const g = __c.Iv.create({ ...__c.Jv,
                                    top: c.top,
                                    left: c.left,
                                    width: c.width,
                                    height: c.height,
                                    rotation: (e = c.rotation) !== null && e !== void 0 ? e : __c.Jv.rotation,
                                    fill: __c.Kv,
                                    X: (f = (d = c.X) === null || d === void 0 ? void 0 : d.items) !== null && f !== void 0 ? f : __c.Jv.X
                                });
                                Object.defineProperties(g, {
                                    fill: {
                                        value: c.fill.instance
                                    }
                                });
                                return g
                            })
                        }))
                    },
                    n6 = function() {
                        throw Error("ref not found");
                    },
                    x_b = function(a, b) {
                        return class extends w_b {
                            componentDidCatch(c) {
                                a.error(c);
                                this.setState({
                                    hasError: !0
                                })
                            }
                            render() {
                                return this.state.hasError ? o6(__c.yy, {
                                    background: "criticalLow",
                                    width: "full",
                                    height: "full",
                                    padding: "0.25u",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    role: "alert",
                                    children: o6(__c.vy, {
                                        size: "xsmall",
                                        alignment: "center",
                                        children: __c.P("Q6XSow")
                                    })
                                }) : o6(b, { ...this.props
                                })
                            }
                            constructor(...c) {
                                super(...c);
                                this.state = {
                                    hasError: !1
                                }
                            }
                        }
                    },
                    y_b = function(a, b) {
                        var c = a.H2a.get(b.id);
                        if (c) return c;
                        c = a.k$a(b.id, b.uN);
                        a.H2a.set(b.id, c);
                        return c
                    },
                    z_b = __webpack_require__(519427),
                    p6 = z_b.computed,
                    A_b = z_b.observable;
                var o6 = __webpack_require__(443763).jsx;
                var q6 = __webpack_require__(875604),
                    B_b = q6.memo,
                    w_b = q6.PureComponent,
                    C_b = q6.useState;
                var h6 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.Ula = a;
                            this.resultType = b;
                            this.apply = c
                        }
                    },
                    r6 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c, d) {
                            this.Ula = a;
                            this.D6a = b;
                            this.resultType = c;
                            this.apply = d
                        }
                    },
                    s6 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.F6a = a;
                            this.resultType = b;
                            this.apply = c
                        }
                    },
                    E_b = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b) {
                            var c = D_b;
                            this.E6a = a;
                            this.resultType = b;
                            this.apply = c
                        }
                    },
                    JZb = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c, d) {
                            this.itemType = a;
                            this.$6a = b;
                            this.resultType = c;
                            this.reduce =
                                d
                        }
                    };
                var MZb = class {
                    map(a) {
                        return a(this)
                    }
                    constructor(a, b) {
                        this.type = a;
                        this.get = b
                    }
                };
                var F_b = class {},
                    UZb = class extends F_b {
                        tma(a) {
                            return new UZb(a(this.value))
                        }
                        qqa(a) {
                            return a(this.value)
                        }
                        constructor(a) {
                            super();
                            this.value = this.value = a
                        }
                    },
                    VZb = class extends F_b {
                        tma(a, b) {
                            return new VZb(b(this.value))
                        }
                        qqa(a, b) {
                            return b(this.value)
                        }
                        constructor(a) {
                            super();
                            this.value = this.value = a
                        }
                    };
                var a6 = class {
                        map(a) {
                            return a(this)
                        }
                    },
                    t6 = class extends a6 {
                        Isa(a) {
                            return this === a || a.oza(b => this.vca(b))
                        }
                        NO() {
                            throw Error(`${this} is not iterable`);
                        }
                        Bua(a) {
                            var b;
                            const c = (b = this.propTypes) !== null && b !== void 0 ? b : this.propTypes = this.Dda();
                            if (!c) throw Error(`${this} is not navigable"`);
                            if (!c.hasOwnProperty(a)) throw Error(`${this} has no navigable property "${a}"`);
                            return c[a]
                        }
                        Dda() {
                            throw Error(`${this} is not navigable`);
                        }
                        zqa(a) {
                            a(this)
                        }
                        oza(a) {
                            return a(this)
                        }
                        constructor() {
                            super();
                            this.kind = "simple";
                            this.propTypes =
                                void 0
                        }
                    },
                    u6 = class extends t6 {
                        vca(a) {
                            return a instanceof u6 && this.name === a.name
                        }
                        toString() {
                            return this.name
                        }
                        constructor(a) {
                            super();
                            this.name = a
                        }
                    },
                    v6 = class extends t6 {
                        vca(a) {
                            return a instanceof v6 && this.bF === a.bF
                        }
                        toString() {
                            return this.bF.name
                        }
                        constructor(a) {
                            super();
                            this.bF = a
                        }
                    },
                    w6 = class extends t6 {
                        vca(a) {
                            return a instanceof w6 && this.bF === a.bF && $5(this.zw, a.zw)
                        }
                        toString() {
                            return `${this.bF}<${this.zw}>`
                        }
                        constructor(a, b) {
                            super();
                            this.bF = a;
                            this.zw = b
                        }
                    },
                    G_b = class extends w6 {
                        NO() {
                            return this.zw
                        }
                        Dda() {
                            const a =
                                this.zw;
                            return {
                                size: f6.number,
                                empty: f6.Ci,
                                get first() {
                                    return f6.optional(a)
                                }
                            }
                        }
                        constructor(a) {
                            super("array", a)
                        }
                    },
                    H_b = class extends w6 {
                        NO() {
                            return this.zw
                        }
                        Dda() {
                            const a = this.zw;
                            return {
                                size: f6.number,
                                empty: f6.Ci,
                                get first() {
                                    return f6.optional(a)
                                }
                            }
                        }
                        constructor(a) {
                            super("set", a)
                        }
                    },
                    I_b = class extends t6 {
                        vca(a) {
                            return a instanceof I_b ? Object.entries(a.fields).every(([b, c]) => this.fields.hasOwnProperty(b) && $5(this.fields[b], c)) : !1
                        }
                        Dda() {
                            return this.fields
                        }
                        toString() {
                            const a = Object.entries(this.fields);
                            return a.length ?
                                `{ ${a.map(([b,c])=>`${b}: ${c}`).join(", ")} }` : "{}"
                        }
                        constructor(a) {
                            super();
                            this.fields = a
                        }
                    },
                    x6 = class extends a6 {
                        Isa(a) {
                            return this === a || this.Cn.every(b => b.Isa(a))
                        }
                        NO() {
                            const a = this.Cn.map(b => b.NO());
                            return Z5(a, b => f6.union(...b))
                        }
                        Bua(a) {
                            const b = this.Cn.map(c => c.Bua(a));
                            return Z5(b, c => f6.union(...c))
                        }
                        zqa(a) {
                            this.Cn.forEach(b => b.zqa(a))
                        }
                        oza(a) {
                            return this.Cn.some(b => b.oza(a))
                        }
                        toString() {
                            return this.Cn.length ? this.Cn.map(a => a.toString()).join(" | ") : "never"
                        }
                        constructor(a) {
                            super();
                            this.Cn = a;
                            this.kind =
                                "disjunction";
                            v(a.length !== 1)
                        }
                    },
                    y6 = new x6([]),
                    J_b = new u6("string"),
                    K_b = new u6("number"),
                    L_b = new u6("boolean"),
                    M_b = new u6("undefined"),
                    N_b = class {
                        get never() {
                            return y6
                        }
                        get string() {
                            return J_b
                        }
                        get number() {
                            return K_b
                        }
                        get Ci() {
                            return L_b
                        }
                        get undefined() {
                            return M_b
                        }
                        optional(a) {
                            return f6.union(a, f6.undefined)
                        }
                        array(a) {
                            return new G_b(a)
                        }
                        set(a) {
                            return new H_b(a)
                        }
                        e$(a) {
                            return new x6([new G_b(a), new H_b(a)])
                        }
                        ed(a) {
                            return new I_b({ ...a
                            })
                        }
                        union(...a) {
                            if (a.length === 0) return y6;
                            if (a.length === 1) return a[0];
                            const b =
                                new Set;
                            for (const d of a) LZb(d).zqa(e => b.add(e));
                            a = [...b];
                            if (a.length === 0) return y6;
                            if (a.length === 1) return a[0];
                            if (a.length === 2) {
                                const [d, e] = a;
                                return $5(d, e) ? e : $5(e, d) ? d : new x6(a)
                            }
                            const c = new Set;
                            for (const d of a)[...c].some(e => $5(d, e)) || (c.forEach(e => $5(e, d) && c.delete(e)), c.add(d));
                            return c.size === 1 ? [...c][0] : new x6([...c])
                        }
                    },
                    O_b = class extends N_b {
                        instance(a) {
                            return new v6(a)
                        }
                    },
                    f6 = new O_b,
                    P_b = class extends N_b {
                        instance(a) {
                            return new v6(__c.D(this.classes[a]))
                        }
                        constructor(a) {
                            super();
                            this.classes =
                                a
                        }
                    };
                var z6 = Symbol("value"),
                    A6 = class {
                        get props() {
                            var a;
                            return (a = this.R5a) !== null && a !== void 0 ? a : this.R5a = this.Vla()
                        }
                    },
                    Q_b = class {
                        get size() {
                            return this[z6].length
                        }
                        get empty() {
                            return this[z6].length === 0
                        }
                        get first() {
                            return this[z6][0]
                        }
                        constructor(a) {
                            this[z6] = a
                        }
                    },
                    R_b = class extends A6 {
                        Vla() {
                            return new Q_b(this.items)
                        }
                        map(a) {
                            return this.items.map(a)
                        }[Symbol.iterator]() {
                            return this.items[Symbol.iterator]()
                        }
                        toString() {
                            return this.items.length ? `[${Array.from(this.items,c6).join(", ")}]` : "[]"
                        }
                        constructor(a) {
                            super();
                            this.kind = "array";
                            this.items = [...a]
                        }
                    },
                    S_b = class {
                        get size() {
                            return this[z6].size
                        }
                        get empty() {
                            return this[z6].size === 0
                        }
                        get first() {
                            return this[z6][Symbol.iterator]().next().value
                        }
                        constructor(a) {
                            this[z6] = a
                        }
                    },
                    T_b = class extends A6 {
                        Vla() {
                            return new S_b(this.items)
                        }
                        map(a) {
                            return Array.from(this.items, a)
                        }[Symbol.iterator]() {
                            return this.items[Symbol.iterator]()
                        }
                        toString() {
                            return this.items.size ? `Set [${Array.from(this.items,c6).join(", ")}]` : "Set []"
                        }
                        constructor(a) {
                            super();
                            this.kind = "set";
                            this.items = new Set(a)
                        }
                    },
                    U_b = class extends A6 {
                        Vla() {
                            return this.fields
                        }
                        toString() {
                            const a = Object.entries(this.fields);
                            return a.length ? `{ ${[...a].map(([b,c])=>`${b}: ${c6(c)}`).join(", ")} }` : "{}"
                        }
                        constructor(a) {
                            super();
                            this.fields = a;
                            this.kind = "record"
                        }
                    },
                    V_b = class {
                        toString() {
                            return `[instance ${this.bF.name}]`
                        }
                        constructor(a, b) {
                            this.bF = a;
                            this.instance = b;
                            this.kind = "instance"
                        }
                    },
                    W_b = class {
                        array(a) {
                            return new R_b(a)
                        }
                        arrayOf(...a) {
                            return new R_b(a)
                        }
                        set(a) {
                            return new T_b(a)
                        }
                        ed(a) {
                            return new U_b({ ...a
                            })
                        }
                    },
                    X_b = class extends W_b {
                        instance(a,
                            b) {
                            return new V_b(a, b)
                        }
                        stringify(a) {
                            return c6(a)
                        }
                        constructor() {
                            super();
                            this.Jh = b6
                        }
                    },
                    k6 = new X_b,
                    Y_b = class extends W_b {
                        instance(a, b) {
                            a = __c.D(this.classes[a]);
                            return new V_b(a, b)
                        }
                        constructor(a) {
                            super();
                            this.classes = a
                        }
                    };
                var RZb = {
                        [0]: new h6(f6.number, f6.number, a => -a),
                        [1]: new h6(f6.string, f6.number, a => a.length),
                        [2]: new h6(f6.Ci, f6.Ci, a => !a)
                    },
                    SZb = {
                        [0]: new r6(f6.number, f6.number, f6.number, (a, b) => a + b),
                        [1]: new r6(f6.number, f6.number, f6.number, (a, b) => a - b),
                        [2]: new r6(f6.number, f6.number, f6.number, (a, b) => a * b),
                        [3]: new r6(f6.number, f6.number, f6.number, (a, b) => a / b),
                        [4]: new r6(f6.number, f6.number, f6.number, (a, b) => a % b),
                        [5]: new r6(f6.string, f6.string, f6.string, (a, b) => a + b),
                        [6]: new r6(f6.number, f6.number, f6.Ci, (a, b) => a === b),
                        [7]: new r6(f6.number,
                            f6.number, f6.Ci, (a, b) => a !== b),
                        [8]: new r6(f6.number, f6.number, f6.Ci, (a, b) => a < b),
                        [9]: new r6(f6.number, f6.number, f6.Ci, (a, b) => a <= b),
                        [10]: new r6(f6.number, f6.number, f6.Ci, (a, b) => a > b),
                        [11]: new r6(f6.number, f6.number, f6.Ci, (a, b) => a >= b),
                        [12]: new r6(f6.Ci, f6.Ci, f6.Ci, (a, b) => a && b),
                        [13]: new r6(f6.Ci, f6.Ci, f6.Ci, (a, b) => a || b)
                    },
                    YZb = {
                        [2]: new s6(f6.number, f6.number, a => a.reduce((b, c) => b + c, 0)),
                        [3]: new s6(f6.number, f6.number, a => a.reduce((b, c) => b * c, 1)),
                        [4]: new s6(f6.number, f6.number, a => Math.max(...a)),
                        [5]: new s6(f6.number,
                            f6.number, a => Math.min(...a)),
                        [6]: new s6(f6.string, f6.string, a => a.join(""))
                    },
                    Z_b = a => k6.array(a),
                    $_b = a => k6.set(a),
                    WZb = {
                        [0]: a => new s6(a, f6.array(a), Z_b),
                        [1]: a => new s6(a, f6.set(a), $_b)
                    },
                    D_b = a => k6.ed(a),
                    c_b = {
                        [0]: a => new E_b(a, f6.ed(a))
                    },
                    a0b = (a, b) => k6.array(b.map(c => c())),
                    b0b = (a, b) => k6.array(b.flatMap(c => c().items)),
                    c0b = (a, b) => k6.array(a.filter((c, d) => b[d]()).map(c => c())),
                    d0b = (a, b) => b.some(c => c()),
                    e0b = (a, b) => b.every(c => c()),
                    f0b = (a, b) => {
                        var c;
                        return (c = a.find((d, e) => b[e]())) === null || c === void 0 ? void 0 : c()
                    },
                    a_b = {
                        [0]: (a, b) => Y5(a, b, f6.array(b), a0b),
                        [1]: (a, b) => b.NO().map(c => Y5(a, f6.array(c), f6.array(c), b0b)),
                        [2]: a => Y5(a, f6.Ci, f6.array(a), c0b),
                        [3]: a => Y5(a, f6.Ci, f6.Ci, d0b),
                        [4]: a => Y5(a, f6.Ci, f6.Ci, e0b),
                        [5]: a => Y5(a, f6.Ci, f6.optional(a), f0b)
                    };
                var j6 = class {
                    define(a, b) {
                        return new j6(new Map([
                            [a, b]
                        ]), this)
                    }
                    resolve(a) {
                        const b = this.defs.get(a);
                        if (b) return b;
                        if (this.parent) return this.parent.resolve(a);
                        throw Error(`undefined symbol: ${a}`);
                    }
                    constructor(a, b) {
                        this.defs = a;
                        this.parent = b
                    }
                };
                var h0b = (a, b, c) => {
                        const d = new j6(new Map(b.S8a)),
                            e = new g0b(a);
                        return {
                            compile: f => {
                                const g = d6(e, d, f).as(c);
                                return {
                                    eval: h => {
                                        h = new j6(new Map(b.eval(h).Wpb));
                                        return g.eval(h)
                                    }
                                }
                            }
                        }
                    },
                    g0b = class {
                        constructor(a) {
                            this.types = a
                        }
                    },
                    i6 = class {
                        static of (a, b) {
                            return new i6(a, b)
                        }
                        as(a) {
                            if (!$5(this.type, a)) throw Error(`inferred type ${this.type} does not match expected type: ${a}`);
                            return this
                        }
                        eval(a) {
                            return this.Xka(a)
                        }
                        computed() {
                            return new i6(this.type, a => {
                                const b = p6(this.eval(a), {
                                    equals: k6.Jh
                                });
                                return () => b.get()
                            })
                        }
                        map(a) {
                            return a(this)
                        }
                        constructor(a,
                            b) {
                            this.type = a;
                            this.Xka = b
                        }
                    },
                    i_b = class {
                        static of (a, b, c) {
                            return new i_b(a, b, c)
                        }
                        eval(a) {
                            return this.Xka(a)
                        }
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.resultType = b;
                            this.Xka = c
                        }
                    };
                var u_b = class {
                        add(a) {
                            a = a(i0b, this.types);
                            return new u_b({ ...this.classes,
                                ...a
                            })
                        }
                        resolve(a) {
                            return this.classes[a]
                        }
                        constructor(a) {
                            this.classes = a;
                            this.types = new P_b(this.classes);
                            this.values = new Y_b(this.classes)
                        }
                    },
                    i0b = class {
                        constructor(a, b, c) {
                            this.name = a;
                            this.create = c;
                            this.Tkb = new h6(f6.ed(b), f6.instance(this), d => k6.instance(this, c(d.fields)))
                        }
                    };
                var q_b = class {
                    error(a, b) {
                        return Error(`widget '${this.Avb}': schema error on key '${a}': ${b}`)
                    }
                    constructor(a) {
                        this.Avb = a
                    }
                };
                var j0b = Object.freeze({
                    empty: !0,
                    count() {
                        return 0
                    },
                    toArray() {
                        return []
                    },
                    Lt() {
                        return new Map
                    },
                    first() {},
                    last() {},
                    next() {
                        n6()
                    },
                    fc() {
                        n6()
                    },
                    cf() {
                        n6()
                    },
                    xC() {
                        n6()
                    },
                    has() {
                        return !1
                    },
                    Uu() {
                        return this
                    },
                    map() {
                        return []
                    },
                    flatMap() {
                        return []
                    },
                    filter() {
                        return []
                    },
                    forEach() {},
                    reduce(a, b) {
                        return b
                    },
                    some() {
                        return !1
                    },
                    every() {
                        return !0
                    },
                    [Symbol.iterator]() {
                        return [][Symbol.iterator]()
                    }
                });
                var k0b = class {
                    static A(a) {
                        __c.Q(a, {
                            Te: p6,
                            Iz: p6
                        })
                    }
                    get Te() {
                        return this.K6a().map(a => {
                            let b = this.gOa.get(a);
                            b == null && (b = `${this.Tfb++}`, this.gOa.set(a, b));
                            return {
                                id: b,
                                ref: a
                            }
                        })
                    }
                    get Iz() {
                        const a = new Map;
                        this.Te.forEach((b, c) => b && a.set(b.ref, c));
                        return a
                    }
                    Qm(a) {
                        return __c.D(this.Iz.get(a), "ref not found")
                    }
                    get empty() {
                        return !this.Te.length
                    }
                    count() {
                        return this.Te.length
                    }
                    toArray() {
                        return this.Te.map(a => a.ref)
                    }
                    Lt() {
                        return new Map(this.map((a, b) => [b, a]))
                    }
                    get Vaa() {
                        const a = this.Te[0];
                        return a && a.ref
                    }
                    get mda() {
                        const a =
                            this.Te[this.Te.length - 1];
                        return a && a.ref
                    }
                    first(a) {
                        if (!a) return this.Vaa;
                        const b = this.Te.find(c => a(c.ref));
                        return b && b.ref
                    }
                    last(a) {
                        if (!a) return this.mda;
                        const b = this.Te;
                        for (let c = b.length - 1; c >= 0; c--) {
                            const d = b[c];
                            if (a(d.ref)) return d.ref
                        }
                    }
                    next(a, b) {
                        const c = this.Te;
                        for (a = this.Qm(a) + 1; a < c.length; a++) {
                            const d = c[a];
                            if (!b || b(d.ref)) return d.ref
                        }
                    }
                    fc(a, b) {
                        const c = this.Te;
                        for (a = this.Qm(a) - 1; a >= 0; a--) {
                            const d = c[a];
                            if (!b || b(d.ref)) return d.ref
                        }
                    }
                    cf(a, b) {
                        a = this.Iz.get(a);
                        b = this.Iz.get(b);
                        v(a != null);
                        v(b != null);
                        return a < b ? -1 : a > b ? 1 : 0
                    }
                    xC(a) {
                        return this.Te[this.Qm(a)].id
                    }
                    has(a) {
                        return this.Iz.has(a)
                    }
                    Uu(a) {
                        return new __c.aO(this, a)
                    }
                    map(a) {
                        return this.Te.map(({
                            ref: b,
                            id: c
                        }) => a(b, c))
                    }
                    flatMap(a) {
                        return this.Te.flatMap(({
                            ref: b,
                            id: c
                        }) => a(b, c))
                    }
                    filter(a) {
                        return this.Te.filter(b => a(b.ref, b.id)).map(b => b.ref)
                    }
                    forEach(a) {
                        this.Te.forEach((b, c) => a(b.ref, b.id, c))
                    }
                    reduce(a, b) {
                        return this.Te.reduce((c, d) => a(c, d.ref, d.id), b)
                    }
                    some(a) {
                        return this.Te.some(b => a(b.ref, b.id))
                    }
                    every(a) {
                        return this.Te.every(b => a(b.ref, b.id))
                    }[Symbol.iterator]() {
                        return this.toArray()[Symbol.iterator]()
                    }
                    constructor(a) {
                        this.K6a =
                            a;
                        this.Tfb = (k0b.A(this), 0);
                        this.gOa = new WeakMap
                    }
                };
                var l0b = new Set,
                    m0b = {
                        fz: () => ({
                            $a: j0b
                        })
                    },
                    n0b = class {
                        static A(a) {
                            __c.Q(a, {
                                Jxa: A_b.shallow
                            })
                        }
                        aPa(a) {
                            if (!l0b.has(a.id)) {
                                var b = a.map(c => {
                                    const d = y_b(this.G2a, c);
                                    if (c.fz) {
                                        const e = c.fz;
                                        if (typeof e === "function") return {
                                            type: 0,
                                            fz: ({
                                                na: h
                                            }) => e({
                                                data: d.eval(h).data
                                            })
                                        };
                                        c = this.$m.types;
                                        const f = c.instance("RectElement"),
                                            g = this.doa(this.$m, d, c.e$(f)).compile(e);
                                        return {
                                            type: 0,
                                            fz: ({
                                                na: h
                                            }) => {
                                                const k = g.eval(h);
                                                return {
                                                    $a: new __c.O0a(new k0b(() => Array.from(k()).map(l => l.instance)))
                                                }
                                            }
                                        }
                                    }
                                    if (c.Component) {
                                        const e = c.Component;
                                        return {
                                            type: 1,
                                            Component: x_b(this.H, B_b(function({
                                                Zab: f
                                            }) {
                                                const [g] = C_b(() => d.eval({
                                                    ph: f
                                                }).data);
                                                return o6(e, {
                                                    data: g
                                                })
                                            }))
                                        }
                                    }
                                    throw new E(c);
                                });
                                this.Jxa.set(a.id, b);
                                l0b.add(a.id);
                                __c.ZP.set(a.id, m0b)
                            }
                        }
                        Scb(a) {
                            return this.Jxa.get(a)
                        }
                        constructor(a, b, c, d) {
                            this.G2a = a;
                            this.$m = b;
                            this.doa = c;
                            this.H = d;
                            this.Jxa = (n0b.A(this), new Map)
                        }
                    };
                var o0b = class {
                    constructor(a) {
                        this.k$a = a;
                        this.H2a = new Map
                    }
                };
                __c.qQa = {
                    Qgb: function({
                        H: a
                    }) {
                        var b = {
                            $m: v_b(),
                            doa: h0b
                        };
                        const {
                            $m: c,
                            doa: d
                        } = b;
                        b = t_b(c);
                        b = new o0b(b);
                        a = new n0b(b, c, d, a);
                        return {
                            G2a: b,
                            F7: a,
                            G7: a
                        }
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/72e45826280fb482.js.map