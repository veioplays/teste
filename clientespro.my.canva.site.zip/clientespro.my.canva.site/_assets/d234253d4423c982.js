(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [60060], {

        /***/
        82986: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(914242);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var JM = __c.JM;
                var W = __c.W;
                var L = __c.L;
                var Ia = __c.Ia;
                var WYb = function() {
                        return new __c.F_({
                            id: "w:demo-blueprint",
                            uN: UYb,
                            fz: ({
                                data: a
                            }) => {
                                var b = VYb.get(a.vma);
                                if (!b) throw Error(`Blueprint ${a.vma} not found`);
                                b = b.variants.find(c => c.nR === a.nR);
                                if (!b) throw Error(`Variant ${a.nR} not found for blueprint ${a.vma}`);
                                return {
                                    $a: b.$a
                                }
                            }
                        })
                    },
                    ZYb = function(a, b) {
                        var c = XYb,
                            d = YYb;
                        a.handle("SET_CONFIG", async e => {
                            if (e === void 0) throw new U5({
                                code: "internal_error",
                                message: "SET_CONFIG: request cannot be undefined."
                            });
                            e = c.kd(e);
                            e = await b(e);
                            if (d) return d.Id(e)
                        })
                    },
                    bZb = async function(a,
                        b) {
                        a = await a.UIa.request("RENDER_ELEMENT", $Yb.Id(b));
                        if (!a.ok) throw Error(`Encountered an error while sending ${"RENDER_ELEMENT"} request: ${a.error}`);
                        if (a.value == null) throw Error("RENDER_ELEMENT: Result cannot be empty");
                        return aZb.kd(a.value)
                    },
                    cZb = function(a) {
                        ZYb(a.UIa, b => a.handler.tfb(b))
                    },
                    eZb = async function(a, b) {
                        const c = b.requestId,
                            d = b.path;
                        b = b.Xm;
                        const e = a.requestHandler.get(d);
                        if (e) {
                            a.H3.LZ.send({
                                type: "ack",
                                requestId: c
                            });
                            var f = setInterval(() => a.H3.LZ.send({
                                type: "ack",
                                requestId: c
                            }), 9E3);
                            try {
                                var g =
                                    await e(b);
                                clearInterval(f);
                                a.H3.LZ.send({
                                    type: "response",
                                    requestId: c,
                                    payload: g
                                })
                            } catch (k) {
                                clearInterval(f);
                                g = "internal_error";
                                b = "Something went wrong on our end, if this issue persists please contact us.";
                                if (k instanceof U5) {
                                    var h = k;
                                    k.code === "internal_error" ? a.H.Nb(k, {
                                        Ve: "Internal error in comms handler",
                                        tags: new Map([
                                            ["type", "request"],
                                            ["path", d]
                                        ])
                                    }) : (g = k.code, b = k.Pob)
                                } else a.xpb ? a.H.Nb(k, {
                                    Ve: "Unexpected error type thrown from comms handler",
                                    tags: new Map([
                                        ["type", "request"],
                                        ["path", d]
                                    ])
                                }) : a.gab.error(k);
                                g = dZb(a.H3, c, g, b);
                                g.ok || a.H.pN(g.error, {
                                    Ve: "unable to send error response",
                                    tags: new Map([
                                        ["type", "request"],
                                        ["path", d]
                                    ])
                                })
                            }
                            if (h != null)
                                for (const k of a.ecb) try {
                                    k(h)
                                } catch (l) {
                                    a.H.yR(l, {
                                        Ve: "Error executing errorObserver"
                                    })
                                }
                        } else h = dZb(a.H3, c, "internal_error", `No request handler configured for path: "${d}".`), h.ok || a.H.pN(h.error, {
                            Ve: "unable to send error response",
                            tags: new Map([
                                ["type", "request"],
                                ["path", d]
                            ])
                        })
                    },
                    dZb = function(a, b, c, d) {
                        return a.LZ.send({
                            type: "error",
                            requestId: b,
                            code: c,
                            message: d
                        })
                    },
                    gZb =
                    function({
                        src: a,
                        srcdoc: b,
                        sandbox: c
                    }) {
                        if (b.length !== 0 || !c.contains("allow-same-origin")) return fZb;
                        a = (new URL(a)).origin;
                        return a === "null" ? fZb : {
                            hDa: a,
                            ZXa: a
                        }
                    },
                    jZb = async function(a, b, c, {
                        addEventListener: d,
                        removeEventListener: e
                    } = window) {
                        const f = new hZb(6E4),
                            g = gZb(c),
                            h = c.contentWindow;
                        if (!h) throw new U5({
                            code: "internal_error",
                            message: "contentWindow is missing from iFrame"
                        });
                        c = ({
                            data: k,
                            source: l,
                            origin: m
                        }) => {
                            var n;
                            (k === null || k === void 0 ? 0 : (n = k.source) === null || n === void 0 ? 0 : n.startsWith("react-")) || (m !== g.hDa ?
                                iZb(m) || b.info("received message event from an unexpected origin", {
                                    extra: new Map([
                                        ["expected", g.hDa],
                                        ["actual", m]
                                    ])
                                }) : l !== h ? l !== window && b.info("source and content window do not match", {
                                    extra: new Map([
                                        ["data.source", k === null || k === void 0 ? void 0 : k.source]
                                    ])
                                }) : (l = k ? k.source ? k.source !== "iframe" ? Ia("invalid source") : (0, __c.Ha)() : Ia("'source' is missing in MessageEvent data object") : Ia("missing 'data' field in MessageEvent"), l.ok ? (h.postMessage({
                                    source: "parent"
                                }, g.ZXa, [a]), f.resolve(void 0)) : b.kM(l.error, {
                                    extra: new Map([
                                        ["data.source", k === null || k === void 0 ? void 0 : k.source]
                                    ])
                                })))
                        };
                        d("message", c);
                        try {
                            await f.promise()
                        } finally {
                            e("message", c)
                        }
                    },
                    iZb = function(a) {
                        return kZb.some(b => a.endsWith(b))
                    },
                    pZb = async function(a, b, c) {
                        const {
                            port1: d,
                            port2: e
                        } = new MessageChannel;
                        var f = new lZb(d, a.H);
                        await jZb(e, a.H, b, window);
                        const g = new mZb(f, {
                            tfb: h => {
                                V5(() => {
                                    const k = h.width,
                                        l = h.height;
                                    c.ura.ph.set("config", {
                                        type: "string",
                                        value: h.config
                                    });
                                    nZb(c, {
                                        width: k,
                                        height: l
                                    })
                                });
                                return new YYb
                            }
                        });
                        f = oZb(() => c.ura.ph.get("config"), async h => {
                            let k;
                            h && (__c.C(h.type === "string"), k = h.value);
                            const {
                                width: l,
                                height: m
                            } = await bZb(g, {
                                config: k
                            });
                            V5(() => {
                                nZb(c, {
                                    width: l,
                                    height: m
                                })
                            })
                        }, {
                            fireImmediately: !0
                        });
                        a.Nh.set(b, f)
                    },
                    nZb = function(a, b) {
                        const c = a.hbb,
                            d = a.ura,
                            e = b.width,
                            f = b.height;
                        if (!(e < 0 || f < 0)) {
                            var g = d.height,
                                h = e / f * g;
                            V5(() => {
                                c.width = h;
                                c.height = g;
                                c.I = e;
                                c.V = f;
                                d.width = h;
                                d.I = h;
                                d.V = g
                            })
                        }
                    },
                    sZb = function({
                        Apa: a,
                        H: b
                    }) {
                        const c = new qZb(b);
                        a && (a.$C = async (d, {
                            element: e,
                            container: f
                        }) => {
                            (f === null || f === void 0 ? void 0 : f.type) === "group-element" && __c.pj(f.group) && f.group.$e.app.id ===
                                "w:codelet" && (__c.C((e === null || e === void 0 ? void 0 : e.type) === "embed"), pZb(c, d, {
                                    hbb: e,
                                    ura: f.group
                                }))
                        }, a.RV = d => {
                            var e;
                            (e = c.Nh.get(d)) === null || e === void 0 || e();
                            c.Nh.delete(d)
                        });
                        return rZb
                    },
                    xZb = function() {
                        return new __c.F_({
                            id: "w:demo-form",
                            uN: tZb,
                            Component: uZb(({
                                data: a
                            }) => vZb(wZb, {
                                state: a
                            }))
                        })
                    };
                __c.jd.prototype.pN = __c.fa(3, function(a, b) {
                    this.console.error(...__c.id(this, "critical", a, b))
                });
                __c.kM.prototype.pN = __c.fa(2, function(a, b) {
                    this.yu.pN(a, b);
                    __c.iM(this, a, "critical", b)
                });
                var W5 = __webpack_require__(519427),
                    yZb = W5.ObservableMap,
                    oZb = W5.reaction,
                    V5 = W5.runInAction;
                var vZb = __webpack_require__(443763).jsx;
                var zZb = __webpack_require__(875604).memo;
                var uZb = __webpack_require__(446474).Pi;
                var VYb = new yZb,
                    UYb = {
                        vma: __c.E_("blueprintId", 0),
                        nR: __c.E_("variantId", 0)
                    };
                var U5 = class extends Error {
                    constructor(a) {
                        a.code = a.code;
                        const b = a.message.endsWith(".") ? "" : ".";
                        super(`[${a.code}]:  ${a.message}${b}`.trim());
                        this.code = a.code;
                        this.name = "CanvaError";
                        this.Pob = a.message;
                        Object.setPrototypeOf(this, U5.prototype)
                    }
                };
                var $Yb = L(() => ({
                    config: __c.Y(1)
                }));
                var AZb = L(() => ({
                    color: W(1)
                }));
                var BZb = L(() => ({
                    type: __c.F("A?", 1, "RECOLORABLE"),
                    id: W(1),
                    value: __c.Sa(2, AZb)
                }));
                var CZb = L(() => ({
                    borderRadius: JM(1),
                    borderWidth: JM(2)
                }));
                var DZb = L(() => ({
                    type: __c.F("A?", 2, "BORDERABLE"),
                    id: W(1),
                    value: __c.Sa(2, CZb)
                }));
                var aZb = L(() => ({
                    config: W(1),
                    width: JM(2),
                    height: JM(3),
                    yW: __c.Ta(4, BZb),
                    D7a: __c.Ta(5, DZb)
                }));
                var XYb = L(() => ({
                    config: W(1),
                    width: JM(2),
                    height: JM(3),
                    yW: __c.Ta(4, BZb),
                    D7a: __c.Ta(5, DZb)
                }));
                var YYb = L(() => ({}));
                var mZb = class {
                    constructor(a, b) {
                        this.UIa = a;
                        this.handler = b;
                        cZb(this)
                    }
                };
                var EZb = class {
                    constructor(a, b, c) {
                        this.handler = a;
                        this.port = b;
                        this.H = c;
                        this.send = d => {
                            try {
                                return this.port.postMessage(d), (0, __c.Ha)()
                            } catch (e) {
                                return this.H.Nb(e), Ia(e)
                            }
                        };
                        this.nmb = d => {
                            this.H.Nb(d)
                        };
                        this.onMessage = ({
                            data: d
                        }) => {
                            if (d) try {
                                this.handler.Tob(d)
                            } catch (e) {
                                this.H.Nb(e)
                            } else this.H.error(new U5({
                                code: "internal_error",
                                message: "missing data in 'MessageEvent'"
                            }))
                        };
                        this.port.onmessage = this.onMessage;
                        this.port.onmessageerror = this.nmb
                    }
                };
                var X5 = new U5({
                        code: "internal_error",
                        message: "Comms promise timed out."
                    }),
                    hZb = class {
                        reset(a) {
                            a && (this.timeoutMs = a);
                            this.setTimeout()
                        }
                        resolve(a) {
                            clearTimeout(this.Vd);
                            this.Fpb(a)
                        }
                        reject(a) {
                            clearTimeout(this.Vd);
                            this.HWa(a)
                        }
                        promise() {
                            return this.p
                        }
                        setTimeout() {
                            clearTimeout(this.Vd);
                            this.Vd = setTimeout(() => {
                                this.HWa(X5)
                            }, this.timeoutMs)
                        }
                        constructor(a) {
                            this.timeoutMs = a;
                            this.p = new Promise((b, c) => {
                                this.Fpb = b;
                                this.HWa = c
                            });
                            this.setTimeout()
                        }
                    };
                var FZb = class {
                    request(a, b) {
                        const c = this.mVa,
                            d = new hZb(5E3),
                            e = this.zpb(),
                            f = async function() {
                                c.set(e, d);
                                try {
                                    const g = await d.promise();
                                    return (0, __c.Ha)(g)
                                } catch (g) {
                                    return g === X5 ? Ia(new U5({
                                        code: X5.code,
                                        message: `Comms promise timed out (${a}).`
                                    })) : Ia(g)
                                } finally {
                                    c.delete(e)
                                }
                            }();
                        b = this.send(e, a, b);
                        b.ok || (this.H.Nb(b.error, {
                            Ve: "unable to send request",
                            tags: new Map([
                                ["type", "request"],
                                ["path", a]
                            ])
                        }), d.reject(b.error));
                        return f
                    }
                    constructor(a, b) {
                        this.send = a;
                        this.H = b;
                        this.zpb = __c.js;
                        this.mVa = new Map
                    }
                };
                var GZb = class {
                    handle(a, b) {
                        if (this.requestHandler.has(a)) throw new U5({
                            code: "internal_error",
                            message: `Handler for '${a}' is already defined.`
                        });
                        this.requestHandler.set(a, b)
                    }
                    constructor(a, b) {
                        var c = console;
                        this.H3 = a;
                        this.H = b;
                        this.xpb = !0;
                        this.gab = c;
                        this.requestHandler = new Map;
                        this.ecb = new Set
                    }
                };
                var lZb = class {
                        constructor(a, b) {
                            this.request = (c, d) => this.client.request(c, d);
                            this.handle = (c, d) => this.requestHandler.handle(c, d);
                            a = new HZb(c => {
                                switch (c.type) {
                                    case "ack":
                                    case "error":
                                    case "response":
                                        var d = this.client;
                                        const e = c.requestId,
                                            f = c.type,
                                            g = d.mVa.get(e);
                                        if (g) switch (f) {
                                            case "response":
                                                g.resolve(c.Xm);
                                                break;
                                            case "ack":
                                                g.reset(2E4);
                                                break;
                                            case "error":
                                                g.reject(new U5({
                                                    code: c.code,
                                                    message: c.message
                                                }));
                                                break;
                                            default:
                                                throw new __c.E(c);
                                        } else f !== "ack" && d.H.error("request has already been handled and resolved or was not sent from this client", {
                                            tags: new Map([
                                                ["type", f],
                                                ["requestId", `${e}`]
                                            ])
                                        });
                                        break;
                                    case "request":
                                        eZb(this.requestHandler, c);
                                        break;
                                    default:
                                        throw new __c.E(c);
                                }
                            }, a, b.Tg("bus"));
                            this.client = new FZb(a.KA, b.Tg("client"));
                            this.requestHandler = new GZb(a, b.Tg("requestHandler"))
                        }
                    },
                    HZb = class {
                        constructor(a, b, c) {
                            this.Oba = a;
                            this.KA = (d, e, f) => this.LZ.send({
                                type: "request",
                                requestId: d,
                                path: e,
                                payload: f
                            });
                            this.zmb = d => {
                                switch (d.type) {
                                    case "ack":
                                        this.Oba({
                                            type: "ack",
                                            requestId: d.requestId
                                        });
                                        break;
                                    case "error":
                                        this.Oba({
                                            type: "error",
                                            requestId: d.requestId,
                                            code: d.code,
                                            message: d.message
                                        });
                                        break;
                                    case "response":
                                        this.Oba({
                                            type: "response",
                                            requestId: d.requestId,
                                            Xm: d.payload
                                        });
                                        break;
                                    case "request":
                                        this.Oba({
                                            type: "request",
                                            requestId: d.requestId,
                                            path: d.path,
                                            Xm: d.payload
                                        });
                                        break;
                                    default:
                                        throw new __c.E(d);
                                }
                            };
                            this.LZ = new EZb({
                                Tob: this.zmb
                            }, b, c)
                        }
                    };
                var fZb = {
                    hDa: "null",
                    ZXa: "*"
                };
                var kZb = "canva-dev.com canva-dev.cn canva-staging.com canva-staging.cn canva.com canva.cn canva-apps.com canva-apps.cn canva-apps-dev.com canva-apps-dev.cn canva-apps-staging.com canva-apps-staging.cn".split(" ");
                var qZb = class {
                    constructor(a) {
                        this.H = a;
                        this.Nh = new Map
                    }
                };
                var rZb = new __c.F_({
                    id: "w:codelet",
                    uN: {
                        url: __c.E_("url", 0),
                        config: __c.E_("config", 1)
                    },
                    fz: ({
                        data: a
                    }) => ({
                        $a: __c.$P.create([{ ...__c.udb,
                            top: 0,
                            left: 0,
                            width: 510,
                            height: 191.25,
                            I: 800,
                            V: 300,
                            url: a.url
                        }])
                    })
                });
                var wZb = zZb(function() {
                    return vZb("div", {
                        style: {
                            width: "100%",
                            height: "100%",
                            display: "flex",
                            backgroundColor: "#fFfFfF",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: "FORM V2 Widget"
                    })
                });
                var tZb = {};
                __c.rQa = {
                    Pgb: function({
                        F7: a,
                        Apa: b,
                        H: c,
                        pbb: d
                    }) {
                        [sZb({
                            Apa: b,
                            H: c
                        }), xZb(), WYb()].forEach(e => a.aPa(e));
                        d && __webpack_require__.me(345045).then(() => __c.TYb).then(({
                            aab: e
                        }) => {
                            e.forEach(f => a.aPa(f))
                        })
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/d234253d4423c982.js.map