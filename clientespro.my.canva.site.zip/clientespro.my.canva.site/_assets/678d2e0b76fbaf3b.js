(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [92780], {

        /***/
        741114: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {}).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])