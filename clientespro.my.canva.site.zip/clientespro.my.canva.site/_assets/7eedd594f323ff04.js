(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [54501], {

        /***/
        933618: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                __c.Kib = {
                    config: {
                        language: "pt-BR",
                        uf: {
                            yMMMd: 'd "de" MMM "de" yyyy',
                            yMd: "dd/MM/yyyy",
                            yMMM: 'MMM "de" yyyy'
                        },
                        yf: "jan. fev. mar. abr. mai. jun. jul. ago. set. out. nov. dez.".split(" "),
                        zf: "janeiro fevereiro mar\u00e7o abril maio junho julho agosto setembro outubro novembro dezembro".split(" "),
                        Zf: "dd *[./\\s-] *mm *[./\\s-] *yy;dd *[./\\s-] *mm *[./\\s-] *yyyy;yyyy *[./\\s-] *mm *[./\\s-] *dd;dd *[./\\s-] *mm;mmm de yyyy;dd de mmm de yyyy".split(";")
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/7eedd594f323ff04.js.map