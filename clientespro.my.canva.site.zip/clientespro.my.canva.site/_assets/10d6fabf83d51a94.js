(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [3593], {

        /***/
        878415: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var OIb, PIb;
                OIb = function(a) {
                    return (b, c) => ({
                        kind: 2,
                        name: a,
                        B6a: b,
                        C6a: c
                    })
                };
                PIb = function(a) {
                    return b => ({
                        kind: 3,
                        name: a,
                        args: b
                    })
                };
                __c.QIb = OIb(1);
                __c.N_ = OIb(3);
                __c.RIb = PIb(5);
                __c.SIb = PIb(0);
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/10d6fabf83d51a94.js.map