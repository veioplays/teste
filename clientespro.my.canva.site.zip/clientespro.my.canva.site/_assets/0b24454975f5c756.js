(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [49222], {

        /***/
        78999: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(841629);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var E = __c.E;
                var C = __c.C;
                var SXb = function(a, b, c, d) {
                        c = new RXb(c, d);
                        C(a.count() === 1, "Only single widget root element is supported");
                        a = a.first();
                        C(a != null && a.type === "layout", `Unexpected widget root found: ${a===null||a===void 0?void 0:a.type}`);
                        c.qja(a, b)
                    },
                    UXb = function(a) {
                        return { ...__c.sdb,
                            ...F5,
                            top: 0,
                            left: 0,
                            width: a.width,
                            height: a.height,
                            viewBox: {
                                top: 0,
                                left: 0,
                                width: a.kja.width,
                                height: a.kja.height
                            },
                            xb: a.xb.map(TXb)
                        }
                    },
                    VXb = function(a) {
                        switch (a.RD) {
                            case 0:
                                var b = __c.vk.Kc().attrs({
                                    "font-size": a.fontSize,
                                    leading: a.lineHeight ? a.lineHeight *
                                        1E3 : void 0,
                                    "text-align": a.textAlign || "start",
                                    "font-weight": a.fontWeight,
                                    "font-family": a.fontFamily,
                                    "font-kerning": "normal",
                                    "font-feature-liga": "on",
                                    "font-feature-clig": "on",
                                    "font-feature-calt": "on",
                                    direction: a.direction
                                });
                                a.color && b.Cg("color", a.color);
                                b = b.Cc(a.text.endsWith("\n") ? a.text : `${a.text}\n`).build();
                                var c;
                                return { ...__c.XK,
                                    ...G5,
                                    ...F5,
                                    Ta: (c = a.Ta) !== null && c !== void 0 ? c : 0,
                                    text: b,
                                    oh: 2
                                };
                            case 1:
                                return b = a.text, { ...__c.XK,
                                    ...G5,
                                    ...F5,
                                    text: b,
                                    oh: 2
                                };
                            default:
                                throw new E(a);
                        }
                    },
                    K5 = function({
                        content: a,
                        fill: b,
                        border: c,
                        X: d
                    }) {
                        b = { ...__c.ddb,
                            fill: H5(b),
                            border: I5(c),
                            X: J5(d)
                        };
                        switch (a.type) {
                            case "shape":
                                return { ...b,
                                    element: UXb(a)
                                };
                            case "text":
                                return { ...b,
                                    element: VXb(a)
                                };
                            case "layout":
                                return { ...b,
                                    element: WXb(a)
                                };
                            default:
                                throw new E(a);
                        }
                    },
                    WXb = function({
                        cells: a,
                        border: b,
                        fill: c,
                        X: d,
                        gridTemplateColumns: e,
                        gridTemplateRows: f,
                        columnGap: g,
                        rowGap: h
                    }) {
                        return { ...__c.edb,
                            ...G5,
                            ...F5,
                            I: G5.width,
                            V: G5.height,
                            fill: H5(c),
                            border: I5(b),
                            direction: 1,
                            X: J5(d),
                            cells: new Map(a.map(k => [k.id, K5(k)])),
                            behavior: {
                                rules: [{
                                    qh: void 0,
                                    grid: {
                                        gridTemplateColumns: e,
                                        gridTemplateRows: f,
                                        columnGap: g !== null && g !== void 0 ? g : 0,
                                        rowGap: h !== null && h !== void 0 ? h : 0,
                                        Kh: XXb(a)
                                    }
                                }]
                            },
                            $e: void 0
                        }
                    },
                    XXb = function(a) {
                        return new Map(a.map(b => [b.id, YXb(b)]))
                    },
                    YXb = function(a) {
                        const b = a.placement.padding;
                        return { ...__c.vCa,
                            ...a.placement,
                            alignSelf: "center",
                            padding: { ...__c.gR,
                                ...(b != null ? typeof b === "number" ? {
                                    all: b
                                } : b : {})
                            }
                        }
                    },
                    I5 = function(a) {
                        var b;
                        const c = (b = a === null || a === void 0 ? void 0 : a.color) !== null && b !== void 0 ? b : "#000000";
                        var d;
                        return { ...__c.gE,
                            all: a ? { ...__c.XQ,
                                weight: (d = a.weight) !== null && d !== void 0 ? d : 1,
                                color: c,
                                jg: !0
                            } : void 0
                        }
                    },
                    J5 = function(a) {
                        return { ...__c.fR,
                            ...(a != null ? typeof a === "number" ? {
                                all: a
                            } : a : {})
                        }
                    },
                    TXb = function(a) {
                        return { ...__c.tdb,
                            ...a,
                            fill: H5(a.fill),
                            stroke: ZXb(a.stroke)
                        }
                    },
                    ZXb = function(a) {
                        return a ? { ...__c.XQ,
                            color: a.color,
                            weight: a.weight
                        } : void 0
                    },
                    H5 = function(a) {
                        var b;
                        const c = { ...__c.Kv,
                            Ta: (b = a === null || a === void 0 ? void 0 : a.Ta) !== null && b !== void 0 ? b : 0
                        };
                        switch (a === null || a === void 0 ? void 0 : a.type) {
                            case "color":
                                return { ...c,
                                    color: a.color
                                };
                            case "gradient":
                                return { ...c,
                                    mb: a.mb
                                };
                            case void 0:
                                return c;
                            default:
                                throw new E(a);
                        }
                    },
                    eYb = function(a, b) {
                        const c = new Map(b.cells.map(e => [e.id, e]));
                        $Xb(a.cells, c, (e, f) => {
                            let g = !1;
                            aYb(e.element, f.content, () => {
                                a.cells.delete(f.id);
                                a.cells.set(f.id, K5(f));
                                g = !0
                            });
                            g || (L5(e.fill, f.fill), bYb(e.border, f.border), cYb(e.X, f.X))
                        }, e => K5(e));
                        dYb(a.behavior, b, c);
                        L5(a.fill, b.fill);
                        cYb(a.X, b.X);
                        bYb(a.border, b.border);
                        var d;
                        a.Ta = (d = b.Ta) !== null && d !== void 0 ? d : 0
                    },
                    dYb = function(a, b, c) {
                        M5(a.rules, [b], d => {
                            fYb(d.grid.gridTemplateColumns, b.gridTemplateColumns) ||
                                (d.grid.gridTemplateColumns = b.gridTemplateColumns);
                            fYb(d.grid.gridTemplateRows, b.gridTemplateRows) || (d.grid.gridTemplateRows = b.gridTemplateRows);
                            var e;
                            d.grid.columnGap = (e = b.columnGap) !== null && e !== void 0 ? e : 0;
                            var f;
                            d.grid.rowGap = (f = b.rowGap) !== null && f !== void 0 ? f : 0;
                            $Xb(d.grid.Kh, c, (g, h) => {
                                const k = h.placement.padding,
                                    l = h.placement.gridColumnEnd,
                                    m = h.placement.gridRowStart,
                                    n = h.placement.gridRowEnd,
                                    p = h.placement.alignSelf;
                                g.gridColumnStart = h.placement.gridColumnStart;
                                g.gridColumnEnd = l;
                                g.gridRowStart = m;
                                g.gridRowEnd =
                                    n;
                                typeof k === "number" && g.padding.all !== k ? g.padding.all = k : typeof k !== "number" && (g.padding.Ba = k === null || k === void 0 ? void 0 : k.Ba, g.padding.Na = k === null || k === void 0 ? void 0 : k.Na, g.padding.Aa = k === null || k === void 0 ? void 0 : k.Aa, g.padding.Ua = k === null || k === void 0 ? void 0 : k.Ua);
                                g.alignSelf = p
                            }, g => YXb(g))
                        }, d => {
                            var e, f;
                            return {
                                qh: void 0,
                                grid: {
                                    gridTemplateColumns: b.gridTemplateColumns,
                                    gridTemplateRows: b.gridTemplateRows,
                                    columnGap: (e = b.columnGap) !== null && e !== void 0 ? e : 0,
                                    rowGap: (f = b.rowGap) !== null && f !== void 0 ? f : 0,
                                    Kh: XXb(d.cells)
                                }
                            }
                        })
                    },
                    gYb = function(a, b) {
                        M5(a.xb, b.xb, (e, f) => {
                            e.d = f.d;
                            L5(e.fill, f.fill);
                            e.stroke.ref && f.stroke ? (e = e.stroke.ref, f = f.stroke, e.color = f.color, e.weight = f.weight) : e.stroke.set(ZXb(f.stroke))
                        }, e => TXb(e));
                        const {
                            viewBox: c,
                            width: d
                        } = UXb(b);
                        a.width = d;
                        __c.Hu(a.viewBox).equals(__c.Hu(c)) || (a.viewBox = c)
                    },
                    aYb = function(a, b, c) {
                        switch (b.type) {
                            case "shape":
                                a.type === "shape" ? gYb(a, b) : c();
                                break;
                            case "text":
                                a.type === "text" && __c.vk.domain.Xb(__c.vk.ua(a.text), VXb(b).text) || c();
                                break;
                            case "layout":
                                a.type === "layout" ? eYb(a, b) : c();
                                break;
                            default:
                                throw new E(b);
                        }
                    },
                    $Xb = function(a, b, c, d) {
                        const e = new Set(a.keys());
                        for (const [f, g] of b)(b = a.get(f)) ? (e.delete(f), c(b, g)) : a.set(f, d(g));
                        e.forEach(f => a.delete(f))
                    },
                    M5 = function(a, b, c, d) {
                        const e = a.toArray();
                        for (let f = 0; f < Math.max(e.length, b.length); f++)
                            if (f < e.length && f < b.length) c(e[f], b[f]);
                            else if (f < e.length && f >= b.length) a.delete(e[f]);
                        else if (f >= e.length && f < b.length) {
                            const g = d(b[f]);
                            a.append(g)
                        }
                    },
                    L5 = function(a, b) {
                        switch (b === null || b === void 0 ? void 0 : b.type) {
                            case "color":
                                a.color = b.color;
                                a.mb.set(void 0);
                                var c;
                                a.Ta = (c = b.Ta) !== null && c !== void 0 ? c : 0;
                                break;
                            case "gradient":
                                if (a.mb.ref && __c.U2a.domain.Xb(a.mb.ref, b.mb)) break;
                                a.color = void 0;
                                a.mb.set(b.mb);
                                var d;
                                a.Ta = (d = b.Ta) !== null && d !== void 0 ? d : 0;
                                break;
                            default:
                                a.color = void 0, a.mb.set(void 0)
                        }
                    },
                    cYb = function(a, b) {
                        b = J5(b);
                        a.all = b.all;
                        a.KE = b.KE;
                        a.IE = b.IE;
                        a.JE = b.JE;
                        a.HE = b.HE
                    },
                    bYb = function(a, b) {
                        b = I5(b).all;
                        var c;
                        if (c = b) c = a.all.ref, c = !(c && b ? __c.hE.domain.Xb(__c.hE.ua(c), b) : !c && !b);
                        c && a.all.set(b)
                    },
                    fYb = function(a, b) {
                        return a.length === b.length && a.every(c => b.includes(c))
                    },
                    iYb = function(a, b, c, d) {
                        let e = a.PWa.get(b);
                        if (e) return e;
                        e = {
                            hz: new hYb(c.HA, b, d, c.jsa),
                            WGa: void 0,
                            GQa: void 0,
                            ESa: __c.XV.mode
                        };
                        a.PWa.set(b, e);
                        return e
                    },
                    kYb = function(a, b, c, d, e) {
                        var f, g;
                        e = iYb(a, c, b, e);
                        const h = e.hz,
                            k = e.GQa,
                            l = e.WGa,
                            m = e.ESa;
                        c = __c.YP.ua(c);
                        const n = ((f = (g = a.mB).qra) === null || f === void 0 ? void 0 : f.call(g, d)) || __c.XV;
                        h.vk === k && jYb.structural(c, l) && n.mode === m || (e.WGa = c, e.GQa = h.vk, e.ESa = n.mode, b = b.render(h, n), a.Dkb.update(d, b), SXb(d, b, (p, q) => a.qR.Bsa.set(p, q), (p, q, r) => a.qR.refs.set(p, {
                            ref: q,
                            key: r
                        })))
                    },
                    nYb = function(a, b) {
                        const c = [],
                            d = () => c.forEach(e => e());
                        c.push(a.rlb());
                        c.push(lYb(() => {
                            a: {
                                var e = new mYb;
                                for (const f of b)
                                    if (e.tR(f), e.nqa) {
                                        e = e.nqa;
                                        break a
                                    }
                                e = void 0
                            }
                            return e && (a.ec.isLoaded(e) || a.vta.has(e))
                        }, e => {
                            if (e) {
                                for (const f of b) C(f.type === "layout"), a.zl.rga(f);
                                d()
                            }
                        }));
                        return d
                    },
                    oYb = function(a, b) {
                        return {
                            fz: ({
                                ph: c
                            }) => {
                                var d;
                                const {
                                    hz: e
                                } = iYb(a.renderer, c, b, a.o3), f = __c.$P.create([]), g = [];
                                g.push(nYb(a.mdb, f));
                                g.push(lYb(() => {
                                    var k, l;
                                    return [(k = (l = a.mB).qra) === null || k === void 0 ? void 0 : k.call(l, f), __c.YP.ua(c),
                                        e.vk
                                    ]
                                }, () => {
                                    kYb(a.renderer, b, c, f, a.o3)
                                }, {
                                    fireImmediately: !0,
                                    equals: jYb.structural
                                }));
                                const h = (d = b.Wua) === null || d === void 0 ? void 0 : d.call(b, {
                                    hz: e
                                });
                                h && g.push(h);
                                return {
                                    $a: f,
                                    Av: () => {
                                        g.forEach(k => k())
                                    }
                                }
                            }
                        }
                    },
                    qYb = function(a, b) {
                        let c = a.Q8.get(b);
                        c || (c = pYb("weakKey"), a.Q8.set(b, c));
                        c.reportObserved()
                    },
                    N5 = __webpack_require__(519427),
                    jYb = N5.comparer,
                    rYb = N5.computed,
                    pYb = N5.createAtom,
                    O5 = N5.observable,
                    lYb = N5.reaction,
                    sYb = N5.runInAction;
                var tYb = class {
                    static A(a) {
                        __c.Q(a, {
                            $mb: O5.ref,
                            Beb: O5.ref
                        })
                    }
                    constructor() {
                        this.qra = (tYb.A(this), void 0)
                    }
                };
                var uYb = class {
                        constructor() {
                            this.sources = new WeakMap
                        }
                    },
                    hYb = class {
                        static A(a) {
                            __c.Q(a, {
                                Df: rYb
                            })
                        }
                        get HQa() {
                            var a = this.o3,
                                b = this.ph,
                                c = this.jsa;
                            let d = a.sources.get(b);
                            d || (d = O5.box(c), a.sources.set(b, d));
                            return d
                        }
                        get vk() {
                            return this.HQa.get()
                        }
                        get Df() {
                            return this.HA.$v({
                                type: "dict",
                                value: this.ph
                            })
                        }
                        hn(a) {
                            this.HQa.set(a instanceof Function ? { ...this.vk,
                                ...a()
                            } : { ...this.vk,
                                ...a
                            })
                        }
                        constructor(a, b, c, d) {
                            this.HA = a;
                            this.ph = b;
                            this.o3 = c;
                            this.jsa = d;
                            hYb.A(this)
                        }
                    };
                var RXb = class {
                    D7(a, b) {
                        this.FWa(a, b);
                        b.ref && this.yxa(a, b.ref, b.key)
                    }
                    wR(a, b) {
                        b.ref && this.yxa(a.text, b.ref, b.key)
                    }
                    JDa(a, b) {
                        switch (b.content.type) {
                            case "shape":
                                C(a.element.type === "shape");
                                this.D7(a.element, b.content);
                                break;
                            case "text":
                                C(a.element.type === "text");
                                this.wR(a.element, b.content);
                                break;
                            case "layout":
                                C(a.element.type === "layout");
                                this.qja(a.element, b.content);
                                break;
                            default:
                                throw new E(b.content);
                        }
                    }
                    qja(a, b) {
                        this.FWa(a, b);
                        b.ref && this.yxa(a, b.ref, b.key);
                        for (const [c, d] of a.cells) a = b.cells.find(e =>
                            e.id === c), C(!!d && !!a), this.JDa(d, a)
                    }
                    constructor(a, b) {
                        this.FWa = a;
                        this.yxa = b
                    }
                };
                var F5 = {
                        locked: !0,
                        El: {
                            q_: !1,
                            xX: !1
                        },
                        Ji: !0
                    },
                    G5 = {
                        top: 0,
                        left: 0,
                        width: 1,
                        height: 1
                    };
                var vYb = class {
                    constructor(a) {
                        this.zl = a;
                        this.update = (b, c) => {
                            M5(b, [c], (d, e) => {
                                switch (d.type) {
                                    case "layout":
                                        eYb(d, e);
                                        break;
                                    default:
                                        throw Error(`Not supported element type: ${d.type}`);
                                }
                            }, d => {
                                a: switch (d.type) {
                                    case "layout":
                                        d = { ...WXb(d),
                                            ...F5,
                                            width: d.minWidth,
                                            height: d.minHeight,
                                            I: d.minWidth,
                                            V: d.minHeight
                                        };
                                        break a;
                                    default:
                                        throw new E(d.type);
                                }
                                return d
                            });
                            for (const d of b) C(d.type === "layout"), d.width = c.minWidth, d.height = c.minHeight, d.I = c.minWidth, d.V = c.minHeight, c.direction && (d.direction = c.direction), this.zl.rga(d)
                        }
                    }
                };
                var wYb = class {
                    constructor(a, b, c) {
                        this.Dkb = a;
                        this.qR = b;
                        this.mB = c;
                        this.PWa = new WeakMap
                    }
                };
                var xYb = class {
                        static A(a) {
                            __c.Q(a, {
                                vta: O5.shallow
                            })
                        }
                        constructor(a, b) {
                            this.ec = a;
                            this.zl = b;
                            this.vta = (xYb.A(this), new Set);
                            this.yqa = new Set;
                            this.rlb = () => {
                                this.iba || (this.iba = __c.Gga(this.ec).subscribe(d => {
                                    sYb(() => {
                                        this.vta.add(d.id)
                                    })
                                }));
                                const c = Symbol();
                                this.yqa.add(c);
                                return () => {
                                    this.yqa.delete(c);
                                    this.yqa.size <= 0 && this.iba && (this.iba.unsubscribe(), this.iba = void 0)
                                }
                            }
                        }
                    },
                    mYb = class extends __c.FC {
                        tR(a, b) {
                            this.nqa || super.tR(a, b)
                        }
                        wR(a) {
                            this.nqa = (a = a.text.Cz("font-family")["font-family"].values().next().value) &&
                                __c.fs(a).id
                        }
                    };
                var yYb = !1,
                    zYb = class {
                        register(a, b) {
                            this.UE.has(a) || (this.UE.set(a, b), yYb || (__c.ZP.set(a, oYb(this, b)), yYb = !0))
                        }
                        get(a) {
                            return this.UE.get(a)
                        }
                        constructor(a, b, c, d, e) {
                            this.renderer = a;
                            this.o3 = b;
                            this.mB = c;
                            this.ec = d;
                            this.zl = e;
                            this.UE = new Map;
                            this.mdb = new xYb(this.ec, this.zl)
                        }
                    };
                var AYb = class {
                    delete(a) {
                        var b;
                        const c = this.map.delete(a);
                        c && ((b = this.Q8.get(a)) === null || b === void 0 || b.reportChanged());
                        return c
                    }
                    get(a) {
                        qYb(this, a);
                        return this.map.get(a)
                    }
                    has(a) {
                        qYb(this, a);
                        return this.map.has(a)
                    }
                    set(a, b) {
                        if (!this.map.has(a) || this.map.get(a) !== b) {
                            var c;
                            this.map.set(a, b);
                            (c = this.Q8.get(a)) === null || c === void 0 || c.reportChanged()
                        }
                        return this
                    }
                    constructor() {
                        this.Q8 = new WeakMap;
                        this.map = new WeakMap
                    }
                };
                var BYb = class {
                        constructor() {
                            this.Bsa = new AYb;
                            this.refs = new AYb
                        }
                    },
                    CYb = class {
                        getContext(a) {
                            return this.qR.refs.get(a)
                        }
                        ZN(a) {
                            return this.qR.Bsa.get(a)
                        }
                        constructor(a, b, c) {
                            this.qR = a;
                            this.o3 = b;
                            this.renderer = c
                        }
                    };
                __c.nQa = {
                    Rgb: function(a) {
                        const b = new tYb,
                            c = new BYb,
                            d = new wYb(new vYb(a.zl), c, b),
                            e = new uYb;
                        a = new zYb(d, e, b, a.ec, a.zl);
                        return {
                            mB: b,
                            POb: new CYb(c, e, d),
                            F7: a,
                            qR: c
                        }
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/0b24454975f5c756.js.map