(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [35024], {

        /***/
        738083: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var SH = __c.SH;
                var Jc = __c.Jc;
                var Q = __c.Q;
                var Hu = __c.Hu;
                var P = __c.P;
                var vx = __c.vx;
                var ju = __c.ju;
                var D = __c.D;
                var E = __c.E;
                var V4 = function(a, b) {
                        switch (b.reference.type) {
                            case 0:
                                const c = a.dT(b.reference.Di);
                                a = a.KW(b.reference.Mi);
                                return c != null && a != null;
                            case 1:
                                return a.dT(b.reference.Di) != null;
                            case 2:
                                return a.KW(b.reference.Mi) != null;
                            case 3:
                                return !1;
                            default:
                                throw new E(b.reference);
                        }
                    },
                    yWb = function(a, b, c) {
                        switch (c.type) {
                            case "invalid":
                                return !1;
                            case "canonical":
                                if (c.la.length > 0) return !1;
                                a = a.LG(c.QZ.slice(1).trim());
                                return a.result !== "success" ? !1 : __c.XD(new __c.$D, a.SI).filter(d => {
                                    switch (d.type) {
                                        case 0:
                                            return V4(b, d);
                                        case 1:
                                            return V4(b,
                                                d.start) && V4(b, d.end);
                                        default:
                                            throw new E(d);
                                    }
                                }).length > 0;
                            default:
                                throw new E(c);
                        }
                    },
                    zWb = function(a, b, c, d) {
                        const e = [];
                        for (const k of c)
                            for (const l of d) {
                                c = k.xa;
                                var f = l.column,
                                    g = a.layout.cells.get(c, f);
                                if (!g || (k.boundary === "start" ? g.span.bc === c : g.span.bd === c))
                                    if (c = b.get(`${f.id}:${c.id}`), c = k.boundary === "start" ? c === null || c === void 0 ? void 0 : c.Ba : c === null || c === void 0 ? void 0 : c.Na) {
                                        g = e[e.length - 1];
                                        f = (f = a.layout.cols.next(f)) ? {
                                            column: f,
                                            boundary: "start"
                                        } : {
                                            column: D(a.layout.cols.last()),
                                            boundary: "end"
                                        };
                                        var h;
                                        if (h = g) h = g.Qpa, h = h.column === l.column && h.boundary === l.boundary;
                                        h && (h = g.oXa, h = h.xa === k.xa && h.boundary === k.boundary);
                                        h && g.color === c.color && g.weight === c.weight && g.yc === c.yc && g.yc === 0 ? g.Qpa = f : e.push({
                                            oXa: k,
                                            gsb: l,
                                            Qpa: f,
                                            color: c.color,
                                            weight: c.weight,
                                            yc: c.yc
                                        })
                                    }
                            }
                        return e
                    },
                    AWb = function(a, b, c, d, e) {
                        const f = [];
                        for (const l of d)
                            for (const m of c) {
                                var g = m.xa,
                                    h = l.column;
                                d = a.layout.cells.get(g, h);
                                if (!d || (l.boundary === "start" ? d.span.Wb === h : d.span.Qc === h))
                                    if (d = b.get(`${h.id}:${g.id}`), (d = l.boundary === "start" ? d === null ||
                                            d === void 0 ? void 0 : d.Aa : d === null || d === void 0 ? void 0 : d.Ua) && (l.boundary !== "start" || e(g, h) !== 1)) {
                                        h = f[f.length - 1];
                                        g = (g = a.layout.rows.next(g)) ? {
                                            xa: g,
                                            boundary: "start"
                                        } : {
                                            xa: D(a.layout.rows.last()),
                                            boundary: "end"
                                        };
                                        var k;
                                        if (k = h) k = h.HIa, k = k.column === l.column && k.boundary === l.boundary;
                                        k && (k = h.Tpa, k = k.xa === m.xa && k.boundary === m.boundary);
                                        k && h.color === d.color && h.weight === d.weight && h.yc === d.yc && h.yc === 0 ? h.Tpa = g : f.push({
                                            HIa: l,
                                            tsb: m,
                                            Tpa: g,
                                            color: d.color,
                                            weight: d.weight,
                                            yc: d.yc
                                        })
                                    }
                            }
                        return f
                    },
                    BWb = function(a, b, c, d, e) {
                        const f =
                            a.fZa.K9a(c, b.layout.rows.last(), b.layout.cols.last());
                        a = (q, r) => {
                            const t = f.get(q) || 0,
                                w = f.get(r) || 0;
                            return t <= w ? q : r
                        };
                        const g = new Map;
                        if (d.length === 0 || e.length === 0) return g;
                        var h = [],
                            k = b.layout.cols.fc(e[0].column);
                        k && h.push({
                            column: k,
                            boundary: "start"
                        });
                        h.push(...e);
                        (e = b.layout.cols.next(e[e.length - 1].column)) && h.push({
                            column: e,
                            boundary: "start"
                        });
                        e = [];
                        (k = b.layout.rows.fc(d[0].xa)) && e.push({
                            xa: k,
                            boundary: "start"
                        });
                        e.push(...d);
                        (d = b.layout.rows.next(d[d.length - 1].xa)) && e.push({
                            xa: d,
                            boundary: "start"
                        });
                        for (const q of h) {
                            h = (d = q.boundary === "start" ? q.column : void 0) ? b.layout.cols.fc(d) : b.layout.cols.last();
                            for (const r of e) {
                                var l = r.boundary === "start" ? r.xa : void 0;
                                k = l ? b.layout.rows.fc(l) : b.layout.rows.last();
                                var m = d && l && c.get(`${d.id}:${l.id}`),
                                    n = d && k && c.get(`${d.id}:${k.id}`);
                                l = h && l && c.get(`${h.id}:${l.id}`);
                                var p = h && k && c.get(`${h.id}:${k.id}`);
                                k = q.boundary === "end" ? l === null || l === void 0 ? void 0 : l.Ua : m === null || m === void 0 ? void 0 : m.Aa;
                                m = r.boundary === "end" ? n === null || n === void 0 ? void 0 : n.Na : m === null || m === void 0 ?
                                    void 0 : m.Ba;
                                n = q.boundary === "end" ? p === null || p === void 0 ? void 0 : p.Ua : n === null || n === void 0 ? void 0 : n.Aa;
                                l = r.boundary === "end" ? p === null || p === void 0 ? void 0 : p.Na : l === null || l === void 0 ? void 0 : l.Ba;
                                p = __c.DDa({
                                    Ba: n,
                                    Na: k,
                                    Aa: l,
                                    Ua: m
                                }, a);
                                let t;
                                switch (p) {
                                    case "blockStart":
                                        t = n;
                                        break;
                                    case "blockEnd":
                                        t = k;
                                        break;
                                    case "inlineStart":
                                        t = l;
                                        break;
                                    case "inlineEnd":
                                        t = m;
                                        break;
                                    default:
                                        t = void 0
                                }
                                const {
                                    height: w,
                                    width: u
                                } = (t === null || t === void 0 ? void 0 : t.yc) === 1 ? {
                                    height: t.weight,
                                    width: t.weight
                                } : {
                                    height: Math.max((l === null || l === void 0 ? void 0 :
                                        l.weight) || 0, (m === null || m === void 0 ? void 0 : m.weight) || 0),
                                    width: Math.max((n === null || n === void 0 ? void 0 : n.weight) || 0, (k === null || k === void 0 ? void 0 : k.weight) || 0)
                                };
                                g.set(W4(q, r), __c.AE(p, w / 2, u / 2))
                            }
                        }
                        return g
                    },
                    CWb = function(a, b, c, d, e, f) {
                        if (d.length === 0 || e.length === 0) return [];
                        const g = zWb(b, c, d, e);
                        f = AWb(b, c, d, e, f);
                        const h = BWb(a, b, c, d, e),
                            k = a.Jeb(b),
                            l = a.feb(b),
                            m = b.direction === "rtl";
                        a = g.map(n => {
                            var p, q, r = n.gsb,
                                t = n.Qpa,
                                w = n.oXa;
                            const u = n.color,
                                x = n.weight;
                            n = n.yc;
                            const y = m ? -1 : 1,
                                A = (p = h.get(W4(r, w))) === null || p === void 0 ?
                                void 0 : p.Ua;
                            p = (q = h.get(W4(t, w))) === null || q === void 0 ? void 0 : q.Aa;
                            if (A != null && p != null) {
                                q = D(k.get(w.xa));
                                var z = D(l.get(r.column));
                                r = D(l.get(t.column));
                                w = w.boundary === "start" ? q.start : q.end;
                                q = z.start;
                                t = t.boundary === "start" ? r.start : r.end;
                                return {
                                    color: u,
                                    weight: x,
                                    yc: n,
                                    p1: new ju(q + A * y, w),
                                    p2: new ju(t + p * y, w),
                                    ...__c.FE((t - q) * y, n * x, A)
                                }
                            }
                        }).filter(__c.wb);
                        return [...f.map(n => {
                            var p, q, r = n.HIa,
                                t = n.tsb,
                                w = n.Tpa;
                            const u = n.color,
                                x = n.weight;
                            n = n.yc;
                            const y = (p = h.get(W4(r, t))) === null || p === void 0 ? void 0 : p.Na;
                            p = (q = h.get(W4(r,
                                w))) === null || q === void 0 ? void 0 : q.Ba;
                            if (y != null && p != null) {
                                q = D(l.get(r.column));
                                var A = D(k.get(t.xa));
                                t = D(k.get(w.xa));
                                r = r.boundary === "start" ? q.start : q.end;
                                q = A.start;
                                w = w.boundary === "start" ? t.start : t.end;
                                return {
                                    color: u,
                                    weight: x,
                                    yc: n,
                                    p1: new ju(r, q + y),
                                    p2: new ju(r, w + p),
                                    ...__c.FE(w - q, n * x, y)
                                }
                            }
                        }).filter(__c.wb), ...a]
                    },
                    DWb = function(a) {
                        const b = [];
                        a = a.filter(c => c.weight !== 0 && c.color != null);
                        a = __c.Bd(a, c => c.weight);
                        a = Array.from(a.entries()).sort(([c], [d]) => c - d);
                        for (const [c, d] of a) {
                            a = __c.Bd(d, e => `${e.Tk}_${e.Uk}`);
                            for (const [, e] of a) {
                                const {
                                    Uk: f,
                                    Tk: g
                                } = e[0];
                                a = __c.Bd(e, h => h.color);
                                for (const [h, k] of a) b.push({
                                    weight: c,
                                    color: h,
                                    lines: k,
                                    Tk: g,
                                    Uk: f
                                })
                            }
                        }
                        return b
                    },
                    EWb = function(a, b, c, d) {
                        var e = __c.psb;
                        const f = b.get().flatMap(k => a.layout.rows.last() === k ? [{
                                xa: k,
                                boundary: "start"
                            }, {
                                xa: k,
                                boundary: "end"
                            }] : [{
                                xa: k,
                                boundary: "start"
                            }]),
                            g = c.get().flatMap(k => a.layout.cols.last() === k ? [{
                                column: k,
                                boundary: "start"
                            }, {
                                column: k,
                                boundary: "end"
                            }] : [{
                                column: k,
                                boundary: "start"
                            }]),
                            h = new Map;
                        for (const k of b.get())
                            for (const l of c.get()) b = l && k ?
                                e.fZa.Epb(a, l, k) : void 0, b && h.set(`${l.id}:${k.id}`, b);
                        c = CWb(e, a, h, f, g, d);
                        return DWb(c)
                    },
                    X4 = function() {
                        const [a] = (0, __c.fc)(() => vx());
                        return a
                    },
                    FWb = function(a) {
                        switch (a) {
                            case 2:
                                return P("ibdecg");
                            case 7:
                                return P("446quA");
                            case 5:
                                return P("j1fbqg");
                            case 1:
                                return P("O5i4AQ");
                            case 6:
                                return P("C0VHsg");
                            case 4:
                                return P("9ND0kg");
                            case -1:
                                return P("RWqnLA");
                            case 9:
                                return P("nQR/7w");
                            case -2:
                                return P("P23rtA");
                            case 3:
                                return P("+IXmVg");
                            default:
                                throw new E(a);
                        }
                    },
                    GWb = function(a, b, c) {
                        const d = [a];
                        for (; a != null &&
                            a !== b;)(a = c.next(a)) && d.push(a);
                        return d
                    },
                    HWb = function(a) {
                        const b = a.direction === "rtl" ? -(0, __c.ssb)(a) / 2 : -(0, __c.qsb)(a) / 2,
                            c = -(0, __c.rsb)(a) / 2,
                            d = a.width + (0, __c.qsb)(a) / 2 + (0, __c.ssb)(a) / 2;
                        a = a.height + (0, __c.rsb)(a) / 2 + (0, __c.tsb)(a) / 2;
                        return Hu({
                            top: 0,
                            left: 0,
                            width: d,
                            height: a,
                            rotation: 0
                        }).translate(b, c)
                    },
                    IWb = function(a) {
                        return b => ({
                            type: "react",
                            node: (0, __c.N)(a, { ...b
                            })
                        })
                    },
                    KWb = function(a) {
                        var b;
                        const c = a.MA;
                        var d = a.content;
                        const e = a.context;
                        a = a.qq;
                        __c.C((d === null || d === void 0 ? void 0 : (b = d.Dg) === null || b ===
                            void 0 ? void 0 : b.type) === "formula");
                        b = d.Yk;
                        const f = {
                            type: "dom",
                            render: h => h.innerText = ""
                        };
                        switch (b.type) {
                            case 9:
                                d = f;
                                break;
                            case 6:
                                var g;
                                d = (g = c.Fka) === null || g === void 0 ? void 0 : g.call(c, {
                                    content: __c.le(__c.g4a, { ...__c.fdb,
                                        value: b.value
                                    }),
                                    context: e,
                                    qq: a
                                });
                                break;
                            case 1:
                            case 3:
                            case 4:
                            case 2:
                            case 7:
                            case 8:
                                d = JWb(c, e, d.AB, d.Yk.type);
                                break;
                            case 0:
                                d = {
                                    type: "react",
                                    node: Y4(__c.TR, {
                                        label: FWb(b.error),
                                        children: Y4(__c.yy, {
                                            width: "full",
                                            display: "flex",
                                            justifyContent: "center",
                                            children: Y4(__c.Mzb, {
                                                tone: "critical"
                                            })
                                        })
                                    })
                                };
                                break;
                            default:
                                throw new E(b);
                        }
                        return d !== null && d !== void 0 ? d : f
                    },
                    JWb = function(a, b, c, d) {
                        var e;
                        return (e = a.Ika) === null || e === void 0 ? void 0 : e.call(a, {
                            context: b,
                            value: c,
                            valueType: d
                        })
                    },
                    NWb = function(a) {
                        const b = a.MA,
                            c = a.Xf,
                            d = a.btb,
                            e = a.Ab;
                        b.Ika = f => __c.JKa({ ...f,
                            Ab: e
                        });
                        b.zFa = f => KWb({ ...f,
                            MA: b
                        });
                        b.Fka = IWb(LWb({
                            Xf: c,
                            TR: void 0
                        }));
                        b.BFa = MWb(d, e);
                        b.CFa = IWb(f => Y4(Z4, { ...f,
                            Ab: e
                        }))
                    },
                    OWb = function({
                        label: a,
                        cb: b,
                        width: c,
                        height: d,
                        scale: e,
                        QIa: f
                    }) {
                        return Y4("div", {
                            style: {
                                width: c,
                                height: d,
                                transform: `scale(${e})`
                            },
                            className: "bx74uQ",
                            children: $4(__c.vy, {
                                className: a5("ivlMMQ", b5(f)),
                                size: "small",
                                alignment: "center",
                                children: [b && Y4(b, {
                                    size: "small"
                                }), a]
                            })
                        })
                    },
                    b5 = function(a) {
                        return {
                            _2BX0vg: a === "primary-default",
                            JfW_Cg: a === "primary-low",
                            isMgNg: a === "primary-active",
                            xwWDeQ: a === "secondary-default",
                            w0EyUQ: a === "secondary-low",
                            _8p5AIA: a === "secondary-active"
                        }
                    },
                    QWb = function({
                        Fd: a,
                        XNa: b,
                        scale: c,
                        $p: d,
                        aq: e,
                        L2a: f
                    }) {
                        const g = c5(() => {
                                const m = d === null || d === void 0 ? void 0 : d.get();
                                if (m != null && m.length !== 0) return new __c.oE(m)
                            }, [d]),
                            h = e(1),
                            k = e(c),
                            l = {
                                ssE9Tg: !a,
                                OkifGQ: a
                            };
                        return Y4(__c.wy, {
                            er: "light",
                            light: "light",
                            tu: "light",
                            dark: "light",
                            children: m => Y4("div", {
                                className: a5("ze9QCQ", l, m.className),
                                style: {
                                    width: k,
                                    height: k
                                },
                                children: Y4("div", {
                                    style: {
                                        width: h,
                                        height: h,
                                        transform: `scale(${c})`
                                    },
                                    className: a5("N7J3UA", l),
                                    ref: g === null || g === void 0 ? void 0 : g.jn,
                                    children: Y4(__c.YR, {
                                        className: a5("m8CFdg", l, {
                                            G6wL4w: f,
                                            W_E0wA: b
                                        }),
                                        ariaLabel: P("ruWN9A"),
                                        children: Y4(PWb, {
                                            size: "tiny"
                                        })
                                    })
                                })
                            })
                        })
                    },
                    SWb = function() {
                        const a = new RWb,
                            b = new __c.xS,
                            c = d5(f => {
                                const {
                                    scale: g = 1,
                                    SNa: h,
                                    size: k =
                                        "small",
                                    L2a: l = !0
                                } = f, m = e5(n => a.aq({
                                    scale: n,
                                    size: k,
                                    nua: h
                                }), [k, h]);
                                return Y4(QWb, { ...f,
                                    scale: h ? Math.max(g, h) : g,
                                    Fd: f.sheet.direction === "rtl",
                                    XNa: f.selection != null && a.Qhb(f.sheet, f.selection),
                                    aq: m,
                                    L2a: l
                                })
                            }),
                            d = d5(f => {
                                const {
                                    scale: g = 1,
                                    SNa: h,
                                    size: k = "small",
                                    sheet: l,
                                    selection: m,
                                    kqb: n
                                } = f, p = e5(u => a.aq({
                                    scale: u,
                                    size: k,
                                    nua: h
                                }), [k, h]), q = h ? Math.max(g, h) : g, r = e5(u => m != null && a.rya(m).has(u), [m]), t = e5(u => m != null && a.Jfb(l, m).has(u), [l, m]), w = e5(u => {
                                    const x = n != null && l.layout.cols.cf(u, n.Wb) >= 0 && l.layout.cols.cf(u, n.Qc) <=
                                        0;
                                    return r(u) ? x ? "secondary-active" : "primary-active" : t(u) ? x ? "secondary-low" : "primary-low" : x ? "secondary-default" : "primary-default"
                                }, [l, n, t, r]);
                                return Y4(f5, { ...f,
                                    rd: g,
                                    Nd: q,
                                    aq: p,
                                    GF: w,
                                    wG: b
                                })
                            }),
                            e = d5(f => {
                                const {
                                    scale: g = 1,
                                    SNa: h,
                                    size: k = "small",
                                    sheet: l,
                                    selection: m,
                                    kqb: n
                                } = f, p = e5(u => a.aq({
                                    scale: u,
                                    size: k,
                                    nua: h
                                }), [k, h]), q = h ? Math.max(g, h) : g, r = e5(u => m != null && a.tya(m).has(u), [m]), t = e5(u => m != null && a.Kfb(l, m).has(u), [l, m]), w = e5(u => {
                                    const x = n != null && l.layout.rows.cf(u, n.bc) >= 0 && l.layout.rows.cf(u, n.bd) <= 0;
                                    return r(u) ?
                                        x ? "secondary-active" : "primary-active" : t(u) ? x ? "secondary-low" : "primary-low" : x ? "secondary-default" : "primary-default"
                                }, [l, n, t, r]);
                                return Y4(g5, { ...f,
                                    rd: q,
                                    Nd: g,
                                    aq: p,
                                    GF: w,
                                    wG: b
                                })
                            });
                        return {
                            l3a: c,
                            k3a: d,
                            m3a: e
                        }
                    },
                    TWb = function(a) {
                        const b = a.Oq,
                            c = () => null;
                        return __c.Fx(d => Y4(h5, { ...d,
                            Oq: b,
                            Yh: c
                        }))
                    },
                    UWb = function({
                        sheet: a,
                        Y: b,
                        range: c,
                        je: d
                    }) {
                        i5(() => j5(() => {
                            if (d.current != null) {
                                var e, f = (e = b === null || b === void 0 ? void 0 : b.get()) !== null && e !== void 0 ? e : 1;
                                e = a.direction === "rtl";
                                e = c ? a.Aa(c.Wb) * f * (e ? 1 : -1) : 0;
                                var g = c ? -a.Ba(c.bc) *
                                    f : 0;
                                d.current.style.transform = `translate(${e}px, ${g}px)`;
                                d.current.style.width = `${a.width*f}px`;
                                d.current.style.height = `${a.height*f}px`
                            }
                        }), [a, c, d, b])
                    },
                    XWb = function({
                        onScroll: a
                    }) {
                        const b = new VWb(a);
                        return {
                            zD: b,
                            rka: d5(c => Y4(WWb, {
                                sheet: c.sheet,
                                zD: b,
                                children: c.children
                            }))
                        }
                    },
                    $Wb = function(a) {
                        const b = a.Oq,
                            c = a.Ef,
                            d = a.gZa,
                            e = ({
                                children: k
                            }) => k,
                            {
                                zD: f,
                                rka: g
                            } = XWb({
                                onScroll: a.onScroll
                            });
                        class h extends YWb {
                            get wM() {
                                const k = this.props.qa.Iu;
                                switch (k) {
                                    case "screen":
                                        return g;
                                    case "print":
                                        return e;
                                    default:
                                        throw new E(k);
                                }
                            }
                            componentDidMount() {
                                d.QYa(this.props.item, {
                                    $b: this.props.$b,
                                    qa: this.props.qa
                                })
                            }
                            componentWillUnmount() {
                                d.B8a(this.props.item, {
                                    $b: this.props.$b,
                                    qa: this.props.qa
                                })
                            }
                            render() {
                                d.QYa(this.props.item, {
                                    $b: this.props.$b,
                                    qa: this.props.qa
                                });
                                return Y4(ZWb, { ...this.props,
                                    Y: this.Y,
                                    Oq: b,
                                    wM: this.wM,
                                    Yh: this.Yh,
                                    gZa: d,
                                    zD: f
                                })
                            }
                            constructor(...k) {
                                super(...k);
                                this.Y = k5(() => {
                                    const l = this.props.item;
                                    var m = this.props.qa,
                                        n = m.Iu;
                                    m = m.zoom;
                                    switch (n) {
                                        case "screen":
                                            return m;
                                        case "print":
                                            n = d.Neb(l);
                                            if (!n) return 1;
                                            ({
                                                width: n
                                            } = new __c.PE(l,
                                                n.$b, {
                                                    zoom: m
                                                }));
                                            return n / l.config.width;
                                        default:
                                            throw new E(n);
                                    }
                                });
                                this.Yh = d5(l => Y4("div", {
                                    className: "wKvivQ",
                                    children: Y4(__c.RKa, { ...this.props,
                                        ...l,
                                        Ef: c
                                    })
                                }))
                            }
                        }
                        return {
                            f5a: h,
                            zD: f
                        }
                    },
                    aXb = function(a, b) {
                        if (b != null && b.Wb != null && b.bc != null && b.Qc != null && b.bd != null) {
                            var c = a.Aa(b.Wb),
                                d = a.Ba(b.bc),
                                e = a.Aa(b.Qc) + b.Qc.width - c;
                            a = a.Ba(b.bd) + b.bd.height - d;
                            return Hu({
                                top: d,
                                left: c,
                                width: e,
                                height: a
                            })
                        }
                    },
                    cXb = function(a) {
                        const b = a.Oq,
                            c = () => null;
                        return d => Y4(bXb, { ...d,
                            Oq: b,
                            Yh: c
                        })
                    },
                    gXb = function(a) {
                        const b = {
                                transform: "translate(-1000px, -1000px) scale(0)"
                            },
                            c = {
                                fIa: b,
                                Iw: b,
                                Pa: {},
                                Go: {}
                            },
                            d = l5(() => a.UA.style || c, h => {
                                var k;
                                Object.assign(a.G9.style, h.fIa);
                                Object.assign(a.PM.style, h.Iw);
                                Object.assign(a.QE.style, h.Pa);
                                Object.assign(a.VE.style, h.Go);
                                h = h === null || h === void 0 ? void 0 : (k = h.Pa) === null || k === void 0 ? void 0 : k.textDecoration;
                                a.QE.classList.toggle("OQx3PQ", h === "underline");
                                a.QE.classList.toggle("_99ezUA", h === "line-through");
                                a.QE.classList.toggle("kppAqQ", h === "underline line-through")
                            }, {
                                fireImmediately: !0,
                                equals: dXb
                            }),
                            e = l5(() => a.gta, h => {
                                a.QE.classList.toggle("_84KvRA", !h);
                                a.G9.classList.toggle("_84KvRA", !h);
                                a.PM.classList.toggle("TL_RLA", !h)
                            }, {
                                fireImmediately: !0
                            }),
                            f = l5(() => a.renderer, h => {
                                a.s$ && (h === null || h === void 0 ? void 0 : h.type) !== "react" ? (a.s$ = void 0, a.L4.remove()) : a.VE.innerHTML = "";
                                switch (h === null || h === void 0 ? void 0 : h.type) {
                                    case "react":
                                        a.s$ = eXb(h.node, a.L4);
                                        a.VE.appendChild(a.L4);
                                        break;
                                    case "dom":
                                        h.render(a.VE);
                                        break;
                                    case void 0:
                                        break;
                                    default:
                                        throw new E(h);
                                }
                                a.dva()
                            }, {
                                fireImmediately: !0
                            }),
                            g = fXb ? l5(() => a.Dra, h => {
                                a.QE.classList.toggle("qxD1GA", h)
                            }, {
                                fireImmediately: !0
                            }) :
                            void 0;
                        return () => {
                            d();
                            e();
                            f();
                            g === null || g === void 0 || g()
                        }
                    },
                    dXb = function(a, b) {
                        return JSON.stringify(a) === JSON.stringify(b)
                    },
                    iXb = function(a) {
                        const b = a.NA,
                            c = a.ID,
                            d = a.eE,
                            e = a.d2a,
                            f = a.Oo,
                            g = new hXb(c),
                            h = (k, l) => f ? yWb(f, k, l) : !1;
                        return k => Y4(m5, { ...k,
                            GO: h,
                            eE: d,
                            ID: c,
                            NA: b,
                            Fsa: g,
                            d2a: e === null || e === void 0 ? void 0 : e.get()
                        })
                    },
                    W4 = (a, b) => `${a.column.id}-${a.boundary}:${b.xa.id}-${b.boundary}`,
                    LWb = ({
                        Xf: a,
                        TR: b
                    }) => c => (0, __c.N)(__c.vsb, { ...c,
                        Xf: a,
                        TR: b
                    }),
                    n5 = __webpack_require__(443763),
                    jXb = n5.Fragment,
                    Y4 = n5.jsx,
                    $4 = n5.jsxs;
                var kXb = __webpack_require__(358579).Z;
                var lXb = __webpack_require__,
                    mXb = lXb(993864),
                    a5 = lXb.n_x(mXb)();
                var d5 = __webpack_require__(446474).Pi;
                var o5 = __webpack_require__(875604),
                    p5 = o5.Component,
                    YWb = o5.PureComponent,
                    e5 = o5.useCallback,
                    i5 = o5.useEffect,
                    nXb = o5.useLayoutEffect,
                    c5 = o5.useMemo,
                    q5 = o5.useRef,
                    oXb = o5.useState;
                var r5 = __webpack_require__(635872),
                    s5 = r5.Om,
                    pXb = r5.kq,
                    qXb = r5.YN;
                var t5 = __webpack_require__(519427),
                    u5 = t5.action,
                    j5 = t5.autorun,
                    v5 = t5.comparer,
                    k5 = t5.computed,
                    rXb = t5.createAtom,
                    w5 = t5.observable,
                    l5 = t5.reaction,
                    sXb = t5.untracked;
                var x5 = __webpack_require__(46239).gn;
                var eXb = __webpack_require__(36281).createPortal;
                var tXb = d5(a => {
                        var b, c, d = a.sheet.direction === "rtl";
                        d = {
                            H2wykw: !d,
                            UweldA: d
                        };
                        const [e] = oXb(() => vx()), f = {
                            get: e5(() => {
                                var g;
                                const h = e === null || e === void 0 ? void 0 : (g = e.current) === null || g === void 0 ? void 0 : g.getBoundingClientRect();
                                var k, l;
                                g = {
                                    top: 0,
                                    left: 0,
                                    width: (k = h === null || h === void 0 ? void 0 : h.width) !== null && k !== void 0 ? k : 0,
                                    height: (l = h === null || h === void 0 ? void 0 : h.height) !== null && l !== void 0 ? l : 0
                                };
                                return Hu(g)
                            }, [e])
                        };
                        return $4("div", {
                            className: a5("nMvVqA", d),
                            children: [$4("div", {
                                ref: kXb(a.je, e),
                                className: "_0YOFPg",
                                children: [Y4(a.Oq, { ...a,
                                    viewport: f
                                }), Y4("div", {
                                    className: a5("Gdl7fQ", d),
                                    children: (c = a.UEa) === null || c === void 0 ? void 0 : (b = c.get()) === null || b === void 0 ? void 0 : b.map((g, h) => Y4(g, {}, h))
                                })]
                            }), a.FFb === "visible" && $4(jXb, {
                                children: [Y4("div", {
                                    className: a5("_32sKQw", d),
                                    children: Y4(a.c5a, { ...a
                                    })
                                }), Y4("div", {
                                    className: a5("xdIsTQ", d),
                                    children: Y4(a.g5a, { ...a
                                    })
                                }), Y4("div", {
                                    className: a5("rsTRSA", d),
                                    children: Y4(a.e5a, { ...a
                                    })
                                })]
                            })]
                        })
                    }),
                    uXb = d5(a => {
                        a = a.content;
                        __c.v(a.type === "text2" || a.type === "text3");
                        switch (a.type) {
                            case "text2":
                                return a.value.aa;
                            case "text3":
                                return __c.hr.ua(a.value).cells.aa();
                            default:
                                throw new E(a);
                        }
                    });
                var MWb = (a, b) => __c.vKa((c, d) => {
                        const e = c.content;
                        c = c.context;
                        if (e.value.isEmpty)
                            for (; d.lastChild;) d.lastChild.remove();
                        else({
                            uh: c
                        } = __c.pg(__c.Yg, c.attrs)), c === "wrap" && (d = d.appendChild(document.createElement("div")), d.className = "dt4Dlg"), a.render({
                            container: d,
                            text: e.value,
                            Qa: void 0,
                            writingMode: 1,
                            Ld: "start",
                            ah: vXb(e, c),
                            Ab: b
                        })
                    }),
                    vXb = s5((a, b) => {
                        if (b === "wrap") return [];
                        a = a.value.aa.split("\n").map(c => c.length + 1);
                        a.pop();
                        return a
                    }, {
                        equals: v5.structural
                    });
                var Z4 = class extends p5 {
                    static A(a) {
                        Q(a, {
                            uh: k5
                        })
                    }
                    get uh() {
                        return __c.pg(__c.Yg, this.props.context.attrs).uh
                    }
                    render() {
                        var a = this.props.content;
                        const b = this.props.context;
                        if (a.value.isEmpty) return null;
                        a = Y4(this.props.Yh, {
                            content: a,
                            xa: b.container.xa,
                            col: b.container.column,
                            uh: this.uh
                        });
                        return this.uh === "wrap" ? Y4("div", {
                            className: "dt4Dlg",
                            children: a
                        }) : a
                    }
                    constructor(...a) {
                        super(...a);
                        Z4.A(this)
                    }
                };
                Z4 = x5([Jc], Z4);
                var RWb = class {
                    aq({
                        size: a,
                        scale: b,
                        nua: c
                    }) {
                        b = c ? Math.max(c, b) : b;
                        return a === "large" ? __c.cW * b : __c.Fyb * b
                    }
                    constructor() {
                        this.Qhb = s5((a, b) => {
                            var c, d;
                            b = b.get();
                            return b != null && a.layout.rows.count() === (((c = b.rows) === null || c === void 0 ? void 0 : c.size) || 0) && a.layout.cols.count() === (((d = b.columns) === null || d === void 0 ? void 0 : d.size) || 0)
                        });
                        this.rya = pXb(a => {
                            var b;
                            return new Set(((b = a.get()) === null || b === void 0 ? void 0 : b.columns) || [])
                        }, {
                            equals: __c.Vr
                        });
                        this.tya = pXb(a => {
                            var b;
                            return new Set(((b = a.get()) === null || b === void 0 ?
                                void 0 : b.rows) || [])
                        }, {
                            equals: __c.Vr
                        });
                        this.Jfb = s5((a, b) => {
                            var {
                                cells: c
                            } = b.get() || {};
                            if (!c) return new Set;
                            if (this.tya(b).size > 0) return new Set(a.layout.cols);
                            b = this.rya(b);
                            const d = new Set;
                            for (const e of c) {
                                c = a.layout.cells.get(e.xa, e.column);
                                for (const f of GWb(c ? c.span.Wb : e.column, c ? c.span.Qc : e.column, a.layout.cols))(b.size === 0 || b.has(f)) && d.add(f)
                            }
                            return d
                        }, {
                            equals: __c.Vr
                        });
                        this.Kfb = s5((a, b) => {
                            var {
                                cells: c
                            } = b.get() || {};
                            if (!c) return new Set;
                            if (this.rya(b).size > 0) return new Set(a.layout.rows);
                            b = this.tya(b);
                            const d = new Set;
                            for (const e of c) {
                                c = a.layout.cells.get(e.xa, e.column);
                                for (const f of GWb(c ? c.span.bc : e.xa, c ? c.span.bd : e.xa, a.layout.rows))(b.size === 0 || b.has(f)) && d.add(f)
                            }
                            return d
                        }, {
                            equals: __c.Vr
                        })
                    }
                };
                var wXb = parseInt("4px", 10) || 4,
                    f5 = class extends p5 {
                        static A(a) {
                            Q(a, {
                                Fd: k5,
                                Br: k5,
                                f6: k5
                            })
                        }
                        get Fd() {
                            return this.props.sheet.direction === "rtl"
                        }
                        get Br() {
                            var a;
                            const b = (a = this.props.$p) === null || a === void 0 ? void 0 : a.get();
                            if (b != null && b.length !== 0) return new __c.oE(b)
                        }
                        get f6() {
                            var a, b, c;
                            return (b = (c = this.props).Zqa) === null || b === void 0 ? void 0 : (a = b.call(c)) === null || a === void 0 ? void 0 : a.get()
                        }
                        render() {
                            return Y4(__c.wy, {
                                er: "light",
                                light: "light",
                                tu: "light",
                                dark: "light",
                                children: this.Q8a
                            })
                        }
                        constructor(...a) {
                            super(...a);
                            this.onMouseMove = (f5.A(this), u5(b => {
                                const {
                                    onMouseMove: c,
                                    sheet: d,
                                    rd: e = 1
                                } = this.props;
                                c === null || c === void 0 || c(b, d, "column", e)
                            }));
                            this.onMouseLeave = u5(b => {
                                var c, d;
                                (c = (d = this.props).onMouseLeave) === null || c === void 0 || c.call(d, b)
                            });
                            this.NWa = (b, c, d) => {
                                const {
                                    sheet: e,
                                    aq: f,
                                    GF: g,
                                    PFb: h,
                                    rd: k = 1,
                                    Nd: l = 1
                                } = this.props, m = {
                                    jNbTIg: !this.Fd,
                                    gtA7Dw: this.Fd
                                }, n = (d === null || d === void 0 ? 0 : d.sticky) ? this.Fd ? {
                                    right: 0
                                } : {
                                    left: 0
                                } : void 0;
                                var p;
                                const q = (d === null || d === void 0 ? 0 : d.sticky) ? (p = this.f6) !== null && p !== void 0 ? p : n : void 0;
                                let r = -1;
                                return $4("div", {
                                    style: q,
                                    className: a5("Vt2_4w", m, {
                                        Tn3nUw: d === null || d === void 0 ? void 0 : d.sticky
                                    }),
                                    onMouseMove: this.onMouseMove,
                                    onMouseLeave: this.onMouseLeave,
                                    children: [e.layout.cols.map(t => {
                                        var w;
                                        r++;
                                        if (!(b && e.layout.cols.cf(t, b) < 0 || c && e.layout.cols.cf(t, c) > 0)) return Y4(xXb, {
                                            col: t,
                                            label: __c.SA(r),
                                            cb: h === null || h === void 0 ? void 0 : (w = h.get()) === null || w === void 0 ? void 0 : w.get(t),
                                            aq: f,
                                            GF: g,
                                            rd: k,
                                            Nd: l
                                        }, t.id)
                                    }), (d === null || d === void 0 ? void 0 : d.sticky) && Y4("div", {
                                        style: {
                                            width: wXb * k
                                        },
                                        className: a5("HBvlug", "ru3tFQ",
                                            m)
                                    })]
                                })
                            };
                            this.Q8a = b => {
                                var c;
                                const d = this.props.sheet,
                                    e = d.view.freeze.DI ? d.layout.Wd.get(d.view.freeze.DI) : void 0,
                                    f = {
                                        jNbTIg: !this.Fd,
                                        gtA7Dw: this.Fd
                                    };
                                return $4("div", {
                                    ref: (c = this.Br) === null || c === void 0 ? void 0 : c.jn,
                                    className: a5("xhBZaw", f, b.className),
                                    children: [e && this.NWa(void 0, e, {
                                        sticky: !0
                                    }), this.NWa(e ? d.cols.next(e) : void 0)]
                                })
                            }
                        }
                    };
                f5 = x5([Jc], f5);
                var g5 = class extends p5 {
                    static A(a) {
                        Q(a, {
                            Fd: k5,
                            Br: k5,
                            f6: k5
                        })
                    }
                    get Fd() {
                        return this.props.sheet.direction === "rtl"
                    }
                    get Br() {
                        var a;
                        const b = (a = this.props.$p) === null || a === void 0 ? void 0 : a.get();
                        if (b != null && b.length !== 0) return new __c.oE(b)
                    }
                    get f6() {
                        var a, b, c;
                        return (b = (c = this.props).Zqa) === null || b === void 0 ? void 0 : (a = b.call(c)) === null || a === void 0 ? void 0 : a.get()
                    }
                    render() {
                        return Y4(__c.wy, {
                            er: "light",
                            light: "light",
                            tu: "light",
                            dark: "light",
                            children: this.Upb
                        })
                    }
                    constructor(...a) {
                        super(...a);
                        this.onMouseMove = (g5.A(this),
                            u5(b => {
                                const {
                                    onMouseMove: c,
                                    sheet: d,
                                    Nd: e = 1
                                } = this.props;
                                c === null || c === void 0 || c(b, d, "row", e)
                            }));
                        this.onMouseLeave = u5(b => {
                            var c, d;
                            (c = (d = this.props).onMouseLeave) === null || c === void 0 || c.call(d, b)
                        });
                        this.RWa = (b, c, d) => {
                            const {
                                sheet: e,
                                aq: f,
                                GF: g,
                                rd: h = 1,
                                Nd: k = 1
                            } = this.props, l = {
                                jNbTIg: !this.Fd,
                                gtA7Dw: this.Fd
                            }, m = (d === null || d === void 0 ? 0 : d.sticky) ? {
                                top: 0
                            } : void 0;
                            var n;
                            const p = (d === null || d === void 0 ? 0 : d.sticky) ? (n = this.f6) !== null && n !== void 0 ? n : m : void 0;
                            let q = -1;
                            return $4("div", {
                                style: p,
                                className: a5("_93roJg", l, {
                                    Tn3nUw: d ===
                                        null || d === void 0 ? void 0 : d.sticky
                                }),
                                onMouseMove: this.onMouseMove,
                                onMouseLeave: this.onMouseLeave,
                                children: [e.rows.map(r => {
                                    q++;
                                    if (!(b && e.rows.cf(r, b) < 0 || c && e.rows.cf(r, c) > 0)) return Y4(yXb, {
                                        xa: r,
                                        label: `${q+1}`,
                                        GF: g,
                                        aq: f,
                                        rd: h,
                                        Nd: k
                                    }, r.id)
                                }), (d === null || d === void 0 ? void 0 : d.sticky) && Y4("div", {
                                    style: {
                                        height: wXb * k
                                    },
                                    className: a5("HBvlug", "koz2Hg")
                                })]
                            })
                        };
                        this.Upb = b => {
                            var c;
                            const d = this.props.sheet,
                                e = d.view.freeze.LW ? d.layout.we.get(d.view.freeze.LW) : void 0,
                                f = {
                                    jNbTIg: !this.Fd,
                                    gtA7Dw: this.Fd
                                };
                            return $4("div", {
                                ref: (c =
                                    this.Br) === null || c === void 0 ? void 0 : c.jn,
                                className: a5("An9VeA", f, b.className),
                                children: [e && this.RWa(void 0, e, {
                                    sticky: !0
                                }), this.RWa(e ? d.rows.next(e) : void 0)]
                            })
                        }
                    }
                };
                g5 = x5([Jc], g5);
                var xXb = d5(a => {
                        const b = a.label,
                            c = a.cb,
                            d = a.col,
                            e = a.GF,
                            f = a.aq,
                            g = a.rd;
                        a = a.Nd;
                        const h = f(a),
                            k = qXb(() => e(d));
                        return Y4("div", {
                            className: a5("_83Rssw", "d2uLIA", b5(k)),
                            style: {
                                width: d.width * g,
                                height: h
                            },
                            children: Y4(OWb, {
                                label: b,
                                cb: c,
                                width: d.width,
                                height: f(1),
                                scale: a,
                                QIa: k
                            })
                        })
                    }),
                    yXb = d5(a => {
                        const b = a.label,
                            c = a.xa,
                            d = a.aq,
                            e = a.GF,
                            f = a.rd;
                        a = a.Nd;
                        const g = d(f),
                            h = qXb(() => e(c));
                        return Y4("div", {
                            className: a5("_83Rssw", "JhBzyw", b5(h)),
                            style: {
                                width: g,
                                height: c.height * a
                            },
                            children: Y4(OWb, {
                                label: b,
                                width: d(1),
                                height: c.height,
                                scale: f,
                                QIa: h
                            })
                        })
                    });
                var zXb = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><circle stroke="currentColor" cx="6" cy="6" r="5.5"/></svg>';
                var AXb = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle stroke="currentColor" cx="12" cy="12" r="9.25" stroke-width="1.5"/></svg>';
                var PWb = __c.MR({
                    zp: zXb,
                    medium: AXb
                });
                var h5 = class extends p5 {
                    static A(a) {
                        Q(a, {
                            He: k5.struct
                        })
                    }
                    render() {
                        const a = this.props.element;
                        return Y4(this.props.Oq, {
                            sheet: a.na.config,
                            container: a,
                            l9: "visible",
                            $p: this.props.$p,
                            Vu: this.props.Vu,
                            Xu: this.props.Xu,
                            Y: this.props.Y,
                            He: this.He,
                            Yh: this.props.Yh,
                            $H: void 0
                        })
                    }
                    get He() {
                        return __c.$A(this.props.element.na.Wa, this.props.Ye)
                    }
                    constructor(...a) {
                        super(...a);
                        h5.A(this)
                    }
                };
                h5 = x5([Jc], h5);
                var BXb = class {
                    constructor() {
                        this.kha = new WeakMap;
                        this.Neb = a => this.kha.get(a);
                        this.QYa = (a, b) => {
                            this.kha.set(a, b)
                        };
                        this.B8a = (a, b) => {
                            const c = this.kha.get(a);
                            c && c.qa === b.qa && c.$b === b.$b && this.kha.delete(a)
                        }
                    }
                };
                var y5 = parseInt("4px", 10) || 4,
                    CXb = d5(({
                        sheet: a,
                        Y: b,
                        range: c,
                        Vw: d,
                        Ww: e
                    }) => {
                        if (c != null && (d || e)) {
                            var f;
                            b = (f = b === null || b === void 0 ? void 0 : b.get()) !== null && f !== void 0 ? f : 1;
                            f = a.direction === "rtl";
                            var g = {
                                ZJ0G6w: !f,
                                dOI_jA: f
                            };
                            if (d && e) return d = a.Ba(c.bd) + c.bd.height, a = a.Aa(c.Qc) + c.Qc.width, Y4("div", {
                                style: {
                                    top: d * b,
                                    width: a * b,
                                    height: y5 * b
                                },
                                className: a5("aX8dhQ", "VGcLng")
                            });
                            if (d) return c = a.Aa(c.Qc) + c.Qc.width, Y4("div", {
                                style: {
                                    width: y5 * b,
                                    height: a.height * b,
                                    ...(f ? {
                                        right: c * b
                                    } : {
                                        left: c * b
                                    })
                                },
                                className: a5("aX8dhQ", "gl1RPg",
                                    g)
                            });
                            if (e) return c = a.Ba(c.bd) + c.bd.height, Y4("div", {
                                style: {
                                    top: c * b,
                                    width: a.width * b,
                                    height: y5 * b
                                },
                                className: a5("aX8dhQ", "VGcLng")
                            })
                        }
                    });
                var z5 = ({
                        sheet: a,
                        range: b,
                        Y: c,
                        children: d
                    }) => {
                        const e = X4();
                        UWb({
                            sheet: a,
                            Y: c,
                            range: b,
                            je: e
                        });
                        return Y4("div", {
                            ref: e,
                            className: a5("nstn2A", a.direction === "rtl" ? "NgnL2Q" : "f8jAGQ"),
                            children: d
                        })
                    },
                    DXb = ({
                        sheet: a,
                        range: b,
                        Y: c,
                        children: d
                    }) => {
                        const e = X4();
                        UWb({
                            sheet: a,
                            Y: c,
                            range: b,
                            je: e
                        });
                        a = a.direction === "rtl" ? "NgnL2Q" : "f8jAGQ";
                        return Y4("div", {
                            className: a5("nstn2A", a, "_9sodyg"),
                            children: Y4("div", {
                                ref: e,
                                className: a5("nstn2A", a),
                                children: d
                            })
                        })
                    };
                var WWb = d5(({
                        sheet: a,
                        children: b,
                        zD: c
                    }) => {
                        const d = e5(f => {
                                c.Pya(a, f)
                            }, [c, a]),
                            e = e5(f => {
                                f != null ? c.BD.set(a, f) : c.BD.delete(a)
                            }, [c, a]);
                        return Y4(__c.Fub, {
                            direction: a.config.direction === "rtl" ? "rtl" : "ltr",
                            onScroll: d,
                            Lv: e,
                            children: b
                        })
                    }),
                    VWb = class {
                        Pya(a, b) {
                            this.onScroll && this.onScroll(a);
                            this.r5.set(a, b)
                        }
                        constructor(a) {
                            this.onScroll = a;
                            this.BD = new WeakMap;
                            this.r5 = w5.map(new Map, {
                                deep: !1
                            });
                            this.scrollTo = u5((b, c) => {
                                b = this.BD.get(b);
                                b === null || b === void 0 || b.scrollTo({
                                    left: Math.floor(c)
                                })
                            })
                        }
                    };
                var ZWb = d5(a => {
                    const b = a.item,
                        c = a.$p,
                        d = a.ng,
                        e = a.measureRef,
                        f = a.Y,
                        g = a.UOa,
                        h = a.$b,
                        k = a.Vu,
                        l = a.Xu,
                        m = a.Oq,
                        n = a.wM,
                        p = a.Yh,
                        q = a.Ye,
                        r = a.zD;
                    a = c5(() => __c.$A(b.Wa, q), [b, q]);
                    const t = c5(() => d5(({
                            sheet: y,
                            range: A,
                            Vw: z,
                            Ww: B
                        }) => Y4(z5, {
                            sheet: y,
                            range: A,
                            Y: f,
                            children: Y4(CXb, {
                                sheet: y,
                                Y: f,
                                range: A,
                                Vw: z,
                                Ww: B
                            })
                        })), [f]),
                        w = HWb(b.config),
                        u = f.get(),
                        x = Math.min(w.width * u, h.width);
                    i5(() => j5(() => {
                        var y = b.config.view.freeze.DI ? b.config.layout.Wd.get(b.config.view.freeze.DI) : void 0;
                        if (y != null)
                            if (b.config.Aa(y) + y.width > x) {
                                if (y = r.BD.get(b)) y.style.overflowX =
                                    "hidden"
                            } else if (y = r.BD.get(b)) y.style.overflowX = "scroll"
                    }), [b, h.width, r, u, x]);
                    return Y4("div", {
                        ref: e,
                        className: "E8r86A",
                        style: {
                            width: x
                        },
                        children: Y4(n, {
                            sheet: b,
                            children: Y4("div", {
                                ref: g,
                                className: "cXTiJA",
                                style: {
                                    width: w.width * u,
                                    height: w.height * u
                                },
                                children: Y4("div", {
                                    className: "W1ir5A",
                                    children: Y4(m, {
                                        container: d.hk(b),
                                        sheet: b.config,
                                        l9: "visible",
                                        $p: c,
                                        Y: f,
                                        Vu: k,
                                        Xu: l,
                                        He: a,
                                        Yh: p,
                                        $H: t
                                    })
                                })
                            })
                        })
                    })
                });
                var EXb = d5(({
                    page: a,
                    range: b,
                    rD: c
                }) => {
                    const d = aXb(a.sheet, b);
                    return Y4("div", {
                        className: "Gi9pfA",
                        children: a.elements.map((e, f) => d == null ? c(e, f) : __c.Fu(Hu(e)).fq(d) && c(e, f))
                    })
                });
                var FXb = new __c.xS,
                    A5 = a => __c.cW * a,
                    GXb = () => "primary-default",
                    bXb = d5(({
                        container: a,
                        $p: b,
                        Vu: c,
                        Xu: d,
                        l1: e,
                        Y: f,
                        viewport: g,
                        Hrb: h,
                        Oq: k,
                        Yh: l,
                        rD: m,
                        Cga: n,
                        Txb: p,
                        Gwb: q,
                        Fwb: r
                    }) => {
                        const t = a.page,
                            w = c5(() => d5(({
                                sheet: u,
                                range: x,
                                Vw: y,
                                Ww: A
                            }) => $4(jXb, {
                                children: [Y4(z5, {
                                    sheet: t.sheet,
                                    range: x,
                                    Y: f,
                                    children: Y4(CXb, {
                                        sheet: u,
                                        Y: f,
                                        range: x,
                                        Vw: y,
                                        Ww: A
                                    })
                                }), $4(DXb, {
                                    sheet: t.sheet,
                                    range: x,
                                    Y: f,
                                    children: [p && Y4(p, {}), m && Y4(EXb, {
                                        page: t,
                                        rD: m,
                                        range: x
                                    }), r && Y4(r, {}), n && n()]
                                }), q && x && Y4(z5, {
                                    sheet: t.sheet,
                                    range: x,
                                    Y: f,
                                    children: Y4(q, {
                                        range: x
                                    })
                                })]
                            })), [t, f, p, m, r, n, q]);
                        return h ? Y4(HXb, {
                            container: a,
                            viewport: g,
                            Y: f,
                            $p: b,
                            Vu: c,
                            Xu: d,
                            Oq: k,
                            Yh: l,
                            $H: w
                        }) : Y4(k, {
                            sheet: t.sheet,
                            container: a,
                            l9: "hidden",
                            $p: b,
                            Vu: c,
                            Xu: d,
                            l1: e,
                            Y: f,
                            viewport: g,
                            Yh: l,
                            $H: w
                        })
                    }),
                    HXb = d5(a => {
                        const b = a.container,
                            c = a.Y,
                            d = a.viewport,
                            e = a.$p,
                            f = a.Vu,
                            g = a.Xu,
                            h = a.Oq,
                            k = a.Yh;
                        a = a.$H;
                        const l = b.page,
                            m = l.sheet.direction === "rtl",
                            n = q5(null),
                            p = q5(null),
                            q = q5(null);
                        i5(() => {
                            const y = B5({
                                sheet: l.sheet,
                                Nha: !0,
                                Oha: !0,
                                Y: c,
                                viewport: d
                            });
                            return l5(() => y === null || y === void 0 ? void 0 : y.get(), A => {
                                const z = n.current;
                                if (A && z) {
                                    var B =
                                        l.sheet.direction === "rtl",
                                        G;
                                    z.style.position = (G = A.position) !== null && G !== void 0 ? G : "sticky";
                                    var H;
                                    z.style.top = (H = A.top) !== null && H !== void 0 ? H : "0px";
                                    var K, I;
                                    B ? z.style.right = (K = A.right) !== null && K !== void 0 ? K : "0px" : z.style.left = (I = A.left) !== null && I !== void 0 ? I : "0px";
                                    var M;
                                    z.style.transform = (M = A.transform) !== null && M !== void 0 ? M : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        i5(() => {
                            const y = B5({
                                sheet: l.sheet,
                                Nha: !1,
                                Oha: !0,
                                Y: c,
                                viewport: d
                            });
                            return l5(() => y === null || y === void 0 ? void 0 : y.get(), A => {
                                const z = q.current;
                                if (A && z) {
                                    var B;
                                    z.style.position =
                                        (B = A.position) !== null && B !== void 0 ? B : "sticky";
                                    var G;
                                    z.style.top = (G = A.top) !== null && G !== void 0 ? G : "0px";
                                    var H;
                                    z.style.transform = (H = A.transform) !== null && H !== void 0 ? H : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        i5(() => {
                            const y = B5({
                                sheet: l.sheet,
                                Nha: !0,
                                Oha: !1,
                                Y: c,
                                viewport: d
                            });
                            return l5(() => y === null || y === void 0 ? void 0 : y.get(), A => {
                                const z = p.current;
                                if (A && z) {
                                    var B = l.sheet.direction === "rtl",
                                        G;
                                    z.style.position = (G = A.position) !== null && G !== void 0 ? G : "sticky";
                                    var H, K;
                                    B ? z.style.right = (H = A.right) !== null && H !== void 0 ? H : "0px" : z.style.left =
                                        (K = A.left) !== null && K !== void 0 ? K : "0px";
                                    var I;
                                    z.style.transform = (I = A.transform) !== null && I !== void 0 ? I : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        const r = e5((y, A, z) => B5({
                                sheet: y,
                                Nha: A,
                                Oha: z,
                                Y: c,
                                viewport: d
                            }), [c, d]),
                            t = c5(() => r ? () => r(l.sheet, !0, !1) : void 0, [r, l.sheet]),
                            w = c5(() => r ? () => r(l.sheet, !1, !0) : void 0, [r, l.sheet]);
                        var u;
                        const x = (u = c === null || c === void 0 ? void 0 : c.get()) !== null && u !== void 0 ? u : 1;
                        return $4("div", {
                            className: a5("OsKKIQ", "cbOp6Q"),
                            children: [Y4("div", {
                                className: "VDFv_A",
                                children: Y4(h, {
                                    sheet: l.sheet,
                                    container: b,
                                    l9: "hidden",
                                    $p: e,
                                    Vu: f,
                                    Xu: g,
                                    l1: r,
                                    Y: c,
                                    viewport: d,
                                    Yh: k,
                                    $H: a
                                })
                            }), Y4("div", {
                                ref: n,
                                className: "_688KWg",
                                children: Y4(QWb, {
                                    Fd: m,
                                    XNa: !1,
                                    aq: A5,
                                    scale: x
                                })
                            }), Y4("div", {
                                ref: q,
                                className: "m0cT1w",
                                children: Y4(f5, {
                                    sheet: l.sheet,
                                    rd: x,
                                    Nd: x,
                                    aq: A5,
                                    GF: GXb,
                                    wG: FXb,
                                    Zqa: t
                                })
                            }), Y4("div", {
                                ref: p,
                                className: "zm537g",
                                children: Y4(g5, {
                                    sheet: l.sheet,
                                    rd: x,
                                    Nd: x,
                                    aq: A5,
                                    GF: GXb,
                                    wG: FXb,
                                    Zqa: w
                                })
                            })]
                        })
                    }),
                    B5 = ({
                        sheet: a,
                        Nha: b,
                        Oha: c,
                        Y: d,
                        viewport: e
                    }) => k5(() => {
                        var f = e === null || e === void 0 ? void 0 : __c.Pu(e.get()),
                            g;
                        const h = (g = d === null || d === void 0 ? void 0 : d.get()) !== null &&
                            g !== void 0 ? g : 1;
                        if (!f) return {};
                        g = {};
                        f = new ju(f.left, f.top);
                        const k = a.direction === "rtl";
                        g.position = "relative";
                        c && (g.top = "0px");
                        b && (k ? g.right = "0px" : g.left = "0px");
                        g.transform = `translate(${b?f.x*h:0}px, ${c?f.y*h:0}px)`;
                        return g
                    });
                var hXb = class {
                    constructor(a) {
                        this.ID = a;
                        this.m8a = __c.kU;
                        this.ueb = s5((b, c, d, e) => {
                            d = d.get();
                            const f = new WeakMap;
                            for (let t = 0; t < d.length; t++) {
                                var g = d[t],
                                    h = this.oeb(b, c, g);
                                if (h) {
                                    switch (h) {
                                        case "start":
                                        case "justify":
                                            var k = d[t + 1];
                                            if (k == null || !SH(b, c, k)) continue;
                                            break;
                                        case "center":
                                            k = d[t + 1];
                                            if (k == null || !SH(b, c, k)) continue;
                                            k = d[t - 1];
                                            if (k == null || !SH(b, c, k)) continue;
                                            break;
                                        case "end":
                                            k = d[t - 1];
                                            if (k == null || !SH(b, c, k)) continue;
                                            break;
                                        default:
                                            throw new E(h);
                                    }
                                    if (k = e(c, g)) {
                                        var l = k.width + (h === "center" ? 0 : this.m8a);
                                        if (!(g.width >
                                                l)) {
                                            switch (h) {
                                                case "start":
                                                case "justify":
                                                    h = b.Aa(g);
                                                    k = h + l;
                                                    break;
                                                case "center":
                                                    k = b.Aa(g) + g.width / 2;
                                                    h = k - l / 2;
                                                    k += l / 2;
                                                    break;
                                                case "end":
                                                    k = b.Aa(g) + g.width;
                                                    h = k - l;
                                                    break;
                                                default:
                                                    throw new E(h);
                                            }
                                            for (l = d.indexOf(g); l >= 0; l--) {
                                                var m = d[l],
                                                    n = l - 1 < 0 || SH(b, c, d[l - 1]),
                                                    p;
                                                if (p = m === g || SH(b, c, m)) {
                                                    p = h;
                                                    var q = k,
                                                        r = b.Aa(m);
                                                    p = p < r && r < q
                                                }
                                                if (p && n) f.set(m, 1);
                                                else break
                                            }
                                            for (g = d.indexOf(g) + 1; g < d.length; g++) {
                                                l = d[g];
                                                if (m = SH(b, c, l)) m = h, n = k, p = b.Aa(l), m = m < p && p < n;
                                                if (m) f.set(l, 1);
                                                else break
                                            }
                                        }
                                    }
                                }
                            }
                            return f
                        });
                        this.oeb = (b, c, d) => {
                            var e, f;
                            const g =
                                b.layout.cells.get(c, d);
                            if (g && (g.ref.content.ref || g.ref.Ha.ref) && g.span.bc === g.span.bd && g.span.Wb === g.span.Qc) {
                                var h = this.ID.Xw(b, c, d);
                                b = this.ID.Tqa(b, c, d, __c.Zg({
                                    uh: void 0,
                                    textAlign: void 0
                                }));
                                var {
                                    uh: k,
                                    textAlign: l
                                } = __c.pg(__c.Yg, b);
                                if (k === "overflow") return __c.wKa(l, (e = g.ref.content.ref) === null || e === void 0 ? void 0 : e.type, (f = g.ref.Ha.ref) === null || f === void 0 ? void 0 : f.type, h ? () => h.Yk.type : void 0)
                            }
                        }
                    }
                };
                var IXb = d5(function(a) {
                    const b = a.sheet;
                    var c = a.wj;
                    const d = a.ivb,
                        e = a.Y,
                        f = a.Fsa,
                        g = a.deb;
                    a = a.overflow;
                    const h = X4();
                    nXb(() => j5(() => {
                        const p = D(h.current);
                        var q;
                        const r = (q = e === null || e === void 0 ? void 0 : e.get()) !== null && q !== void 0 ? q : 1;
                        q = b.height;
                        p.style.width = `${b.width*r}px`;
                        p.style.height = `${q*r}px`
                    }), [h, e, b]);
                    const k = e5(p => f.ueb(b, p, d, g), [f, b, d, g]);
                    var l = e5((p, q) => {
                        var r, t;
                        return (t = (r = k(p)) === null || r === void 0 ? void 0 : r.get(q)) !== null && t !== void 0 ? t : 0
                    }, [k]);
                    c = EWb(b, c, d, l);
                    l = b.width;
                    const m = b.height,
                        n = b.direction ===
                        "rtl";
                    return Y4("svg", {
                        ref: h,
                        role: "presentation",
                        className: a5("c6a1eQ", {
                            H_CtIQ: !n,
                            _8_56PQ: n,
                            _3NnFzw: a === "visible",
                            JMH1ng: a === "hidden"
                        }),
                        viewBox: `0 0 ${l} ${m}`,
                        strokeLinecap: "butt",
                        strokeLinejoin: "miter",
                        children: c.map(({
                            lines: p,
                            color: q,
                            weight: r,
                            Tk: t,
                            Uk: w
                        }) => Y4("path", {
                            stroke: q,
                            strokeDasharray: t,
                            strokeDashoffset: w,
                            strokeWidth: r,
                            d: p.map(({
                                p1: u,
                                p2: x
                            }) => `M ${u.x} ${u.y} L ${x.x} ${x.y}`).join(" ")
                        }, `${q}-${r}-${t}-${w}`))
                    })
                });
                var JXb = class {
                    get size() {
                        return this.wha
                    }
                    get([a, b]) {
                        return (a = this.eG.get(a)) ? a.get(b) : void 0
                    }
                    has([a, b]) {
                        a = this.eG.get(a);
                        return a == null ? !1 : a.has(b)
                    }
                    set([a, b], c) {
                        let d = this.eG.get(a);
                        d == null && (d = new Map, this.eG.set(a, d));
                        d.set(b, c);
                        this.wha++;
                        return this
                    }
                    clear() {
                        this.eG.clear();
                        this.wha = 0
                    }
                    delete([a, b]) {
                        const c = this.eG.get(a);
                        if (c == null || !c.delete(b)) return !1;
                        this.wha--;
                        c.size === 0 && this.eG.delete(a);
                        return !0
                    }
                    forEach(a) {
                        for (const [b, c] of this.eG)
                            for (const [d, e] of c) a([b, d], e)
                    }*[Symbol.iterator]() {
                        for (const [a,
                                b
                            ] of this.eG)
                            for (const [c, d] of b) yield [
                                [a, c], d
                            ]
                    }
                    constructor() {
                        this.wha = 0;
                        this.eG = new Map
                    }
                };
                var fXb = __c.Qw("285688d5", !1),
                    D5 = class extends p5 {
                        render() {
                            const {
                                sba: a,
                                ...b
                            } = this.props, c = this.props.sheet;
                            return $4("div", {
                                ref: this.iZa,
                                className: a5("ZTz_iA", c.direction === "ltr" ? "TA4X7w" : "WvuqMw"),
                                children: [(a === null || a === void 0 ? void 0 : a.wHa) && Y4(C5, { ...b,
                                    sheet: c,
                                    range: a.wHa.range,
                                    Vw: !0,
                                    Ww: !0,
                                    className: "_0C8M3w"
                                }), (a === null || a === void 0 ? void 0 : a.n2a) && Y4(C5, { ...b,
                                    sheet: c,
                                    range: a.n2a.range,
                                    Vw: !1,
                                    Ww: !0,
                                    className: "_7n44yg"
                                }), (a === null || a === void 0 ? void 0 : a.$Na) && Y4(C5, { ...b,
                                    sheet: c,
                                    range: a.$Na.range,
                                    Vw: !0,
                                    Ww: !1,
                                    className: "fF5r6w"
                                }), (a === null || a === void 0 ? void 0 : a.a1a) && Y4(C5, { ...b,
                                    sheet: c,
                                    range: a.a1a.range,
                                    Vw: !1,
                                    Ww: !1,
                                    className: "llILYw"
                                })]
                            })
                        }
                        componentDidMount() {
                            const a = j5(() => {
                                var b = this.props,
                                    c = b.Y;
                                b = b.sheet;
                                const d = this.iZa.current;
                                d && (c = c ? c.get() : 1, d.style.width = `${b.width*c}px`, d.style.height = `${b.height*c}px`)
                            });
                            __c.vc(this, [a])
                        }
                        constructor(...a) {
                            super(...a);
                            this.iZa = vx()
                        }
                    };
                D5 = x5([Jc], D5);
                var C5 = class extends p5 {
                    static A(a) {
                        Q(a, {
                            bza: k5,
                            bounds: k5
                        })
                    }
                    get bza() {
                        const a = this.props.viewport,
                            b = this.props.Vw,
                            c = this.props.Ww;
                        return a == null || !b && !c ? a : k5(() => {
                            const d = __c.Pu(a.get());
                            return Hu({
                                top: c ? 0 : d.top,
                                left: b ? 0 : d.left,
                                width: d.width,
                                height: d.height
                            })
                        })
                    }
                    render() {
                        const a = this.props.GO,
                            b = this.props.sheet,
                            c = this.props.container,
                            d = this.props.range,
                            e = this.props.$H,
                            f = this.props.Vw,
                            g = this.props.Ww;
                        return $4("div", {
                            ref: this.pwa,
                            className: a5("i0YQww", this.props.className),
                            children: [Y4("div", {
                                ref: this.YUa,
                                className: "vUKoKg",
                                children: Y4("div", {
                                    ref: this.ZUa,
                                    children: Y4(E5, {
                                        GO: a,
                                        sheet: b,
                                        container: c,
                                        bounds: d,
                                        $p: this.props.$p,
                                        eE: this.props.eE,
                                        Yh: this.props.Yh,
                                        x_: this.props.x_,
                                        Y: this.props.Y,
                                        wj: this.wj,
                                        C7: this.C7,
                                        nT: this.nT
                                    })
                                })
                            }), Y4(this.tka, {}), e && Y4(e, {
                                sheet: b,
                                range: d,
                                Vw: f,
                                Ww: g
                            })]
                        })
                    }
                    componentDidMount() {
                        const a = j5(() => {
                                var g = this.props,
                                    h = g.Y,
                                    k = g.sheet;
                                const l = g.range;
                                var m = this.pwa.current;
                                const n = this.YUa.current;
                                g = this.ZUa.current;
                                h = h ? h.get() : 1;
                                const p = l ? k.Aa(l.Qc) + l.Qc.width - k.Aa(l.Wb) : k.width,
                                    q = l ? k.Ba(l.bd) +
                                    l.bd.height - k.Ba(l.bc) : k.height;
                                m && (m.style.width = `${p*h}px`, m.style.height = `${q*h}px`);
                                n && (n.style.width = `${p*h}px`, n.style.height = `${q*h}px`);
                                m = k.direction === "rtl";
                                m = l ? k.Aa(l.Wb) * h * (m ? 1 : -1) : 0;
                                k = l ? -k.Ba(l.bc) * h : 0;
                                g && (g.style.transform = `translate(${m}px, ${k}px)`)
                            }),
                            b = this.props.sheet;
                        var c = this.props.l1;
                        const d = this.props.Vw,
                            e = this.props.Ww,
                            f = d || e ? c === null || c === void 0 ? void 0 : c(b, d, e) : void 0;
                        c = j5(() => {
                            const g = this.pwa.current;
                            if (g != null) {
                                var h = d || e ? "sticky" : "relative",
                                    k = e ? "0px" : "unset",
                                    l = d ? "0px" :
                                    "unset",
                                    m = d ? "0px" : "unset",
                                    n = b.direction === "rtl";
                                if (f == null) g.style.position = h, g.style.top = k, g.style.left = n ? "unset" : l, g.style.right = n ? m : "unset";
                                else {
                                    const u = f.get();
                                    var p;
                                    g.style.position = (p = u.position) !== null && p !== void 0 ? p : h;
                                    var q;
                                    g.style.top = (q = u.top) !== null && q !== void 0 ? q : k;
                                    var r;
                                    g.style.left = n ? "unset" : (r = u.left) !== null && r !== void 0 ? r : l;
                                    var t;
                                    g.style.right = n ? (t = u.right) !== null && t !== void 0 ? t : m : "unset";
                                    var w;
                                    g.style.transform = (w = u.transform) !== null && w !== void 0 ? w : "unset"
                                }
                            }
                        });
                        __c.vc(this, [a, c])
                    }
                    get bounds() {
                        const a =
                            this.props.sheet,
                            b = this.props.range;
                        if (a.layout.cols.empty || a.layout.rows.empty) return {
                            Wb: void 0,
                            Qc: void 0,
                            bc: void 0,
                            bd: void 0
                        };
                        var c, d, e, f;
                        return {
                            Wb: (c = b === null || b === void 0 ? void 0 : b.Wb) !== null && c !== void 0 ? c : a.layout.cols.first(),
                            Qc: (d = b === null || b === void 0 ? void 0 : b.Qc) !== null && d !== void 0 ? d : a.layout.cols.last(),
                            bc: (e = b === null || b === void 0 ? void 0 : b.bc) !== null && e !== void 0 ? e : a.layout.rows.first(),
                            bd: (f = b === null || b === void 0 ? void 0 : b.bd) !== null && f !== void 0 ? f : a.layout.rows.last()
                        }
                    }
                    constructor(...a) {
                        super(...a);
                        this.pwa = (C5.A(this), vx());
                        this.YUa = vx();
                        this.ZUa = vx();
                        this.nT = new KXb;
                        this.jvb = k5(() => [...this.wj.get().keys()].sort((b, c) => this.props.sheet.layout.rows.cf(b, c)), {
                            equals: __c.Wr()
                        });
                        this.hvb = k5(() => [...this.C7.get().keys()].sort((b, c) => this.props.sheet.layout.cols.cf(b, c)), {
                            equals: __c.Wr()
                        });
                        this.tka = d5(() => Y4(this.props.b5a, {
                            wj: this.jvb,
                            ivb: this.hvb,
                            deb: this.nT.leb,
                            range: this.props.range
                        }));
                        this.wj = k5(() => {
                            var b;
                            const c = this.props.sheet;
                            var d = this.props.Y,
                                e = (b = this.bza) === null || b === void 0 ? void 0 :
                                b.get();
                            if (e && (e.height <= 0 || e.width <= 0)) return new Map;
                            b = this.bounds;
                            d = d.get();
                            var f = 50 * d;
                            const g = e ? e.tl.y - f : b.bc ? c.Ba(b.bc) : 0;
                            e = e ? e.br.y + f : b.bd ? c.Ba(b.bd) + b.bd.height : 0;
                            f = new Map;
                            for (let h = b.bc; h != null && b.bd != null && c.layout.rows.cf(h, b.bd) <= 0; h = c.layout.rows.next(h)) {
                                const k = c.Ba(h);
                                if (!(k + h.height < g)) {
                                    if (k > e) break;
                                    f.set(h, k * d)
                                }
                            }
                            return f
                        }, {
                            equals: v5.shallow
                        });
                        this.C7 = k5(() => {
                            var b;
                            const c = this.props.sheet;
                            var d = this.props.Y,
                                e = (b = this.bza) === null || b === void 0 ? void 0 : b.get();
                            if (e && (e.height <= 0 || e.width <=
                                    0)) return new Map;
                            b = this.bounds;
                            d = d.get();
                            var f = 50 * d;
                            const g = e ? e.tl.x - f : b.Wb ? c.Aa(b.Wb) : 0;
                            e = e ? e.br.x + f : b.Qc ? c.Aa(b.Qc) + b.Qc.width : 0;
                            f = new Map;
                            for (let h = b.Wb; h != null && b.Qc != null && c.layout.cols.cf(h, b.Qc) <= 0; h = c.layout.cols.next(h)) {
                                const k = c.Aa(h);
                                if (!(k + h.width < g)) {
                                    if (k > e) break;
                                    f.set(h, k * d)
                                }
                            }
                            return f
                        }, {
                            equals: v5.shallow
                        })
                    }
                };
                C5 = x5([Jc], C5);
                var KXb = class {
                        constructor() {
                            this.cells = new JXb;
                            this.xxa = (a, b, c) => {
                                let d = this.cells.get([a, b]);
                                d == null && (d = w5.box(void 0, {
                                    deep: !1
                                }), this.cells.set([a, b], d));
                                d.set(c);
                                return () => {
                                    const e = this.cells.get([a, b]);
                                    e === d && (e.set(void 0), this.cells.delete([a, b]))
                                }
                            };
                            this.leb = (a, b) => {
                                var c;
                                let d = this.cells.get([a, b]);
                                d == null && (d = w5.box(void 0, {
                                    deep: !1
                                }), this.cells.set([a, b], d));
                                return (c = d.get()) === null || c === void 0 ? void 0 : c.nJa
                            }
                        }
                    },
                    E5 = class extends p5 {
                        static A(a) {
                            Q(a, {
                                gM: w5.shallow,
                                Br: k5,
                                cHa: u5,
                                z$: u5.bound
                            })
                        }
                        get Br() {
                            var a;
                            const b = (a = this.props.$p) === null || a === void 0 ? void 0 : a.get();
                            if (b != null && b.length !== 0) return new __c.oE(b)
                        }
                        render() {
                            var a;
                            return $4("div", {
                                ref: kXb(this.je, (a = this.Br) === null || a === void 0 ? void 0 : a.jn),
                                children: [Y4("div", {
                                    ref: this.fna,
                                    className: "_5YlOqQ"
                                }), Y4("div", {
                                    ref: this.hna,
                                    className: "_XCmKw"
                                }), this.gM.map(b => b.iob)]
                            })
                        }
                        componentDidMount() {
                            const a = l5(() => [this.props.sheet, this.props.C7.get(), this.props.wj.get()], ([d, e, f], g) => {
                                    [g] = g || [];
                                    d !== g && (d = D(this.fna.current), g = D(this.hna.current), d.innerHTML =
                                        "", g.innerHTML = "", this.vDa.length = 0, this.gM.length = 0);
                                    this.cHa(e, f)
                                }, {
                                    fireImmediately: !0
                                }),
                                b = j5(() => {
                                    var d = this.props,
                                        e = d.Y;
                                    d = d.sheet;
                                    const f = this.je.current;
                                    f && (e = e ? e.get() : 1, f.style.width = `${d.width*e}px`, f.style.height = `${d.height*e}px`)
                                }),
                                c = this.gM.map(d => gXb(d));
                            __c.vc(this, [b, a, ...c])
                        }
                        cHa(a, b) {
                            const c = D(this.fna.current),
                                d = D(this.hna.current),
                                e = [],
                                f = new Map;
                            for (const g of this.vDa) b.has(g.xa) ? f.set(g.xa, g) : e.push(g);
                            for (const [g, h] of b) b = f.get(g) || e.pop(), b || (b = new LXb(this.z$, g), c.appendChild(b.H9),
                                d.appendChild(b.J9), this.vDa.push(b)), b.update(h, g, a);
                            for (const g of e) g.hide()
                        }
                        z$(a, b) {
                            const c = this.props.x_,
                                d = this.props.sheet,
                                e = this.props.container,
                                f = this.props.nT;
                            a = new MXb(this.props.GO, this.props.eE, this.props.Yh, c(a, b), d, a, b, e, f.xxa, this.Iba, this.Hba);
                            __c.vc(this, gXb(a));
                            this.gM.push(a);
                            return a
                        }
                        constructor(...a) {
                            super(...a);
                            this.je = (E5.A(this), vx());
                            this.fna = vx();
                            this.hna = vx();
                            this.vDa = [];
                            this.gM = [];
                            this.Iba = s5(b => {
                                const c = this.props.wj.get();
                                return b === "first" ? c.keys().next().value : [...c.keys()].pop()
                            });
                            this.Hba = s5(b => {
                                const c = this.props.C7.get();
                                return b === "first" ? c.keys().next().value : [...c.keys()].pop()
                            })
                        }
                    };
                E5 = x5([Jc], E5);
                var LXb = class {
                        static A(a) {
                            Q(a, {
                                update: u5
                            })
                        }
                        update(a, b, c) {
                            [this.H9, this.J9].forEach(d => {
                                d.style.transform = `translateY(${a}px)`;
                                d.classList.add("FPpqvg")
                            });
                            this.xa = b;
                            for (const [d] of c) c = this.gM.get(d), c || (c = this.z$(d, b), this.gM.set(d, c), this.H9.appendChild(c.G9), this.J9.appendChild(c.PM)), c.update(b)
                        }
                        hide() {
                            [this.H9, this.J9].forEach(a => {
                                a.style.transform = "translate(-1000px, -1000px) scale(0)"
                            })
                        }
                        constructor(a, b) {
                            this.z$ = a;
                            this.xa = b;
                            this.H9 = (LXb.A(this), document.createElement("div"));
                            this.J9 = document.createElement("div");
                            this.gM = new Map
                        }
                    },
                    MXb = class {
                        static A(a) {
                            Q(a, {
                                s$: w5.ref,
                                xa: w5.ref,
                                Dra: k5,
                                update: u5,
                                pu: k5,
                                attrs: k5.struct,
                                gta: k5,
                                Iw: k5,
                                renderer: k5,
                                nJa: k5.struct
                            })
                        }
                        get Dra() {
                            if (!fXb) return !1;
                            const a = this.pu;
                            return a == null || a.content.ref == null || a.content.ref.type !== "formula" ? !1 : this.GO(this.sheet, a.content.ref.value)
                        }
                        update(a) {
                            a !== this.xa && (this.xa = a, this.UA.xa = a, this.bpa && this.bpa(), this.bpa = this.xxa(this.xa, this.col, this))
                        }
                        get iob() {
                            return this.s$
                        }
                        get pu() {
                            const a = this.sheet.layout.cells.get(this.xa, this.col);
                            return a ?
                                a.ref : void 0
                        }
                        get attrs() {
                            const a = this.UA.attrs;
                            return {
                                uh: a === null || a === void 0 ? void 0 : a.uh,
                                textAlign: a === null || a === void 0 ? void 0 : a.textAlign,
                                direction: a === null || a === void 0 ? void 0 : a.direction,
                                link: a === null || a === void 0 ? void 0 : a.link
                            }
                        }
                        get gta() {
                            var a = this.UA.span;
                            if (!a) return !1;
                            if (a.bc === a.bd && a.Wb === a.Qc) return !0;
                            var b = this.Iba("first");
                            const c = this.Iba("last"),
                                d = this.Hba("first"),
                                e = this.Hba("last");
                            if (!(b && c && d && e)) return !1;
                            b = this.sheet.layout.rows.cf(a.bc, b) >= 0 && this.sheet.layout.rows.cf(a.bc, c) <=
                                0 ? a.bc : b;
                            a = this.sheet.layout.cols.cf(a.Wb, d) >= 0 && this.sheet.layout.cols.cf(a.Wb, e) <= 0 ? a.Wb : d;
                            return b === this.xa && a === this.col
                        }
                        get Iw() {
                            const a = this.sheet,
                                b = this.xa,
                                c = this.col;
                            if (!this.container) return {
                                type: void 0,
                                sheet: a,
                                xa: b,
                                column: c
                            };
                            switch (this.container.type) {
                                case "fixed-page":
                                    return this.container.xnb.Md(c, b);
                                case "sheet-item":
                                    return this.container.aza.Md(c, b);
                                case "sheet-element":
                                    return this.container.xrb.Md(c, b);
                                default:
                                    throw new E(this.container);
                            }
                        }
                        get renderer() {
                            const a = this.pu;
                            if (a && this.gta &&
                                (a.content.ref || a.Ha.ref)) return this.eE({
                                context: {
                                    container: this.Iw,
                                    attrs: this.attrs
                                },
                                qq: this.dva,
                                Yh: this.Yh
                            })
                        }
                        get nJa() {
                            this.oJa.reportObserved();
                            var a = sXb(() => this.renderer);
                            if (a && (a = a.type === "react" ? this.L4 : this.VE, a.childNodes.length !== 0 && (a = a.childNodes[0], a instanceof HTMLElement))) return {
                                width: a.clientWidth,
                                height: a.clientHeight
                            }
                        }
                        constructor(a, b, c, d, e, f, g, h, k, l, m) {
                            var n, p, q, r, t, w;
                            this.GO = a;
                            this.eE = b;
                            this.UA = d;
                            this.sheet = e;
                            this.col = f;
                            this.container = h;
                            this.xxa = k;
                            this.Iba = l;
                            this.Hba = m;
                            this.G9 =
                                (MXb.A(this), document.createElement("div"));
                            this.PM = document.createElement("div");
                            this.QE = document.createElement("div");
                            this.VE = document.createElement("div");
                            this.L4 = document.createElement("div");
                            this.oJa = rXb("content size atom");
                            this.dva = u5(() => this.oJa.reportChanged());
                            this.xa = g;
                            this.G9.className = "_2JFriw";
                            this.PM.className = "imy9ug";
                            this.QE.className = a5("pDMp7w", {
                                _0yZ6Qg: ((p = this.pu) === null || p === void 0 ? void 0 : (n = p.content.ref) === null || n === void 0 ? void 0 : n.type) !== "text3",
                                qhF5uA: ((r = this.pu) === null ||
                                    r === void 0 ? void 0 : (q = r.content.ref) === null || q === void 0 ? void 0 : q.type) !== "text3" && ((w = this.pu) === null || w === void 0 ? void 0 : (t = w.content.ref) === null || t === void 0 ? void 0 : t.type) !== "text2",
                                qxD1GA: this.Dra
                            });
                            this.VE.className = "_30B9pw";
                            this.QE.appendChild(this.VE);
                            this.PM.appendChild(this.QE);
                            this.L4.className = "G7zH2w";
                            this.bpa = k(this.xa, this.col, this);
                            this.Yh = u => Y4(c, { ...u,
                                qq: this.dva
                            })
                        }
                    };
                var m5 = class extends p5 {
                    static A(a) {
                        Q(a, {
                            sba: k5
                        })
                    }
                    render() {
                        const {
                            GO: a,
                            sheet: b,
                            container: c,
                            $p: d,
                            l1: e,
                            eE: f,
                            He: g,
                            Yh: h,
                            viewport: k,
                            $H: l,
                            d2a: m = !1
                        } = this.props;
                        if (!b.layout.cols.empty && !b.layout.rows.empty) return Y4("div", {
                            className: a5("SNkrHw", b.direction === "ltr" ? "TA4X7w" : "WvuqMw", {
                                RaA0Nw: m
                            }),
                            ...g,
                            children: Y4(D5, {
                                GO: a,
                                eE: f,
                                Yh: h,
                                b5a: this.tka,
                                x_: this.x_,
                                sheet: b,
                                container: c,
                                $p: d,
                                l1: e,
                                Y: this.Y,
                                viewport: k,
                                $H: l,
                                sba: this.sba
                            })
                        })
                    }
                    get sba() {
                        var a = this.props.sheet;
                        const b = {},
                            c = a.view.freeze.LW ? a.layout.we.get(a.view.freeze.LW) :
                            void 0,
                            d = a.view.freeze.DI ? a.layout.Wd.get(a.view.freeze.DI) : void 0,
                            e = a.layout.rows.first(),
                            f = a.layout.rows.last(),
                            g = a.layout.cols.first(),
                            h = a.layout.cols.last();
                        if (e != null && f != null && g != null && h != null) {
                            var k = d ? a.layout.cols.next(d) : g;
                            a = c ? a.layout.rows.next(c) : e;
                            c && d && (b.wHa = {
                                range: {
                                    Wb: g,
                                    bc: e,
                                    Qc: d,
                                    bd: c
                                }
                            });
                            c && k && (b.n2a = {
                                range: {
                                    Wb: k,
                                    bc: e,
                                    Qc: h,
                                    bd: c
                                }
                            });
                            d && a && (b.$Na = {
                                range: {
                                    Wb: g,
                                    bc: a,
                                    Qc: d,
                                    bd: f
                                }
                            });
                            a && k && (b.a1a = {
                                range: {
                                    Wb: k,
                                    bc: a,
                                    Qc: h,
                                    bd: f
                                }
                            });
                            return b
                        }
                    }
                    get Y() {
                        return this.props.Y ? this.props.Y : k5(() => 1)
                    }
                    constructor(...a) {
                        super(...a);
                        this.tka = (m5.A(this), d5(b => {
                            const {
                                sheet: c,
                                Fsa: d,
                                Y: e,
                                l9: f = "hidden"
                            } = this.props;
                            return Y4(z5, {
                                sheet: c,
                                range: b.range,
                                Y: e,
                                children: Y4(IXb, { ...b,
                                    sheet: c,
                                    Y: this.Y,
                                    Fsa: d,
                                    overflow: f
                                })
                            })
                        }));
                        this.x_ = (b, c) => new __c.PKa(this.props.ID, this.props.NA, this.props.sheet, b, c, this.Y, this.Vu, this.Xu);
                        this.Vu = (b, c) => {
                            var d, e;
                            return (d = (e = this.props).Vu) === null || d === void 0 ? void 0 : d.call(e, this.props.sheet, b, c)
                        };
                        this.Xu = (b, c) => {
                            var d, e;
                            return (d = (e = this.props).Xu) === null || d === void 0 ? void 0 : d.call(e, this.props.sheet, b, c)
                        }
                    }
                };
                m5 = x5([Jc], m5);
                __c.WKa = {
                    Ngb: function(a) {
                        const b = a.No,
                            c = a.Rd,
                            d = a.qd,
                            e = a.dn,
                            f = a.ID,
                            g = a.NA,
                            h = a.CY;
                        NWb({
                            MA: a.MA,
                            Xf: a.Xf,
                            btb: a.hQ,
                            Ab: a.Ab
                        });
                        const k = iXb({
                            eE: h,
                            ID: f,
                            NA: g,
                            Oo: void 0
                        });
                        b.Mka = cXb({
                            Oq: k
                        });
                        c.uka = TWb({
                            Oq: k
                        });
                        ({
                            f5a: a
                        } = $Wb({
                            Oq: k,
                            Ef: e(),
                            gZa: new BXb
                        }));
                        d.Vq.Lka = a;
                        const {
                            l3a: l,
                            m3a: m,
                            k3a: n
                        } = SWb();
                        return {
                            nFa: d5(p => Y4(tXb, { ...p,
                                container: void 0,
                                Oq: k,
                                e5a: l,
                                g5a: m,
                                c5a: n,
                                Yh: uXb
                            }))
                        }
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/a1693ff0e6d52af9.js.map