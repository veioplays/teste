window['cmsg']['assets'] = window['cmsg']['assets'] || {};
window['cmsg']['assets']["pt-BR"] = Object.assign(window['cmsg']['assets']["pt-BR"] || {}, {
    "12188": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "15706": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "20371": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "20382": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "35024": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "36732": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "38701": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "44868": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "46405": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "46763": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "50869": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "53508": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "53607": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "57406": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "70911": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "71078": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "76420": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "81869": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "83103": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "84283": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    },
    "90364": {
        "js": ["510a0dfd32a7e7ff.strings.js"],
        "css": []
    },
    "95665": {
        "js": ["3e577775d4572e6a.strings.js"],
        "css": []
    }
});