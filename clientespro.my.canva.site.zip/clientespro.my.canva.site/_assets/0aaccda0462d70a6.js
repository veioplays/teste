(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [4143], {

        /***/
        994944: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(59534);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                var E = __c.E;
                var Q = __c.Q;
                var sVb = function(a, b = "medium") {
                        if (a !== null && a !== void 0 && a.length) {
                            var c = window.devicePixelRatio || 1,
                                d = (typeof b === "number" ? b : rVb(b)) * c;
                            return [...a].sort((e, f) => {
                                e = e.width;
                                f = f.width;
                                return e > d && f < d ? -1 : e < d && f > d ? 1 : Math.abs(e - d) - Math.abs(f - d)
                            })[0].url
                        }
                    },
                    yVb = function(a, b) {
                        class c {
                            static A(d) {
                                Q(d, {
                                    Xe: H4,
                                    ula: H4
                                })
                            }
                            get Xe() {
                                switch (this.ula) {
                                    case "date":
                                        return new tVb(this.Go, b.language || "en-AU");
                                    case "select":
                                        return new uVb(this.Go);
                                    case "mention":
                                        return new vVb(this.Go);
                                    case "embed":
                                        return new wVb(this.Go);
                                    case "plain_number":
                                    case "currency":
                                    case "percentage":
                                    case void 0:
                                        break;
                                    default:
                                        throw new E(this.ula);
                                }
                            }
                            get ula() {
                                var d;
                                return (d = this.Go.wr) === null || d === void 0 ? void 0 : d.type
                            }
                            constructor(d) {
                                this.context = d;
                                this.Go = (c.A(this), void 0);
                                this.Go = __c.D(a.Xw(d.sheet, d.xa, d.column))
                            }
                        }
                        return xVb(d => (new c(d)).Xe)
                    },
                    AVb = function() {
                        const a = I4(() => new Map, []);
                        return {
                            Geb: b => {
                                if (a.has(b)) return __c.D(a.get(b));
                                const c = zVb();
                                a.set(b, c);
                                return c
                            }
                        }
                    },
                    BVb = function(a, b) {
                        return I4(() => {
                            const c = new Map;
                            return d => {
                                if (c.has(d)) return __c.D(c.get(d));
                                const e = a(d);
                                c.set(d, e);
                                return e
                            }
                        }, b)
                    },
                    IVb = function({
                        children: a,
                        keyFrame: b,
                        KZa: c,
                        ariaLive: d,
                        TPa: e = !1,
                        r6a: f,
                        Rna: g,
                        bbb: h,
                        lCb: k,
                        hJa: l,
                        gLa: m,
                        jCb: n,
                        Qtb: p
                    }) {
                        const {
                            Geb: q
                        } = AVb(), {
                            Idb: r,
                            ipb: t
                        } = CVb(b, a), w = BVb(u => () => {
                            (e === !1 || typeof e === "function" && !e(u)) && t(u)
                        }, [t, e]);
                        return J4("div", {
                            className: K4(g, "_9GxJfQ", {
                                KwB0XQ: l === "hidden",
                                WV1Mmw: c === "fill-height",
                                _2uSJxw: c === "flex-grow"
                            }),
                            children: J4("div", {
                                className: K4("m2VaAA", h),
                                "aria-live": d,
                                style: k,
                                role: "region",
                                children: [...r.map(({
                                    key: u,
                                    element: x
                                }) => J4(DVb, { in: u === b,
                                    timeout: f,
                                    classNames: p,
                                    mountOnEnter: !0,
                                    unmountOnExit: !e,
                                    nodeRef: q(u),
                                    onExited: w(u),
                                    children: y => J4(EVb.Provider, {
                                        value: y,
                                        children: J4("div", {
                                            className: K4("KxXR9g", n, {
                                                KwB0XQ: m === "hidden"
                                            }),
                                            ref: q(u),
                                            "aria-hidden": y === FVb || y === GVb || y === HVb,
                                            children: u === b ? a : x
                                        })
                                    })
                                }, u)), r.every(u => u.key !== b) && J4(DVb, { in: !1,
                                    timeout: f,
                                    classNames: p,
                                    mountOnEnter: !0,
                                    unmountOnExit: !e,
                                    nodeRef: q(b),
                                    onExited: e ? void 0 : w(b),
                                    children: u => J4(EVb.Provider, {
                                        value: u,
                                        children: J4("div", {
                                            className: K4("KxXR9g", n),
                                            ref: q(b),
                                            "aria-hidden": u === FVb || u === GVb || u === HVb,
                                            children: a
                                        })
                                    })
                                }, b)]
                            })
                        })
                    },
                    CVb = function(a,
                        b) {
                        const [c, d] = JVb(() => [{
                            key: a,
                            element: b
                        }]);
                        KVb(() => {
                            d(f => f.every(g => g.key !== a) ? f.concat({
                                key: a,
                                element: b
                            }) : f.map(g => g.key === a ? {
                                key: a,
                                element: b
                            } : g))
                        }, [a, b]);
                        const e = L4(f => {
                            d(g => g.filter(h => h.key !== f))
                        }, []);
                        return {
                            Idb: c,
                            ipb: e
                        }
                    },
                    LVb = function(a) {
                        switch (a.type) {
                            case "mention":
                                return "bCAtqw";
                            case "embed":
                                return "BTcT3w";
                            case "date":
                                return "McKQgg";
                            case "select":
                                return "V2E5nQ";
                            default:
                                throw new E(a);
                        }
                    },
                    PVb = function(a, b) {
                        switch (a.type) {
                            case "mention":
                                return J4(MVb, {
                                    Ur: a.user ? b.Y0(a.user) : void 0,
                                    text: a.text,
                                    backgroundColor: a.user ? b.Zdb(a.user).background : void 0
                                });
                            case "embed":
                                const c = !a.url;
                                a = b.jLa.f0.get(a.url);
                                return J4(NVb, {
                                    icon: a,
                                    Jhb: c
                                });
                            case "date":
                                return a.text ? void 0 : J4(OVb, {});
                            case "select":
                                break;
                            default:
                                throw new E(a);
                        }
                    },
                    RVb = function(a, b) {
                        switch (a.type) {
                            case "mention":
                            case "embed":
                            case "date":
                                break;
                            case "select":
                                return J4(QVb, {
                                    selected: !!b.lXa
                                });
                            default:
                                throw new E(a);
                        }
                    },
                    M4 = function(a) {
                        return (/Mac/.test(navigator.platform) ? a.metaKey : a.ctrlKey) ? !0 : a instanceof KeyboardEvent ? a.key === "Meta" || ["91",
                            "224"
                        ].includes(a.code) : !1
                    },
                    SVb = function(a) {
                        __c.v(!0, "chunkLength must be positive");
                        const b = [];
                        for (let c = 0; c < a.length; c += 50) b.push(a.slice(c, c + 50));
                        return b
                    },
                    TVb = function(a, b, c) {
                        if (c) {
                            var d = sVb(c.images, "medium"),
                                e = sVb(c.images, "xxxlarge");
                            if (d && e) {
                                c = new Image;
                                c.src = d;
                                var f = new Image;
                                f.src = e;
                                f.onload = N4(() => a.o7.set(b, e));
                                f.onerror = N4(() => a.o7.set(b, void 0));
                                !f.complete && c.complete ? a.o7.set(b, d) : c.src = ""
                            }
                        } else a.o7.set(b, void 0)
                    },
                    VVb = function(a, {
                        url: b,
                        id: c,
                        extension: d
                    }) {
                        if (!a.promises.has(b)) {
                            const e =
                                new Promise(f => {
                                    a.ih ? a.ih.bFb(new UVb({
                                        id: c,
                                        extension: d
                                    })).then(({
                                        document: g
                                    }) => {
                                        const h = g.$f.content.title;
                                        h ? (O4(() => a.W_a.set(b, {
                                            status: 1,
                                            title: h
                                        })), f(h)) : f(void 0)
                                    }).catch(() => {
                                        O4(() => a.W_a.set(b, {
                                            status: 2
                                        }));
                                        f(void 0)
                                    }) : f(void 0)
                                });
                            a.promises.set(b, e)
                        }
                        return a.promises.get(b)
                    },
                    rVb = a => a.endsWith("rem") ? parseFloat(a) * 10 : __c.zy * __c.HDb[a],
                    P4 = __webpack_require__(519427),
                    N4 = P4.action,
                    WVb = P4.comparer,
                    H4 = P4.computed,
                    XVb = P4.observable,
                    Q4 = P4.ObservableMap,
                    O4 = P4.runInAction;
                var xVb = __webpack_require__(635872).Om;
                var R4 = __webpack_require__(875604),
                    YVb = R4.createContext,
                    zVb = R4.createRef,
                    S4 = R4.memo,
                    L4 = R4.useCallback,
                    KVb = R4.useEffect,
                    ZVb = R4.useLayoutEffect,
                    I4 = R4.useMemo,
                    JVb = R4.useState;
                var $Vb = __webpack_require__(443763),
                    J4 = $Vb.jsx,
                    aWb = $Vb.jsxs;
                var bWb = __webpack_require__,
                    cWb = bWb(993864),
                    K4 = bWb.n_x(cWb)();
                var DVb = __webpack_require__(460876).Z;
                var T4 = __webpack_require__(223826),
                    HVb = T4.Wj,
                    FVb = T4.Ix,
                    GVb = T4.$r;
                var U4 = __webpack_require__(446474).Pi;
                var dWb = class {
                        static A(a) {
                            Q(a, {
                                text: H4,
                                user: H4,
                                brand: H4
                            })
                        }
                        get text() {
                            return this.Xe.text
                        }
                        get user() {
                            return this.Xe.user
                        }
                        get brand() {
                            return this.Xe.brand
                        }
                        constructor(a) {
                            this.Xe = a;
                            this.type = (dWb.A(this), "mention")
                        }
                    },
                    eWb = class {
                        static A(a) {
                            Q(a, {
                                text: H4,
                                url: H4
                            })
                        }
                        get text() {
                            return this.Xe.text
                        }
                        get url() {
                            return this.Xe.url
                        }
                        constructor(a) {
                            this.Xe = a;
                            this.type = (eWb.A(this), "embed")
                        }
                    },
                    fWb = class {
                        static A(a) {
                            Q(a, {
                                text: H4,
                                language: H4,
                                style: H4,
                                date: H4
                            })
                        }
                        get text() {
                            return this.Xe.text
                        }
                        get language() {
                            return this.Xe.language
                        }
                        get style() {
                            return this.Xe.style
                        }
                        get date() {
                            return this.Xe.date
                        }
                        constructor(a) {
                            this.Xe =
                                a;
                            this.type = (fWb.A(this), "date")
                        }
                    },
                    gWb = class {
                        static A(a) {
                            Q(a, {
                                text: H4,
                                options: H4,
                                Cf: H4,
                                fT: H4
                            })
                        }
                        get text() {
                            return this.Xe.text
                        }
                        get options() {
                            return this.Xe.options.map(a => a)
                        }
                        get Cf() {
                            return this.Xe.Cf
                        }
                        get fT() {
                            var a;
                            return (a = this.Xe.options.first(b => b.id === this.Xe.Cf)) === null || a === void 0 ? void 0 : a.fill.color
                        }
                        constructor(a) {
                            this.Xe = a;
                            this.type = (gWb.A(this), "select")
                        }
                    },
                    hWb = xVb(a => {
                        switch (a.type) {
                            case "mention":
                                return new dWb(a);
                            case "embed":
                                return new eWb(a);
                            case "date":
                                return new fWb(a);
                            case "select":
                                return new gWb(a);
                            default:
                                throw new E(a);
                        }
                    });
                var tVb = class {
                        static A(a) {
                            Q(a, {
                                style: H4,
                                date: H4,
                                text: H4
                            })
                        }
                        get style() {
                            return 2
                        }
                        get date() {
                            var a;
                            (a = this.Ep.Yk.type === 2 ? this.Ep.Yk.date : void 0) || (a = new Date, a = __c.Wz(a), a = {
                                year: a.getFullYear(),
                                month: a.getMonth() + 1,
                                day: a.getDate(),
                                Nfb: a.getHours(),
                                zkb: a.getMinutes()
                            });
                            return a
                        }
                        get text() {
                            return this.Ep.AB
                        }
                        constructor(a, b) {
                            this.Ep = a;
                            this.language = b;
                            this.type = (tVb.A(this), "date")
                        }
                    },
                    iWb = class {
                        get label() {
                            return this.option.label
                        }
                        get fill() {
                            return this.option.fill
                        }
                        constructor(a, b) {
                            this.option = a;
                            this.id =
                                b
                        }
                    },
                    uVb = class {
                        static A(a) {
                            Q(a, {
                                options: H4,
                                Cf: H4,
                                fT: H4,
                                text: H4,
                                HMa: H4({
                                    equals: WVb.shallow
                                })
                            })
                        }
                        get options() {
                            return this.HMa.map((a, b) => new iWb(a, b))
                        }
                        get Cf() {
                            var a;
                            return (a = this.options.find(b => b.label === this.text)) === null || a === void 0 ? void 0 : a.id
                        }
                        get fT() {
                            var a;
                            return (a = this.options.find(b => b.id === this.Cf)) === null || a === void 0 ? void 0 : a.fill.color
                        }
                        get text() {
                            return this.Ep.AB
                        }
                        get HMa() {
                            var a, b;
                            __c.C(((a = this.Ep.wr) === null || a === void 0 ? void 0 : a.type) === "select");
                            return (b = this.Ep.wr) === null || b === void 0 ?
                                void 0 : b.options
                        }
                        constructor(a) {
                            this.Ep = a;
                            this.type = (uVb.A(this), "select")
                        }
                    },
                    vVb = class {
                        static A(a) {
                            Q(a, {
                                PN: H4
                            })
                        }
                        get text() {
                            return this.PN ? this.PN.text : ""
                        }
                        get user() {
                            return this.PN ? this.PN.user : ""
                        }
                        get brand() {
                            return this.PN ? this.PN.brand : ""
                        }
                        get PN() {
                            if (this.Ep.Yk.type !== 9) return __c.C(this.Ep.Yk.type === 7), this.Ep.Yk ? this.Ep.Yk.value[0] : void 0
                        }
                        constructor(a) {
                            this.Ep = a;
                            this.type = (vVb.A(this), "mention")
                        }
                    },
                    wVb = class {
                        static A(a) {
                            Q(a, {
                                C0: H4
                            })
                        }
                        get text() {
                            return this.C0 ? this.C0.embed.text : ""
                        }
                        get url() {
                            return this.C0 ?
                                this.C0.embed.url : ""
                        }
                        get C0() {
                            if (this.Ep.Yk.type !== 9) return __c.C(this.Ep.Yk.type === 8), this.Ep.Yk ? this.Ep.Yk.value[0] : void 0
                        }
                        constructor(a) {
                            this.Ep = a;
                            this.type = (wVb.A(this), "embed")
                        }
                    };
                var jWb = class {
                    gqa(a) {
                        this.kma.gqa(a)
                    }
                    E5(a, b) {
                        this.kma.E5(a, b)
                    }
                    Y0(a) {
                        return this.kma.Y0(a)
                    }
                    dqa(a) {
                        this.jLa.dqa(a)
                    }
                    constructor(a, b, c, d) {
                        this.kma = a;
                        this.jLa = b;
                        this.Ab = c;
                        this.oF = d;
                        this.eDa = new __c.$tb;
                        this.Zdb = e => __c.SJa(this.eDa, e)
                    }
                };
                var EVb = YVb(void 0);
                var kWb = Number.parseInt("300ms", 10),
                    lWb = {
                        enter: "_QukmA",
                        enterActive: "_5_06KQ",
                        enterDone: void 0,
                        exitActive: "a952jg",
                        exitDone: "orZOEA"
                    },
                    mWb = S4(function({
                        Qs: a = !1,
                        children: b,
                        keyFrame: c,
                        KZa: d,
                        hJa: e = "hidden",
                        gLa: f = "hidden",
                        ariaLive: g,
                        TPa: h,
                        GFb: k = "none"
                    }) {
                        a = __c.tb() && !a;
                        return IVb({
                            children: b,
                            keyFrame: c,
                            KZa: d,
                            ariaLive: g,
                            hJa: e,
                            gLa: f,
                            TPa: h,
                            r6a: a ? kWb : 0,
                            bbb: K4({
                                _1niDPQ: a,
                                Q6kGbg: k === "none",
                                _9j7ODw: k === "layout"
                            }),
                            Qtb: lWb
                        })
                    });
                var nWb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.25 3.5a.75.75 0 0 0-1.5 0V5H7a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4h10a4 4 0 0 0 4-4V9a4 4 0 0 0-4-4h-.75V3.5a.75.75 0 0 0-1.5 0V5h-5.5V3.5Zm5.5 4v-1h-5.5v1a.75.75 0 0 1-1.5 0v-1H7A2.5 2.5 0 0 0 4.5 9v1h15V9A2.5 2.5 0 0 0 17 6.5h-.75v1a.75.75 0 0 1-1.5 0Zm4.75 4h-15V17A2.5 2.5 0 0 0 7 19.5h10a2.5 2.5 0 0 0 2.5-2.5v-5.5Z" fill="currentColor"/></svg>';
                var oWb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-1.288-.244-2.52-.687-3.65v-.1h-.04A10.003 10.003 0 0 0 12 2C6.477 2 2 6.477 2 12Zm12.653-8.078A8.526 8.526 0 0 1 19.63 8.25h-3.457c-.317-1.74-.848-3.236-1.52-4.328ZM20.2 9.75h-3.813c.075.723.114 1.476.114 2.25s-.04 1.527-.114 2.25h3.813A8.51 8.51 0 0 0 20.5 12a8.51 8.51 0 0 0-.301-2.25Zm-.569 6h-3.457c-.317 1.74-.848 3.236-1.52 4.328a8.526 8.526 0 0 0 4.977-4.328Zm-4.755-1.5a20.109 20.109 0 0 0 0-4.5h-5.75a20.116 20.116 0 0 0 0 4.5h5.75Zm-5.519 1.5h5.288C14.08 18.593 12.953 20.5 12 20.5c-.953 0-2.081-1.907-2.644-4.75Zm-1.529 0c.317 1.74.848 3.236 1.52 4.328A8.526 8.526 0 0 1 4.37 15.75h3.457Zm-.213-1.5H3.801A8.51 8.51 0 0 1 3.5 12c0-.779.105-1.533.301-2.25h3.813A21.9 21.9 0 0 0 7.5 12c0 .774.04 1.527.114 2.25ZM12 3.5c.953 0 2.081 1.907 2.644 4.75H9.356C9.92 5.407 11.047 3.5 12 3.5ZM4.37 8.25h3.457c.317-1.74.848-3.236 1.52-4.328A8.525 8.525 0 0 0 4.37 8.25Z" fill="currentColor"/></svg>';
                var pWb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M8.64 16.5a4.87 4.87 0 0 0 4.11 2.25h4.5a4.88 4.88 0 0 0 0-9.75h-4.5a4.88 4.88 0 0 0-4.5 3h1.7c.6-.9 1.63-1.5 2.8-1.5h4.5a3.38 3.38 0 0 1 0 6.75h-4.5c-.8 0-1.54-.28-2.12-.75H8.64zm7.1-9a4.87 4.87 0 0 0-4.12-2.25h-4.5a4.87 4.87 0 1 0 0 9.75h4.5a4.88 4.88 0 0 0 4.5-3h-1.69c-.6.9-1.63 1.5-2.8 1.5h-4.5a3.38 3.38 0 0 1 0-6.75h4.5c.8 0 1.54.28 2.12.75h1.98z"/></svg>';
                var qWb = '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.374 7.572A3.5 3.5 0 1 0 5.6 7.548a5.365 5.365 0 0 0-2.928 3.968 1.5 1.5 0 0 0 .592 1.441 7.9 7.9 0 0 0 4.7 1.543 7.9 7.9 0 0 0 4.698-1.542 1.5 1.5 0 0 0 .592-1.442 5.364 5.364 0 0 0-2.88-3.944ZM10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm-5.847 6.75a3.858 3.858 0 0 1 7.62 0A6.4 6.4 0 0 1 7.963 13a6.4 6.4 0 0 1-3.81-1.25Z" fill="currentColor"/></svg>';
                var rWb = S4(a => {
                        const b = a.link,
                            c = a.className,
                            d = a.ariaLabel,
                            e = a.fT,
                            f = a.lab,
                            g = a.N4a,
                            h = a.o5a,
                            k = a.measureRef,
                            l = a.onPointerDown,
                            m = a.onMouseEnter,
                            n = a.onMouseLeave,
                            p = K4({
                                EdewNw: !!g,
                                _6ZpPrw: !!h,
                                pzXyUA: a.text.length > 0
                            });
                        a = a.text.length > 0 ? a.text : "\ufeff";
                        return aWb("span", {
                            className: K4(c, "FedJ0Q"),
                            "aria-label": d || a,
                            children: [J4("span", {
                                className: K4("_2Lr6pQ", p),
                                children: J4("span", {
                                    className: "Z_WvzQ",
                                    children: a
                                })
                            }), aWb("span", {
                                className: K4("XemTdQ", p),
                                ref: k,
                                style: e ? {
                                    color: e
                                } : void 0,
                                onPointerDown: l,
                                onMouseEnter: m,
                                onMouseLeave: n,
                                children: [g, J4("span", {
                                    className: K4("U_QH_A", {
                                        C9XL8g: !f
                                    }),
                                    children: b ? J4("a", {
                                        className: "vgTP5Q",
                                        ...b,
                                        children: a
                                    }) : a
                                }), h]
                            })]
                        })
                    }),
                    MVb = S4(a => {
                        const b = a.backgroundColor,
                            c = a.Ur;
                        a = a.text;
                        const d = {
                            width: "0.9em",
                            height: "0.9em"
                        };
                        return J4(mWb, {
                            keyFrame: c ? "show" : "hide",
                            children: a ? J4(__c.LDb, {
                                name: a,
                                style: d,
                                backgroundColor: b,
                                Ur: c,
                                borderColor: c ? void 0 : b
                            }) : J4("span", {
                                "aria-hidden": "true",
                                className: "_tFJqA",
                                dangerouslySetInnerHTML: {
                                    __html: qWb
                                }
                            })
                        })
                    }),
                    NVb = S4(a => {
                        const b = a.icon;
                        a = a.Jhb;
                        return J4(mWb, {
                            keyFrame: b ? "favicon" : "placeholder",
                            children: b ? J4("span", {
                                className: "_tFJqA",
                                children: J4("img", {
                                    src: b,
                                    className: "qpbYdw"
                                })
                            }) : J4("span", {
                                "aria-hidden": "true",
                                className: "_tFJqA",
                                dangerouslySetInnerHTML: {
                                    __html: a ? pWb : oWb
                                }
                            })
                        })
                    }),
                    OVb = S4(() => J4("span", {
                        "aria-hidden": "true",
                        className: "_tFJqA",
                        dangerouslySetInnerHTML: {
                            __html: nWb
                        }
                    })),
                    QVb = S4(({
                        selected: a
                    }) => J4("div", {
                        className: K4("whph4A", {
                            zgzjww: a
                        }),
                        children: J4(__c.IL, {
                            size: "medium",
                            style: {
                                width: "0.9em",
                                height: "0.9em"
                            },
                            className: "_tFJqA"
                        })
                    })),
                    sWb = U4(a => {
                        const {
                            Xe: b,
                            lXa: c,
                            Dwa: d,
                            mode: e = "viewable",
                            measureRef: f,
                            qq: g,
                            onPointerDown: h
                        } = a;
                        a = b.text || "\u00a0".repeat(16);
                        const k = b.type === "embed" ? d.Ab(b.url) : void 0,
                            [l, m] = JVb(!1),
                            n = L4(t => m(M4(t)), [m]),
                            p = L4(t => m(!M4(t)), [m]),
                            q = L4(t => {
                                m(M4(t.nativeEvent));
                                document.addEventListener("keydown", n);
                                document.addEventListener("keyup", p)
                            }, [m, n, p]),
                            r = L4(() => {
                                m(!1);
                                document.removeEventListener("keydown", n);
                                document.removeEventListener("keyup", p)
                            }, [m, n, p]);
                        KVb(() => {
                            O4(() => {
                                switch (b.type) {
                                    case "mention":
                                        b.user && d.gqa(b.user);
                                        break;
                                    case "embed":
                                        d.dqa(b.url)
                                }
                            })
                        }, [b, d]);
                        ZVb(() => {
                            g === null || g === void 0 || g()
                        }, [b.type, a, g]);
                        return J4(rWb, {
                            text: a,
                            link: e === "viewable" || l ? k : void 0,
                            lab: b.text.length === 0,
                            ariaLabel: b.text || "",
                            className: LVb(b),
                            fT: b.fT,
                            N4a: PVb(b, d),
                            o5a: RVb(b, {
                                lXa: c
                            }),
                            measureRef: f,
                            onPointerDown: h,
                            onMouseEnter: b.type === "embed" && e === "editable" ? q : void 0,
                            onMouseLeave: b.type === "embed" && e === "editable" ? r : void 0
                        })
                    });
                var tWb = __c.L(() => ({
                    oGb: __c.RM(11),
                    mode: __c.F("A?", 1, "BY_USER_IDS"),
                    Nub: __c.QM(1)
                }));
                var uWb = class {
                        static A(a) {
                            Q(a, {
                                lR: XVb.shallow,
                                XLa: N4
                            })
                        }
                        Y0(a) {
                            return this.pHa.Y0(a)
                        }
                        gqa(a) {
                            this.dDa.has(a) || this.lR.has(a) || (this.lR.add(a), this.M$a())
                        }
                        E5(a, b) {
                            this.dDa.has(a) || (this.dDa.set(a, b), this.lR.delete(a), TVb(this.pHa, a, b))
                        }
                        async XLa() {
                            if (this.lR.size !== 0) {
                                var a = [...this.lR.values()];
                                this.lR.clear();
                                if (this.qHa) {
                                    var b = await this.qHa;
                                    await Promise.all(SVb(a).map(async c => {
                                        const d = new tWb({
                                                Nub: c
                                            }),
                                            {
                                                izb: e
                                            } = await b.DEb(d);
                                        O4(() => c.forEach(f => this.E5(f, e.get(f))))
                                    }))
                                } else a.forEach(c => this.E5(c))
                            }
                        }
                        constructor(a,
                            b) {
                            this.qHa = a;
                            this.dDa = (uWb.A(this), new Q4);
                            this.lR = new Set;
                            this.pHa = new vWb;
                            this.M$a = __c.Oc(() => this.XLa(), 200);
                            O4(() => {
                                b === null || b === void 0 || b.forEach((c, d) => this.E5(d, c))
                            })
                        }
                    },
                    vWb = class {
                        Y0(a) {
                            return this.o7.get(a)
                        }
                        constructor() {
                            this.o7 = new Q4
                        }
                    };
                var UVb = __c.L(() => ({
                    id: __c.W("id", 1),
                    extension: __c.Y("extension", 3),
                    eXa: __c.MM("revision", 5),
                    version: __c.MM("version", 2),
                    VFb: __c.MM("imagesetsLimit", 6)
                }));
                var wWb = class {
                    static A(a) {
                        Q(a, {
                            Icb: N4
                        })
                    }
                    async Icb(a) {
                        if (this.ih) {
                            var b = (new URL(a)).pathname; {
                                const c = /design\/(D[a-zA-Z0-9_-]{10})\/?([a-zA-Z0-9_-]+)?/g.exec(b);
                                c == null || c.length < 2 ? b = void 0 : (b = c[2], (new Set(["edit", "remix", "view", "watch"])).has(c[2]) && (b = void 0), b = {
                                    id: c[1],
                                    extension: b
                                })
                            }
                            if (b) return await VVb(this, {
                                url: a,
                                ...b
                            })
                        }
                    }
                    constructor(a) {
                        this.ih = a;
                        this.W_a = (wWb.A(this), new Q4);
                        this.promises = new Map
                    }
                };
                var xWb = class {
                    static A(a) {
                        Q(a, {
                            f0: XVb.shallow
                        })
                    }
                    async dqa(a) {
                        const b = new Image;
                        let c;
                        try {
                            var d;
                            const e = await ((d = this.oF) === null || d === void 0 ? void 0 : d.H8(a));
                            c = e === null || e === void 0 ? void 0 : e.Hcb
                        } catch (e) {}
                        c ? (b.src = c, b.onload = N4(() => this.f0.set(a, c)), b.onerror = N4(() => this.f0.set(a, void 0))) : O4(() => this.f0.set(a, void 0))
                    }
                    constructor(a) {
                        this.oF = a;
                        this.f0 = (xWb.A(this), new Map)
                    }
                };
                __c.yGa = {
                    Lgb: function(a) {
                        const b = a.document,
                            c = a.ih,
                            d = a.Ab,
                            e = a.oF;
                        var f = a.a9;
                        const g = a.qd,
                            h = a.MA,
                            k = a.fY;
                        a = a.hGb;
                        f = new uWb(a === null || a === void 0 ? void 0 : a(), f);
                        a = new xWb(e);
                        new wWb(c);
                        const l = new jWb(f, a, d, e),
                            m = yVb(k, b);
                        g.Vq.Hka = U4(({
                            item: p,
                            measureRef: q
                        }) => {
                            const r = I4(() => hWb(p.Xe), [p.Xe]);
                            return J4(sWb, {
                                Xe: r,
                                Dwa: l,
                                measureRef: q
                            })
                        });
                        const n = U4(({
                            context: p,
                            qq: q
                        }) => {
                            const r = I4(() => __c.D(m(p.container)), [p]);
                            ZVb(q, [q, p.container.column.width]);
                            return J4(sWb, {
                                Xe: r,
                                Dwa: l,
                                qq: q
                            })
                        });
                        h.AFa = ({
                                context: p,
                                qq: q
                            }) =>
                            ({
                                type: "react",
                                node: J4(n, {
                                    context: p,
                                    qq: q
                                })
                            });
                        return {
                            Dwa: l
                        }
                    }
                };
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/0aaccda0462d70a6.js.map