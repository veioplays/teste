(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [53684], {

        /***/
        810695: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._7ccc7343da2ae983607b3819c7bc1f93 = self._7ccc7343da2ae983607b3819c7bc1f93 || {};
            (function(__c) {
                __c.JFb = function(a) {
                    const b = { ...a.props
                    };
                    a.na.My(({
                        Sk: c,
                        QI: d
                    }) => {
                        c = a.LBb ? {} : {
                            We: c()
                        };
                        a.ma.track(a.event, { ...c,
                            Cq: d(),
                            ...b
                        })
                    })
                };
                __c.TJ.prototype.fU = __c.fa(17, function() {});
                __c.eM.prototype.fU = __c.fa(16, function() {
                    this.ended || this.mM || (this.mM = !0, setTimeout(() => {
                        try {
                            this.ended = !0, __c.gYa(this)
                        } catch (a) {
                            this.H.Nb(a, {
                                Ve: "Error ending span in next cycle",
                                extra: new Map(__c.WL(this))
                            })
                        }
                    }))
                });
            }).call(self, self._7ccc7343da2ae983607b3819c7bc1f93);
        }

    }
])
//# sourceMappingURL=sourcemaps/81c4feeafd696bd5.js.map