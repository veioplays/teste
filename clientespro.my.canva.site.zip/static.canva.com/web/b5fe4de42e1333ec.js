(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [67896], {

        /***/
        933618: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                __c.PYa = {
                    config: {
                        language: "pt-BR",
                        $d: {
                            yMMMd: 'd "de" MMM "de" yyyy',
                            yMd: "dd/MM/yyyy",
                            yMMM: 'MMM "de" yyyy'
                        },
                        ie: "jan. fev. mar. abr. mai. jun. jul. ago. set. out. nov. dez.".split(" "),
                        je: "janeiro fevereiro mar\u00e7o abril maio junho julho agosto setembro outubro novembro dezembro".split(" "),
                        Ne: "dd *[./\\s-] *mm *[./\\s-] *yy;dd *[./\\s-] *mm *[./\\s-] *yyyy;yyyy *[./\\s-] *mm *[./\\s-] *dd;dd *[./\\s-] *mm;mmm de yyyy;dd de mmm de yyyy".split(";")
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/b5fe4de42e1333ec.js.map