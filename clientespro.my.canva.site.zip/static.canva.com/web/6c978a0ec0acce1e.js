(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [19289], {

        /***/
        981587: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {}).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])