(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [21389], {

        /***/
        476834: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            self._5c0f058b2d917619b177d32cbc4c572b = self._5c0f058b2d917619b177d32cbc4c572b || {};
            (function(__c) {
                /*

                 Copyright The Closure Library Authors.
                 Copyright The Closure Compiler Authors.
                 SPDX-License-Identifier: Apache-2.0
                */
                var aa = function(a) {
                        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
                        for (var b = 0; b < a.length; ++b) {
                            var c = a[b];
                            if (c && c.Math == Math) return c
                        }
                        throw Error("Cannot find global object");
                    },
                    da = function(a, b) {
                        if (b) a: {
                            var c = ba;a = a.split(".");
                            for (var d = 0; d < a.length - 1; d++) {
                                var e = a[d];
                                if (!(e in c)) break a;
                                c = c[e]
                            }
                            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ca(c, a, {
                                configurable: !0,
                                writable: !0,
                                value: b
                            })
                        }
                    },
                    p = function(a, b) {
                        var c = [];
                        if (!a) throw Error(b == null ? "invalid argument" : ea(b, ...c));
                    },
                    ea = function(a, ...b) {
                        let c = 0;
                        return a.replace(/\{}/g, () => c < b.length ? b[c++] : "{}")
                    },
                    ha = function(a, b) {
                        var c = [];
                        if (!a) throw Error(b == null ? "invalid state" : ea(b, ...c));
                    },
                    ia = function(a, b, ...c) {
                        if (a == null) throw Error(b == null ? "argument is null" : ea(b, ...c));
                        return a
                    },
                    ma = function(a, b) {
                        if (!(a in ja)) {
                            const c = self.bootstrap;
                            if (!c) throw Error("Could not find bootstrap");
                            ja[a] = { ...c[a]
                            };
                            delete c[a]
                        }
                        a in ka && ka[a] != null ? a = ka[a] : (b = b(la.required(a, ja)), a = ka[a] =
                            b);
                        return a
                    },
                    oa = function() {
                        var a = window.location.search;
                        ["base", "page", "ui"].forEach(b => {
                            na(a, `bootstrap.${b}.`)
                        })
                    },
                    na = function(a, b) {
                        const c = new Map;
                        (new URLSearchParams(a)).forEach((d, e) => {
                            e.startsWith(b) && c.set(decodeURIComponent(e.replace(b, "").replace(/\+/g, " ")), decodeURIComponent(d.replace(/\+/g, " ")))
                        });
                        return c
                    },
                    qa = function(a) {
                        return new pa(a)
                    },
                    sa = function(a) {
                        return new ra(a)
                    },
                    ta = function(a) {
                        return a != null && a.then != null
                    },
                    wa = function(a) {
                        ({
                            af: b
                        } = {
                            af: !1
                        });
                        var b;
                        let c = !1,
                            d;
                        return (...e) => {
                            p(e.length ===
                                0);
                            if (d == null || b && (!d.ok || c)) try {
                                c = !1, d = ua(a()), ta(d.value) && d.value.then(null, () => c = !0)
                            } catch (f) {
                                d = va(f)
                            }
                            if (d.ok) return d.value;
                            throw d.error;
                        }
                    },
                    xa = function(a, b, c, d) {
                        return {
                            tag: c,
                            K: 2,
                            D: b,
                            default: d != null ? d : a.defaultValue,
                            defaultValue: a.defaultValue,
                            A: a.A
                        }
                    },
                    ya = function(a, b, c) {
                        return {
                            tag: c,
                            K: 3,
                            D: b,
                            defaultValue: a.defaultValue,
                            A: a.A
                        }
                    },
                    Aa = function(a) {
                        return (b, c, d) => {
                            const {
                                tag: e,
                                D: f,
                                U: g
                            } = r(b, c, d);
                            return {
                                K: 5,
                                tag: e,
                                D: f,
                                ka: g,
                                Ec: za.A,
                                A: a === "object" ? "object" : a === "enum" ? "string" : a.A
                            }
                        }
                    },
                    u = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 1,
                            D: void 0,
                            dd: d,
                            value: e,
                            xe: !1,
                            A: "string"
                        }
                    },
                    v = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 2,
                            D: d,
                            ka: e,
                            A: "object"
                        }
                    },
                    y = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 3,
                            D: d,
                            ka: e,
                            A: "object"
                        }
                    },
                    z = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 4,
                            D: d,
                            ka: e,
                            A: "object"
                        }
                    },
                    C = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e,
                            md: f
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 2,
                            D: d,
                            ka: e,
                            default: f,
                            A: "string"
                        }
                    },
                    D = function(a, b) {
                        const {
                            tag: c,
                            D: d,
                            U: e
                        } = r(a, b);
                        return {
                            tag: c,
                            K: 3,
                            D: d,
                            ka: e,
                            A: "string"
                        }
                    },
                    I = function(a) {
                        var b = {};
                        const c = wa(() => {
                            const e = a();
                            var f = Object.keys(e);
                            const g = {},
                                h = {};
                            for (const k of f) switch (f = e[k], f.K) {
                                case 1:
                                    h[f.tag] = { ...f,
                                        name: k
                                    };
                                    break;
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                    g[f.tag] = { ...f,
                                        name: k
                                    };
                                    break;
                                default:
                                    throw new E(f);
                            }
                            return {
                                kind: 1,
                                Vc: e,
                                Bb: Ba(e, b.zb),
                                Ke: g,
                                pe: h
                            }
                        });
                        class d {
                            static va(e) {
                                return d.lb(e, [])
                            }
                            static Qb(e, f, g) {
                                f = f.config;
                                return f.A === "Uint8Array" ? Ca(e) : f.ka ? f.ka.lb(e, g) : e
                            }
                            static P(e) {
                                return d.Ma(e, [])
                            }
                            static yb(e, f, g) {
                                f = f.config;
                                return f.A === "Uint8Array" ? Da(e) : f.ka ?
                                    f.ka.Ma(e, g) : e
                            }
                            static Ma(e, f) {
                                var {
                                    Bb: g
                                } = c(), h = Object.create(d.prototype);
                                for (const x of g) {
                                    g = x.config;
                                    const w = x.name;
                                    var k = x.L,
                                        l = x.W,
                                        n = k,
                                        m = e[n];
                                    m == null && l != null && e[l] != null && (n = l, m = e[n]);
                                    switch (g.K) {
                                        case 3:
                                            if (m == null) {
                                                h[w] = void 0;
                                                break
                                            } else if (!F(m, g.A)) throw Ea({
                                                L: k,
                                                W: l
                                            }, m, g.A, f);
                                            f.push(n);
                                            h[w] = d.yb(m, x, f);
                                            f.pop();
                                            break;
                                        case 2:
                                            if (m == null && g.defaultValue != null) {
                                                h[w] = g.defaultValue;
                                                break
                                            } else if (m == null || !F(m, g.A)) throw Fa({
                                                L: k,
                                                W: l
                                            }, m, g.A, f);
                                            f.push(n);
                                            h[w] = d.yb(m, x, f);
                                            f.pop();
                                            break;
                                        case 1:
                                            var t = x.Lb;
                                            n = x.Bc;
                                            if (m == null && g.xe) {
                                                h[w] = g.value;
                                                break
                                            }
                                            if (m === t) {
                                                h[w] = g.value;
                                                break
                                            }
                                            if (n != null && m === n) {
                                                h[w] = g.value;
                                                break
                                            }
                                            e = t;
                                            h = n;
                                            throw new TypeError(`Expected value ${h?`either "${e}" OR "${h}"`:`"${e}"`} for key ${Ga({L:k,W:l})} found: ${JSON.stringify(m)} ${G(f)}`);
                                        case 4:
                                            if (m == null) {
                                                h[w] = [];
                                                break
                                            } else if (!Array.isArray(m)) throw Ha({
                                                L: k,
                                                W: l
                                            }, m, g.A, f);
                                            t = Array(m.length);
                                            for (var q = 0; q < m.length; ++q) {
                                                if (!F(m[q], g.A)) throw Fa({
                                                    L: k,
                                                    W: l
                                                }, m[q], g.A, [...f, n], q);
                                                f.push(`${n}[${q}]`);
                                                t[q] = d.yb(m[q], x, f);
                                                f.pop()
                                            }
                                            h[w] =
                                                t;
                                            break;
                                        case 5:
                                            if (m == null) {
                                                h[w] = new Map;
                                                break
                                            } else if (typeof m !== "object") throw new TypeError(`Expected Map for key ${Ga({L:k,W:l})}, found: ${H(m)} ${G(f)}`);
                                            k = g.Ec === "number";
                                            m = Object.entries(m);
                                            l = Array(m.length);
                                            for (t = 0; t < m.length; ++t) {
                                                const [A, B] = m[t];
                                                if (k) {
                                                    if (q = Number(A), isNaN(q)) throw new TypeError(`Expected number map key, found: NaN ${G([...f,n])}`);
                                                } else q = A;
                                                if (!F(B, g.A)) throw new TypeError(`Expected ${g.A} map value for map key "${q}", found: ${H(B)} ${G([...f,n])}`);
                                                f.push(`${n}["${q}"]`);
                                                const M = d.yb(B, x, f);
                                                f.pop();
                                                l[t] = [q, M]
                                            }
                                            h[w] = new Map(l);
                                            break;
                                        default:
                                            throw new E(g);
                                    }
                                }
                                return h
                            }
                            constructor(e = {}) {
                                var {
                                    Bb: f
                                } = c();
                                for (const g of f) {
                                    f = g.config;
                                    const h = g.name,
                                        k = e[h];
                                    switch (f.K) {
                                        case 1:
                                            this[h] = f.value;
                                            break;
                                        case 2:
                                            this[h] = k == null ? f.default : k;
                                            break;
                                        case 3:
                                            this[h] = k;
                                            break;
                                        case 4:
                                            this[h] = k == null ? [] : k;
                                            break;
                                        case 5:
                                            this[h] = k == null ? new Map : k;
                                            break;
                                        default:
                                            throw new E(f);
                                    }
                                }
                            }
                        }
                        d.init = c;
                        d.lb = b.Ha ? (e, f) => {
                            throw new TypeError(`Unproducible oneof case ${G(f)}`);
                        } : (e, f) => {
                            if (e == null || typeof e !== "object") throw new TypeError(`Expected type object, found: ${H(e)} ${G(f)}`);
                            var {
                                Bb: g
                            } = c();
                            const h = {};
                            for (const m of g) {
                                g = m.config;
                                var k = m.L,
                                    l = e[m.name];
                                const t = k;
                                switch (g.K) {
                                    case 1:
                                        if (l !== g.value) throw new TypeError(`Expected value ${JSON.stringify(g.value)} for key "${k}", found: ${JSON.stringify(l)} ${G(f)}`);
                                        h[t] = m.Lb;
                                        break;
                                    case 2:
                                        if (g.defaultValue != null && l === g.defaultValue) break;
                                        f.push(t);
                                        var n = d.Qb(l, m, f);
                                        f.pop();
                                        if (!F(n, g.A)) throw Fa({
                                            L: k
                                        }, l, g.A, f);
                                        h[t] = n;
                                        break;
                                    case 3:
                                        if (l == null) break;
                                        f.push(t);
                                        n = d.Qb(l, m, f);
                                        f.pop();
                                        if (!F(n, g.A)) throw Ea({
                                            L: k
                                        }, l, g.A, f);
                                        h[t] = n;
                                        break;
                                    case 4:
                                        if (l == null) break;
                                        else {
                                            if (!Array.isArray(l)) throw Ha({
                                                L: k
                                            }, l, g.A, f);
                                            if (l.length === 0) break
                                        }
                                        n = Array(l.length);
                                        for (let q = 0; q < l.length; ++q) {
                                            f.push(`${t}[${q}]`);
                                            const x = d.Qb(l[q], m, f);
                                            f.pop();
                                            if (!F(x, g.A)) throw Fa({
                                                L: k
                                            }, x, g.A, [...f, t], q);
                                            n[q] = x
                                        }
                                        h[t] = n;
                                        break;
                                    case 5:
                                        if (!(l instanceof Map)) throw new TypeError(`Expected Map for key "${k}", found: ${H(l)} ${G(f)}`);
                                        if (l.size === 0) break;
                                        k = {};
                                        for (const [q, x] of l) {
                                            if (typeof q !== g.Ec) throw new TypeError(`Expected ${g.Ec} map key, found: ${H(q)} ${G([...f,
t])}`);
                                            f.push(`${t}["${q}"]`);
                                            l = d.Qb(x, m, f);
                                            f.pop();
                                            if (!F(l, g.A)) throw new TypeError(`Expected ${g.A} map value for map key "${q}", found: ${H(l)} ${G([...f,t])}`);
                                            k[q] = l
                                        }
                                        h[t] = k;
                                        break;
                                    default:
                                        throw new E(g);
                                }
                            }
                            return h
                        };
                        return d
                    },
                    J = function(a, b) {
                        var c = {};
                        const d = wa(() => {
                                var g = a();
                                const h = Object.keys(g)[0];
                                let k;
                                const l = new Map,
                                    n = new Map,
                                    m = new Map;
                                for (var t = 0; t < g[h].length; t += 2) {
                                    var q = g[h][t];
                                    const A = g[h][t + 1],
                                        B = A.init().Vc[h];
                                    if (!B) throw new TypeError("Missing discriminator.");
                                    if (B.K !== 1) throw new TypeError(`Discriminator must be FieldLabel.CONSTANT, was ${B.K}.}`);
                                    var x = Ia("A?", B.D, c.zb);
                                    const {
                                        aa: M,
                                        ua: fa
                                    } = Ia(Ja(q - 1), B.dd, c.zb);
                                    m.set(q, {
                                        lg: A,
                                        value: B.value
                                    });
                                    l.set(B.value, A);
                                    n.set(M, A);
                                    fa && n.set(fa, A);
                                    if (k && k.L !== x.aa) throw new TypeError(`oneOf JSON keys are not consistent. ${k.L} ${x.aa}`);
                                    if (k && k.W !== x.ua) throw new TypeError(`oneOf secondary JSON keys are not consistent. ${k.W} ${x.ua}`);
                                    q = B.tag;
                                    k = {
                                        L: x.aa,
                                        W: x.ua
                                    }
                                }
                                if (k == null || q == null) throw new TypeError("OneOf has no cases.");
                                g = b();
                                x = Object.keys(g);
                                t = {};
                                for (var w of x) t[g[w].tag] = { ...g[w],
                                    name: w
                                };
                                w = c.ve != null ?
                                    c.ve() : void 0;
                                return {
                                    kind: 2,
                                    Bb: Ba(g, c.zb),
                                    Ae: h,
                                    pf: l,
                                    Ng: q,
                                    ze: k,
                                    Nf: n,
                                    we: w,
                                    Vc: g,
                                    Ke: t,
                                    pe: {},
                                    Gi: m
                                }
                            }),
                            e = (g, h) => {
                                const {
                                    Ae: k,
                                    pf: l
                                } = d(), n = g[k], m = l.get(n);
                                if (!m) throw new TypeError(`Unknown oneof deserialized case: ${JSON.stringify(n)} ${G(h)}`);
                                return m.lb(g, h)
                            },
                            f = (g, h) => {
                                const {
                                    Nf: k,
                                    ze: l,
                                    we: n
                                } = d();
                                var m = l.W;
                                let t = g[l.L];
                                t == null && m && (t = g[m]);
                                if (t == null && n) return n.Ma(g, h);
                                m = k.get(t);
                                if (!m) throw new TypeError(`Unknown oneof serialized case: ${JSON.stringify(t)} ${G(h)}`);
                                return m.Ma(g, h)
                            };
                        return {
                            init: d,
                            va: g =>
                                e(g, []),
                            lb: e,
                            P: g => f(g, []),
                            Ma: f
                        }
                    },
                    K = function(a, b = 0) {
                        var c = {};
                        const d = wa(() => {
                                const g = a(),
                                    h = [],
                                    k = new Map,
                                    l = new Map,
                                    n = new Map,
                                    m = new Map,
                                    t = new Set;
                                let q = 0,
                                    x = 1;
                                for (; q < g.length;) {
                                    const A = x++,
                                        B = g[q];
                                    var w = Ja(B - b);
                                    q += 1;
                                    let M;
                                    const fa = g[q];
                                    typeof fa === "string" && (M = fa, q += 1);
                                    const {
                                        aa: Gb,
                                        ua: Hb
                                    } = Ia(w, M, c.zb);
                                    w = g[q];
                                    typeof w === "object" && w.Ha && (t.add(A), q += 1);
                                    h.push(A);
                                    k.set(Gb, A);
                                    Hb && k.set(Hb, A);
                                    l.set(A, Gb);
                                    n.set(A, B);
                                    m.set(B, A)
                                }
                                return {
                                    values: h,
                                    Fd: l,
                                    Wi: n,
                                    ii: m,
                                    Of: k,
                                    Ha: t.size ? t : void 0
                                }
                            }),
                            e = (g, h, k) => {
                                const {
                                    Ha: l
                                } =
                                d();
                                if (l && l.has(g)) throw new TypeError(`Unproducible enum value: ${JSON.stringify(g)} ${k?G(k):""}`);
                                h = h.get(g);
                                if (h == null) throw new TypeError(`The proto enum serializer failed to serialize value ${JSON.stringify(g)} into JSON.
It does not recognize value ${JSON.stringify(g)} as a valid member of the TypeScript enum.
${k?G(k):""}`);
                                return h
                            },
                            f = (g, h) => {
                                const k = d().Of.get(g);
                                if (k == null) throw new TypeError(`The proto enum deserializer failed to deserialize JSON ${JSON.stringify(g)} into an enum value.
It does not recognize JSON ${JSON.stringify(g)} as a valid JSON value encoding of the enum.
${G(h)}`);
                                return k
                            };
                        return {
                            values: () => d().values,
                            fi: () => {
                                const {
                                    values: g,
                                    Ha: h
                                } = d();
                                return h == null ? g : g.filter(k => !h.has(k))
                            },
                            va: g => e(g, d().Fd, []),
                            lb: (g, h) => e(g, d().Fd, h),
                            P: g => f(g, []),
                            Ma: f
                        }
                    },
                    Ba = function(a, b) {
                        return Object.entries(a).map(([c, d]) => {
                            let e = Ja(d.tag - 1);
                            if (d.K === 1) {
                                const {
                                    aa: k,
                                    ua: l
                                } = Ia(e, d.dd, b);
                                e = "A?";
                                var f = {
                                    Lb: k,
                                    Bc: l
                                }
                            }
                            const {
                                aa: g,
                                ua: h
                            } = Ia(e, d.D, b);
                            return {
                                config: d,
                                name: c,
                                L: g,
                                W: h,
                                Lb: f === null || f === void 0 ? void 0 : f.Lb,
                                Bc: f === null || f === void 0 ? void 0 : f.Bc
                            }
                        })
                    },
                    Ia = function(a, b, c) {
                        if (!b) {
                            if (c !==
                                void 0) throw Error("Dual Deserialization config templated but JSON full key/value wasn't");
                            return {
                                aa: a
                            }
                        }
                        if (c === void 0) return {
                            aa: b
                        };
                        if (c === 0) return {
                            aa: a,
                            ua: b
                        };
                        if (c === 1) return {
                            aa: b,
                            ua: a
                        };
                        throw Error("function should have been exhaustive, but wasn't");
                    },
                    Ha = function(a, b, c, d) {
                        return new TypeError(`Expected repeated ${c} value for key ${Ga(a)}, found: ${H(b)} ${G(d)}`)
                    },
                    Ea = function(a, b, c, d) {
                        return new TypeError(`Expected optional ${c} value for key ${Ga(a)}, found: ${H(b)} ${G(d)}`)
                    },
                    Fa = function(a, b, c,
                        d, e) {
                        return new TypeError(`Expected ${c} value${e!==void 0?` at index ${e}`:""} for key ${Ga(a)}, found: ${H(b)} ${G(d)}`)
                    },
                    Ga = function(a) {
                        const b = a.L;
                        return (a = a.W) ? `either "${b}" OR "${a}"` : `"${b}"`
                    },
                    G = function(a) {
                        return `(path: .${a.join(".")})`
                    },
                    H = function(a) {
                        return a === null ? "null" : Array.isArray(a) ? "array" : typeof a
                    },
                    Ja = function(a) {
                        if (a < 64) return "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a);
                        const b = [];
                        for (; a > 0;) b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a %
                            64)), a = Math.floor(a / 64);
                        return b.reverse().join("")
                    },
                    r = function(a, b, c) {
                        return typeof a === "string" ? {
                            D: a,
                            tag: b,
                            U: c,
                            md: void 0
                        } : {
                            tag: a,
                            U: b,
                            md: c
                        }
                    },
                    F = function(a, b) {
                        return typeof a === b || b === "Uint8Array" && typeof a === "string"
                    },
                    Ca = function(a) {
                        a = Array.from(a, b => String.fromCodePoint(b)).join("");
                        return btoa(a)
                    },
                    Da = function(a) {
                        return Uint8Array.from(atob(a), b => b.codePointAt(0))
                    },
                    Oa = async function(a, b) {
                        const c = Ka(a.ob),
                            d = a.l.na(b.request.mode === "navigate" ? "intercept_fetch.navigate" : "intercept_fetch.other", {
                                startTime: c
                            });
                        La(a.ra, b);
                        try {
                            await a.l.Ob("handle_request", d, () => {
                                const e = Ma(a.requestHandler, b, d);
                                e != null ? (b.request.mode === "navigate" && Na(a.ra, b, e), b.respondWith(e)) : (d.abort(), a.l.na("intercept_fetch.unhandled", {
                                    startTime: c
                                }).end());
                                return e
                            })
                        } finally {
                            d.end()
                        }
                    },
                    Pa = function(a, b, c) {
                        b = new Headers([
                            ["X-serviceworker-error-navigation-url", b],
                            ["X-serviceworker-error-code", JSON.stringify(c)]
                        ]);
                        try {
                            fetch(a.bb, {
                                headers: b
                            })
                        } catch (d) {}
                    },
                    Qa = function(a) {
                        return a != null
                    },
                    Sa = function(a, b, c) {
                        return b != null && typeof b === "object" &&
                            b.sampleRate != null && b instanceof Error ? Ra(b.sampleRate) : c === "error" || c === "fatal" ? a.Pc : a.Oc
                    },
                    Ra = function(a) {
                        return Math.min(Math.max(0, a), 1)
                    },
                    Ta = async function(a, b) {
                        b = [
                            ["requestUrl", b]
                        ];
                        if (a instanceof Error && /quota/i.test(a.message)) {
                            var c, d;
                            (a = await ((d = navigator.storage) === null || d === void 0 ? void 0 : (c = d.estimate) === null || c === void 0 ? void 0 : c.call(d))) && b.push(...Object.entries(a))
                        }
                        return new Map(b)
                    },
                    Ua = async function(a, b, c) {
                        const d = new L(b instanceof Error ? b.message : String(b), .01);
                        try {
                            const e = await Ta(b,
                                    c.url),
                                f = new Map([
                                    ["requestMode", c.mode],
                                    ["requestOrigin", (new URL(c.url)).origin]
                                ]);
                            a.j.error(d, {
                                extra: e,
                                tags: f
                            })
                        } catch (e) {
                            a.j.error(d)
                        }
                    },
                    Xa = function({
                        C: {
                            j: a
                        },
                        bb: b
                    }) {
                        const c = b != null ? new Va({
                                bb: b
                            }) : null,
                            d = new Wa(a);
                        return {
                            $e: (e, f) => {
                                f.then(g => {
                                    e.mode !== "navigate" || g.ok || c === null || c === void 0 || Pa(c, e.url, g.status)
                                }).catch(g => {
                                    Ua(d, g, e);
                                    e.mode !== "navigate" || c !== null && c !== void 0 && Pa(c, e.url, -1)
                                })
                            }
                        }
                    },
                    Ma = function(a, b, c) {
                        try {
                            const d = a.yc.resolve(b.request);
                            if (d == null) return a.B.Pa() ? Promise.resolve(Response.error()) :
                                void 0;
                            c.setAttribute("handler_name", d.name);
                            const e = d.handle(b, c);
                            a.Fe.$e(b.request, e);
                            return e.then(f => a.Kf.Dd(f)).catch(() => a.qf.Xe(b.request))
                        } catch (d) {
                            a.j.error(new L(d instanceof Error ? d.message : String(d), .01))
                        }
                    },
                    $a = function() {
                        ({
                            userAgent: a
                        } = {
                            userAgent: self.navigator.userAgent
                        });
                        var a;
                        return a.includes("Firefox") ? new Ya : new Za
                    },
                    ab = function(a) {
                        return new Promise(b => setTimeout(b, a))
                    },
                    bb = function(a) {
                        const b = Error(a);
                        return c => {
                            c instanceof Error && (c.stack == null || c.stack === "") && (c.stack = b.stack);
                            return c
                        }
                    },
                    cb = function(a) {
                        return new Promise((b, c) => {
                            const d = () => {
                                    a.removeEventListener("success", e);
                                    a.removeEventListener("error", g)
                                },
                                e = () => {
                                    d();
                                    b(a.result)
                                },
                                f = bb("idb promisify_request_events error"),
                                g = () => {
                                    d();
                                    c(f(a.error))
                                };
                            a.addEventListener("success", e);
                            a.addEventListener("error", g)
                        })
                    },
                    db = async function(a, b) {
                        const c = a.J(a.cursor.request);
                        a.cursor.continue(b);
                        return c
                    },
                    fb = function(a) {
                        return new Promise((b, c) => {
                            const d = bb("idb_transaction error");
                            a.Y.addEventListener("complete", () => b());
                            a.Y.addEventListener("error",
                                f => {
                                    f = f.target;
                                    c(d((f === null || f === void 0 ? void 0 : f.error) || a.Y.error || Error("Unknown error")))
                                });
                            const e = new eb;
                            a.Y.addEventListener("abort", () => {
                                if (a.Y.error instanceof Error) {
                                    var f = e.cause = a.Y.error;
                                    f = [`${f.name}`, `${f.message}`].filter(g => !!g).join(": ");
                                    e.message = `${e.message} (${f})`
                                }
                                c(e)
                            })
                        })
                    },
                    hb = function({
                        name: a,
                        version: b,
                        wf: c,
                        Xd: d
                    }) {
                        var e = indexedDB;
                        return new Promise((f, g) => {
                            try {
                                const h = e.open(a, b);
                                let k, l = !1;
                                c && h.addEventListener("upgradeneeded", m => {
                                    l || (k = new gb(h.result), c(k, m))
                                });
                                switch (d.type) {
                                    case 0:
                                        d.uf &&
                                            h.addEventListener("blocked", d.uf);
                                        h.addEventListener("success", () => {
                                            f(k !== null && k !== void 0 ? k : new gb(h.result))
                                        });
                                        break;
                                    case 1:
                                        h.addEventListener("blocked", () => {
                                            l = !0;
                                            g(Error("operation blocked due to open connections"))
                                        });
                                        h.addEventListener("success", () => {
                                            const m = h.result;
                                            l ? m.close() : (m.addEventListener("versionchange", t => {
                                                (d.ke && t.newVersion == null || d.le && t.newVersion != null) && m.close()
                                            }), f(k !== null && k !== void 0 ? k : new gb(m)))
                                        });
                                        break;
                                    default:
                                        throw new E(d);
                                }
                                const n = bb("idb_database open error");
                                h.addEventListener("error",
                                    () => {
                                        g(n(h.error))
                                    })
                            } catch (h) {
                                g(h)
                            }
                        })
                    },
                    kb = function(a) {
                        if (!(a instanceof Error)) return !1;
                        if (a.name === "QuotaExceededError" || a instanceof DOMException && a.code === 22 || a instanceof ib) return !0;
                        jb == null && (jb = [/Encountered full disk while opening backing store for indexedDB.open./i, /Failed to PutOrAdd in database because not enough space for domain/i]);
                        return jb.some(b => b.test(a.message))
                    },
                    nb = function(a) {
                        if (!self.indexedDB) return !0;
                        if (!(a instanceof Error)) return !1;
                        if (a instanceof lb || a instanceof eb || a instanceof DOMException && ["AbortError", "TransactionInactiveError"].includes(a.name)) return !0;
                        mb == null && (mb = [/(transaction|operation) was aborted/i, /The database connection is closing/i, /connection to indexed database server lost/i, /internal error/i, /the transaction is inactive or finished/i, /unable to open database file on disk/i, /without an in-progress transaction/i]);
                        return mb.some(b => b.test(a.message))
                    },
                    pb = async function(a, b) {
                        const c = await a.xf(),
                            d = () => {
                                e.connection = void 0;
                                c.removeEventListener("close", d)
                            };
                        c.addEventListener("close", d, {
                            once: !0
                        });
                        const e = new ob({
                            transaction: (f, g) => c.transaction(f, g),
                            close: () => {
                                d();
                                c.close();
                                b()
                            }
                        });
                        e.ub = self.setTimeout(() => {
                            e.dispose()
                        }, 2500);
                        return e
                    },
                    qb = async function(a, {
                        G: b
                    }) {
                        var c;
                        const d = b != null ? (c = a.l) === null || c === void 0 ? void 0 : c.oa("idb_connection_manager.open_idb_connection", b) : void 0,
                            e = pb(a.Ze, () => {
                                a.connection === e && (a.connection = void 0)
                            }).catch(f => {
                                a.connection = void 0;
                                d === null || d === void 0 || d.setStatus("error");
                                throw f;
                            }).finally(() => d === null || d === void 0 ? void 0 :
                                d.end());
                        return e
                    },
                    rb = async function(a, b, {
                        G: c
                    }) {
                        var d;
                        const e = c != null ? (d = a.l) === null || d === void 0 ? void 0 : d.oa("idb_connection_manager.get_connection", c) : void 0;
                        try {
                            if (a.connection == null || (b === null || b === void 0 ? 0 : b.Oe)) a.connection = qb(a, {
                                G: c
                            });
                            let f = await a.connection;
                            f.cf || (a.connection = qb(a, {
                                G: c
                            }), f = await a.connection);
                            return f
                        } catch (f) {
                            throw e === null || e === void 0 || e.setStatus("error"), f;
                        } finally {
                            e === null || e === void 0 || e.end()
                        }
                    },
                    sb = async function({
                        transaction: a,
                        H: b,
                        V: c
                    }) {
                        try {
                            const e = await c(a.objectStore(b));
                            try {
                                var d;
                                a === null || a === void 0 || (d = a.commit) === null || d === void 0 || d.call(a)
                            } catch (f) {}
                            return e
                        } catch (e) {
                            try {
                                a === null || a === void 0 || a.abort()
                            } catch (f) {}
                            throw e;
                        }
                    },
                    N = async function(a, {
                        H: b,
                        mode: c,
                        V: d,
                        methodName: e
                    }) {
                        var f;
                        const g = (f = a.l) === null || f === void 0 ? void 0 : f.kf({
                            methodName: e
                        });
                        try {
                            try {
                                const k = (await rb(a.Yc, {}, {
                                        G: g
                                    })).transaction(b, c),
                                    [l] = await Promise.all([sb({
                                        transaction: k.transaction,
                                        H: b,
                                        V: d
                                    }), k.Id]);
                                return l
                            } catch (k) {
                                const l = (await rb(a.Yc, {
                                        Oe: !0
                                    }, {
                                        G: g
                                    })).transaction(b, c),
                                    [n] = await Promise.all([sb({
                                        transaction: l.transaction,
                                        H: b,
                                        V: d
                                    }), l.Id]);
                                return n
                            }
                        } catch (k) {
                            a = k;
                            var h = a instanceof Error ? kb(a) ? new ib(a) : nb(a) ? new lb(a) : a : Error(String(a));
                            h instanceof tb || h instanceof ub || h instanceof vb || h instanceof ib || (g === null || g === void 0 || g.setAttribute("error", k instanceof Error ? k.message : String(k)), g === null || g === void 0 || g.end("error"));
                            throw h;
                        } finally {
                            g === null || g === void 0 || g.end("ok")
                        }
                    },
                    zb = function(a, b, c, d = [], e) {
                        return new wb(a, b, new xb(new yb({
                            xf: () => hb({
                                name: a,
                                version: 1,
                                wf: f => {
                                    f = f.createObjectStore(a, {
                                        keyPath: "key"
                                    });
                                    if (d !=
                                        null && d.length > 0)
                                        for (const {
                                                name: g,
                                                Cb: h,
                                                ...k
                                            } of d) f.createIndex(g, `${"record"}.${h}`, k)
                                },
                                Xd: {
                                    type: 1,
                                    ke: !0,
                                    le: !0
                                }
                            })
                        }, e), e != null ? {
                            kf: ({
                                methodName: f
                            }) => {
                                if (!(e == null || Math.random() > .01)) return e.na(`storage_layer.idb_database_manager.execute.${f}`, {
                                    attrs: new Map([
                                        ["sample_rate_override", 1]
                                    ]),
                                    timeout: 3E5
                                })
                            }
                        } : void 0), c)
                    },
                    Ab = function(a, b, c, d, e) {
                        return zb(a, b, c, d, e)
                    },
                    Bb = async function(a) {
                        if (a.xb != null) switch (a = await a.xb.hc(), a) {
                            case 1:
                                break;
                            case 2:
                            case 3:
                            case void 0:
                                throw new tb;
                            default:
                                throw new E(a);
                        }
                    },
                    Eb = async function(a, b, c) {
                        await Bb(a);
                        return N(a.ia, {
                            H: a.H,
                            mode: "readwrite",
                            V: async d => {
                                await Promise.all(b.map(async e => {
                                    var f = await d.get(e);
                                    f = f ? {
                                        value: a.P(Cb(f))
                                    } : void 0;
                                    f = c(f, e);
                                    f != null ? await d.put(Db(e, a.Rb.va(f.value))) : await d.delete(e)
                                }))
                            },
                            methodName: "updateMany"
                        })
                    },
                    Db = function(a, b) {
                        return {
                            key: a,
                            record: b
                        }
                    },
                    Fb = function(a) {
                        if (typeof a !== "object" || a == null) throw Error("Result is not an object");
                        a = a.key;
                        if (typeof a !== "string") throw Error("Key is not a string");
                        return a
                    },
                    Cb = function(a) {
                        if (typeof a !==
                            "object" || a == null) throw Error("Result is not an object");
                        a = a.record;
                        if (a == null) throw Error("Value is undefined");
                        return a
                    },
                    Jb = async function(a) {
                        return Promise.race([(async () => {
                            try {
                                return await Ib().get("userAgent")
                            } catch (b) {
                                a.F(b)
                            }
                        })(), ab(1E4).then(() => {})])
                    },
                    Ib = function() {
                        return zb("config", {
                            va: a => a,
                            P: a => a
                        })
                    },
                    Kb = async function(a, b) {
                        const c = await a.Df.Se();
                        if (c == null || c === a.options.Rf || (new URL(b.url)).origin !== a.options.targetOrigin) return b;
                        a = b.clone();
                        a.headers.set("X-Canva-User-Agent", c);
                        return a
                    },
                    Nb = function({
                        ga: a,
                        B: b,
                        C: {
                            j: c
                        }
                    }) {
                        return new Lb(b, a ? new Mb({
                            Se: () => Jb(c)
                        }) : void 0, (...d) => self.fetch(...d))
                    },
                    Ob = function({
                        H: a,
                        ca: b,
                        ea: c
                    }) {
                        return `${b}-${c}-${a}`
                    },
                    Pb = function(a, b, c) {
                        return a.fd.Ca(b, c, void 0, a.Zc[b], a.l)
                    },
                    Rb = function(a, b) {
                        var c = Qb;
                        const d = a.Ic.ca,
                            e = a.Ic.ea,
                            f = Ob({
                                H: b,
                                ca: d,
                                ea: e
                            });
                        a.Vf.put(f, {
                            ca: d,
                            ea: e
                        }).catch(g => a.j.F(g));
                        return a.fd.Ca(f, c, a.ne[b] ? {
                            hc: async () => a.xb.hc(d)
                        } : void 0, a.Zc[b], a.l)
                    },
                    Vb = function(a) {
                        const b = new Sb(void 0),
                            c = new Tb(void 0);
                        return new Ub(void 0, b, c, a, void 0)
                    },
                    Wb =
                    function(a) {
                        return self.navigator.locks ? self.navigator.locks.request("page_preloader_lock", a) : a()
                    },
                    $b = async function(a) {
                        async function b(k, l, n, m = "js") {
                            n && (l = m === "js" ? l + `\n//# sourceMappingURL=${n}` : l + `\n/*# sourceMappingURL=${n}*/`);
                            if (n = k.match(/^([0-9a-fA-F]{16,}).*$/))
                                if ([, n] = n, m = (new TextEncoder).encode(l.replace(new RegExp(n, "g"), "")), await Xb(m) !== n) throw Error(`The file named ${k} doesn't match its content hash.`);
                            h.push({
                                fileName: k,
                                content: l
                            })
                        }
                        if (!Xb) {
                            var {
                                kg: c
                            } = await __webpack_require__.me(536633).then(() =>
                                ({
                                    kg: __c.Yb
                                }));
                            Xb = c
                        }
                        if (c = Zb(a)) a = c.re;
                        const d = /(?:\n|^)(?:;\/\/|\/\*) __FILE_CONTENT_FOR__:(.*?)(?: \*\/)?\n/gm;
                        let e, f, g = "";
                        const h = [];
                        for (; e = d.exec(a);) g && await b(g, a.slice(f, e.index), c === null || c === void 0 ? void 0 : c.yd.shift(), c === null || c === void 0 ? void 0 : c.Wc), g = e[1], f = d.lastIndex;
                        g && await b(g, a.slice(f, a.endsWith("\n") ? a.length - 1 : void 0), c === null || c === void 0 ? void 0 : c.yd.shift(), c === null || c === void 0 ? void 0 : c.Wc);
                        return h
                    },
                    Zb = function(a) {
                        var b = a.endsWith("\n") ? a.length - 1 : a.length;
                        const c = a.lastIndexOf("\n",
                            b);
                        if (b = a.slice(c + 1, b).match(/\/(\/|\*)# sourceMappingURL=.*\/chunk-batch-sm\/(.*?)(?: \*\/)?$/)) {
                            var [, d, e] = b;
                            b = d === "/" ? "js" : "css";
                            return {
                                yd: e.split("+").map(f => f.split("_")[1]),
                                Wc: b,
                                re: a.slice(0, c)
                            }
                        }
                    },
                    bc = async function(a, {
                        urls: b,
                        Jf: c
                    }) {
                        const d = [];
                        await Eb(a.db, b, (e, f) => {
                            e = e === null || e === void 0 ? void 0 : e.value;
                            e == null && (e = new ac({
                                vc: [],
                                Oa: !1,
                                Eb: void 0
                            }));
                            e.Oa === !1 && d.push(f);
                            e.Kc.add(c);
                            e.Eb = Date.now();
                            return {
                                value: e
                            }
                        });
                        return {
                            dg: d
                        }
                    },
                    cc = async function(a, b, c) {
                        await a.db.update(b, d => {
                            d = d === null || d ===
                                void 0 ? void 0 : d.value;
                            d == null && (d = new ac({
                                vc: [],
                                Oa: !1,
                                Eb: Date.now()
                            }));
                            d.Oa = !0;
                            return {
                                value: d
                            }
                        });
                        try {
                            await (await a.fc()).put(b, c)
                        } catch (d) {
                            throw a.db.update(b, e => {
                                e = e === null || e === void 0 ? void 0 : e.value;
                                if (e != null) return e.Oa = !1, {
                                    value: e
                                }
                            }).catch(() => {}), d;
                        }
                    },
                    dc = async function(a, b, c) {
                        if (b.ok) {
                            var d = await b.clone().text(),
                                e = [];
                            try {
                                e = (await a.l.Nb("chunk_composing_route.extractFilesFromBatchContent", c, async () => a.je.Ie(d))).map(({
                                    fileName: f,
                                    content: g
                                }) => ({
                                    url: `${a.N}/${f}`,
                                    response: new Response(g, {
                                        headers: b.headers
                                    })
                                }))
                            } catch (f) {
                                a.j.F(f);
                                return
                            }
                            try {
                                await a.l.Nb("chunk_composing_route.cache_chunks", c, async () => a.ge.fe(e))
                            } catch (f) {
                                a.j.F(f)
                            }
                        }
                    },
                    gc = function({
                        N: a,
                        B: b,
                        I: c,
                        C: d
                    }) {
                        const e = {
                                Ie: $b
                            },
                            f = Vb(d.j),
                            g = new ec(f, d.l);
                        return {
                            ie: new fc(b, a, c, {
                                fe: async h => {
                                    await Wb(async () => {
                                        const k = new Map(h.map(({
                                                url: n,
                                                response: m
                                            }) => [n, m])),
                                            {
                                                dg: l
                                            } = await bc(g, {
                                                urls: [...k.keys()],
                                                Jf: ""
                                            });
                                        for (const n of l) {
                                            if (!k.has(n)) throw Error(`Response for ${n} not found`);
                                            await cc(g, n, k.get(n))
                                        }
                                    })
                                }
                            }, e, d.j, d.l)
                        }
                    },
                    ic = async function(a, b, c) {
                        c = await a.mf.match(b.request.url, {
                            G: c
                        });
                        return c == null ? null : a.Mb != null && b.request.headers.has("range") ? hc(a.Mb, b.request, c) : c
                    },
                    jc = function({
                        start: a,
                        end: b,
                        Wd: c
                    }) {
                        p(a == null || a >= 0, "Range start and end must be within the bounds of the blob");
                        p(b == null || b <= c, "Range start and end must be within the bounds of the blob");
                        if (a != null && b != null) return {
                            start: a,
                            end: b + 1
                        };
                        if (a != null && b == null) return {
                            start: a,
                            end: c
                        };
                        if (a == null && b != null) return {
                            start: c - b,
                            end: c
                        };
                        throw Error(`Invalid range. Start: ${a}, end: ${b}`);
                    },
                    hc = async function(a, b, c) {
                        try {
                            const e =
                                b.headers.get("range");
                            if (e == null) throw Error("Range header is required");
                            const f = await c.blob();
                            var d;
                            const [, g, h] = (d = kc.exec(e)) !== null && d !== void 0 ? d : [];
                            if (g == null && h == null) throw Error(`invalid-range-header: ${e}`);
                            const {
                                start: k,
                                end: l
                            } = {
                                start: g == null ? void 0 : Number(g),
                                end: h == null ? void 0 : Number(h)
                            }, n = jc({
                                start: k,
                                end: l,
                                Wd: f.size
                            }), m = f.slice(n.start, n.end), t = m.size, q = new Response(m, {
                                status: 206,
                                headers: c.headers
                            });
                            q.headers.set(...lc);
                            q.headers.set("Content-Length", t.toString());
                            q.headers.set("Content-Range",
                                `bytes ${n.start}-${n.end-1}/${f.size}`);
                            return q
                        } catch (e) {
                            return a.j.F(e), new Response("", {
                                status: 416
                            })
                        }
                    },
                    nc = function({
                        j: a
                    }) {
                        return {
                            Mb: new mc({
                                j: a
                            })
                        }
                    },
                    qc = function({
                        B: a,
                        ha: b,
                        C: {
                            j: c,
                            l: d
                        },
                        I: e
                    }) {
                        d = new oc({
                            cacheName: "media",
                            Hc(f) {
                                const {
                                    origin: g,
                                    pathname: h
                                } = new URL(f);
                                return g + h
                            }
                        }, c, d);
                        ({
                            Mb: b
                        } = b ? nc({
                            j: c
                        }) : {});
                        return {
                            ye: new pc(a, d, b, e)
                        }
                    },
                    sc = function({
                        N: a,
                        C: {
                            j: b,
                            l: c
                        },
                        B: d,
                        I: e
                    }) {
                        return {
                            Af: new rc({
                                N: a
                            }, d, e, new oc({
                                cacheName: "assets-2"
                            }, b, c))
                        }
                    },
                    uc = function(a) {
                        p(a.length > 0);
                        p(a.every(b => b.indexOf("?") < 0));
                        return new tc(["",
                            ...a.map(encodeURIComponent)
                        ].join("/"))
                    },
                    vc = function(a, b) {
                        p(!0);
                        p(!a.Sa.has("ui"));
                        if (b != null)
                            if (Array.isArray(b)) {
                                b = b.filter(Qa);
                                if (b.length === 0) return a;
                                p(b.every(c => typeof c === "number" || typeof c === "string"));
                                a.Sa.set("ui", b)
                            } else if (typeof b === "boolean") a.Sa.set("ui", b || String(b));
                        else if (typeof b === "number" || typeof b === "string") a.Sa.set("ui", String(b));
                        else throw Error(`invalid param value type: ${typeof b}`);
                        return a
                    },
                    wc = function(a) {
                        if (a.Sa.size === 0) return a.path;
                        const b = Array.from(a.Sa.entries()).map(([c,
                            d
                        ]) => d === !0 ? `${encodeURIComponent(c)}` : Array.isArray(d) ? d.map(e => `${encodeURIComponent(c)}=${encodeURIComponent(e)}`).join("&") : `${encodeURIComponent(c)}=${encodeURIComponent(d)}`).join("&");
                        return `${a.path}?${b}`
                    },
                    xc = function(a) {
                        a = /design\/(D[a-zA-Z0-9_-]{10})\/?([a-zA-Z0-9_-]+)?/g.exec(a);
                        if (!(a == null || a.length < 2)) {
                            var b = a[2];
                            (new Set(["edit", "remix", "view", "watch"])).has(a[2]) && (b = void 0);
                            return {
                                id: a[1],
                                rh: b
                            }
                        }
                    },
                    zc = function({
                        C: {
                            pb: a
                        }
                    }) {
                        a = Rb(a, "homepage_bootstraps");
                        return new yc({
                            mb: !1
                        }, a)
                    },
                    Ac =
                    function({
                        C: {
                            pb: a
                        }
                    }) {
                        a = Rb(a, "editor_page_bootstraps");
                        return new yc({
                            mb: !1
                        }, a, {
                            normalizeUrl: b => {
                                var c = ia(xc(b), `Attempted to load editor bootstrap with invalid url ${b}`);
                                b = location.origin;
                                c = {
                                    id: c.id
                                };
                                var d = uc(["design", c.id]);
                                c = wc(vc(d, c.Mi));
                                return b + c
                            }
                        })
                    },
                    Bc = function({
                        C: {
                            pb: a
                        }
                    }) {
                        a = Pb(a, "offline_fallback_bootstrap", Qb);
                        return new yc({
                            mb: !0
                        }, a)
                    },
                    Cc = function({
                        jc: a
                    }) {
                        return {
                            eb: async b => {
                                const c = await a();
                                if (c != null) return zc({
                                    C: {
                                        pb: c
                                    }
                                }).eb(b)
                            }
                        }
                    },
                    Dc = function({
                        jc: a
                    }) {
                        return {
                            eb: async b => {
                                const c = await a();
                                if (c != null) return Ac({
                                    C: {
                                        pb: c
                                    }
                                }).eb(b)
                            }
                        }
                    },
                    Ec = function({
                        S: a,
                        gf: b
                    }) {
                        return a.app === b.Fb.app && a.locale === b.locale
                    },
                    Fc = function({
                        app: a,
                        commit: b
                    }) {
                        return `${a}-${b}`
                    },
                    Gc = async function(a, b, c, d, e) {
                        b = Fc({
                            app: b,
                            commit: c
                        });
                        let f;
                        try {
                            f = await a.db.get(b)
                        } catch (g) {
                            if (g instanceof ub) {
                                a.db.delete(b);
                                return
                            }
                            throw g;
                        }
                        if (a = f != null) a = f, a.variant !== d ? a = !1 : (d = Date.now() / 1E3, a = (e === null || e === void 0 || !e.mb) && a.timestamp + 1209600 < d ? !1 : !0);
                        if (a) return f
                    },
                    Ic = async function(a, b, c) {
                        b = await ia(a.Yd.get(b)).eb(c);
                        if (b != null) {
                            var d =
                                Hc.P(JSON.parse(b.xa));
                            a = await Gc(a.hf, b.app, d.commit, d.ee, {
                                mb: c.href === a.options.T
                            });
                            if (a != null && Ec({
                                    S: b,
                                    gf: a
                                })) return {
                                xa: d,
                                kb: b,
                                Fb: a.Fb,
                                Cc: a.Cc
                            }
                        }
                    },
                    Oc = function({
                        T: a,
                        C: {
                            l: b,
                            j: c
                        }
                    }) {
                        const d = Vb(c);
                        var e = async () => {
                                var h = await Pb(d, "active_user_brand_hint_for_service_worker_to_serve_pages", Jc).get("active");
                                if (h != null) {
                                    const k = new Sb(void 0),
                                        l = new Tb(void 0);
                                    h = new Kc(h, k, l, c, void 0)
                                } else h = void 0;
                                return h
                            },
                            f = Cc({
                                jc: e
                            });
                        e = Dc({
                            jc: e
                        });
                        const g = Bc({
                            C: {
                                pb: d
                            }
                        });
                        f = new Map([
                            ["home", f],
                            ["editor", e],
                            ["offline_fallback",
                                g
                            ]
                        ]);
                        e = Pb(d, "manifests", Lc);
                        return new Mc({
                            T: a
                        }, f, new Nc(e, b))
                    },
                    Pc = function(a, b) {
                        const c = b.pathname;
                        if (c[0] !== "/") return a.fallback;
                        for (const d of a.rules)
                            if (d.match(c)) return {
                                page: d.page,
                                gb: e => d.gb(b, e)
                            };
                        return a.fallback
                    },
                    O = function(a, {
                        Ah: b,
                        ed: c
                    } = {}) {
                        const d = new RegExp(a === "/" ? "^/$" : `^${a.replaceAll("*","[^/]+")}/?$`);
                        return {
                            page: "home",
                            match: e => d.test(e),
                            gb: (e, f) => {
                                switch (f) {
                                    case 0:
                                        return new URL(b !== null && b !== void 0 ? b : "/", self.location.origin);
                                    case 1:
                                        return new URL(c !== null && c !== void 0 ? c : e, self.location.origin);
                                    default:
                                        throw new E(f);
                                }
                            }
                        }
                    },
                    Qc = function() {
                        return {
                            page: "editor",
                            match: a => xc(a) != null,
                            gb: a => a
                        }
                    },
                    Rc = function() {
                        return {
                            page: "offline_fallback",
                            gb: () => new URL("/_offline-fallback", self.location.origin)
                        }
                    },
                    Sc = function(a) {
                        let b;
                        try {
                            b = a.crypto.randomUUID()
                        } catch (c) {
                            b = a.crypto.getRandomValues(new Uint8Array(16)).reduce((d, e) => d + String.fromCharCode(e), "")
                        }
                        return btoa(b)
                    },
                    Tc = function(a) {
                        var b;
                        var c = '<!DOCTYPE html>\n<html dir="' + ((b = a.direction) == null ? "" : b) + '" lang="' + ((b = a.locale) == null ? "" : b) + '">\n  <head>\n    <meta http-equiv="Content-type" content="text/html; charset=utf-8"/>\n    <meta name="referrer" content="origin">\n    ';
                        a.viewport && (c += '\n      <meta name="viewport" content="' + ((b = a.viewport) == null ? "" : b) + '">\n    ');
                        c += '\n    <link rel="shortcut icon" href="/favicon.ico">\n    <title>' + ((b = a.title) == null ? "" : b) + '</title>\n    <script nonce="' + ((b = a.nonce) == null ? "" : b) + '">\n      window["bootstrap"] = {\n        "ui": JSON.parse(' + ((b = a.Fc) == null ? "" : b) + '),\n        "base": JSON.parse(' + ((b = a.xa) == null ? "" : b) + '),\n        "page": JSON.parse(' + ((b = a.kb) == null ? "" : b) + '),\n      };\n      window["flags"] = JSON.parse(' + ((b =
                            a.dc) == null ? "" : b) + ');\n      window["__canva_public_path__"] = "' + ((b = a.Gf) == null ? "" : b) + '";\n      window["cmsg"] = {\n        locale: "' + ((b = a.locale) == null ? "" : b) + '",\n        strings: {},\n      };\n    \x3c/script>\n    ';
                        for (const d of a.links) c += '\n      <link href="' + ((b = d.href) == null ? "" : b) + '" rel="' + ((b = d.rel) == null ? "" : b) + '" ' + ((b = d.nonce ? `nonce="${d.nonce}"` : "") == null ? "" : b) + ">\n    ";
                        c += '\n  </head>\n  <body>\n    <div id="root">' + ((b = a.tc) == null ? "" : b) + "</div>\n    ";
                        for (const d of a.scripts) c +=
                            '\n      <script src="' + ((b = d.src) == null ? "" : b) + '" nonce="' + ((b = d.nonce) == null ? "" : b) + '" ' + ((b = d.defer ? "defer" : "") == null ? "" : b) + ">\x3c/script>\n    ";
                        return c + "\n  </body>\n</html>\n"
                    },
                    Uc = function(a, b) {
                        const c = [];
                        var d = a.Rc;
                        d.config.O === 3 && /android/i.test(d.config.userAgent) ? c.push(...b.vd.Hd.Rd.Ba) : (a = a.Rc, a.config.O === 3 && /ipod|iphone|ipad/i.test(a.config.userAgent) && c.push(...b.vd.Hd.bf.Ba));
                        c.push(...b.Mc.Ba);
                        return c
                    },
                    Vc = function(a, b, c, d, e) {
                        const f = b.locale,
                            g = b.direction,
                            h = b.title,
                            k = b.Fc,
                            l = b.xa,
                            n = b.kb;
                        b = b.dc;
                        const m = c.viewport,
                            t = c.tc;
                        var q = c.Mc;
                        const x = c.df.get(f) || {
                            Ya: [],
                            Ba: []
                        };
                        q = [...c.links.filter(({
                            rel: w
                        }) => w !== "preload" && w !== "prefetch").map(w => ({
                            href: /^(https?:)?\/\//.test(w.href) ? w.href : `${d}/${w.href}`,
                            rel: w.rel,
                            nonce: e
                        })), ...x.Ya.map(w => ({
                            href: `${d}/${w}`,
                            rel: "stylesheet"
                        })), ...q.Ya.map(w => ({
                            href: `${d}/${w.filename}`,
                            rel: "stylesheet"
                        }))];
                        a = [...x.Ba.map(w => ({
                            src: `${d}/${w}`,
                            nonce: e
                        })), ...Uc(a, c).map(w => ({
                            src: `${d}/${w.filename}`,
                            nonce: e,
                            defer: !0
                        }))];
                        return Tc({
                            locale: f,
                            direction: g ===
                                1 ? "ltr" : "rtl",
                            title: h,
                            viewport: m,
                            nonce: e,
                            Gf: d ? `${d}/` : "",
                            Fc: JSON.stringify(k),
                            xa: JSON.stringify(l),
                            kb: JSON.stringify(n),
                            dc: JSON.stringify(b || "{}"),
                            links: q,
                            tc: t !== null && t !== void 0 ? t : "",
                            scripts: a
                        })
                    },
                    Wc = async function(a, b, {
                        G: c
                    }) {
                        c = a.l.oa("service_worker.page_assembler.render_page", c);
                        try {
                            const k = Pc(a.Mf, b);
                            let l = await Ic(a.od, k.page, k.gb(0));
                            l == null && (l = await Ic(a.od, "offline_fallback", new URL(a.config.T)));
                            if (l != null) {
                                var d = { ...l.kb
                                };
                                const n = Hc.va({ ...l.xa,
                                    $c: 2,
                                    timestamp: void 0
                                });
                                var e = JSON.stringify(n);
                                b = { ...d,
                                    xa: e
                                };
                                var f = Sc(a.sf),
                                    g = Vc(a.tf, b, l.Fb, l.Cc, f),
                                    h = a.qe.createPolicy({
                                        page: k.page,
                                        nonce: f
                                    });
                                return new Response(g, {
                                    headers: {
                                        "content-type": "text/html;charset=utf-8",
                                        "content-security-policy-report-only": h,
                                        "X-Offline-Response": "true"
                                    }
                                })
                            }
                        } catch (k) {
                            c.setStatus("error"), a.j.F(k)
                        } finally {
                            c.end()
                        }
                    },
                    ad = function({
                        T: a,
                        userAgent: b,
                        O: c,
                        C: {
                            j: d,
                            l: e
                        }
                    }) {
                        var f = [O("/"), O("/settings", {
                                ed: "/settings"
                            }), O("/settings/*", {
                                ed: "/settings"
                            }), O("/folder"), O("/folder/*"), O("/folder/*/designs"), O("/folder/*/designs/*"),
                            O("/folder/*/images"), O("/folder/*/images/*"), O("/folder/*/videos"), O("/folder/*/videos/*"), O("/folder/*/templates"), O("/folder/*/templates/*"), O("/your-projects"), O("/your-projects/videos"), O("/your-projects/videos/*"), O("/projects"), O("/projects/videos"), O("/projects/videos/*"), O("/library/*"), O("/library/*/videos"), O("/library/*/videos/*"), O("/dream-lab"), O("/assistant"), O("/assistant/*"), O("/ai"), O("/ai/*"), O("/ai/code"), O("/ai/code/*"), O("/s/designs"), O("/s/templates"), O("/offline-designs"),
                            O("/shared-with-you"), O("/rewards"), O("/planner"), O("/design-reviews"), O("/classwork"), O("/menu"), O("/creators/apply"), O("/creators/template"), O("/creators/template/dashboard"), O("/creators/template/inspiration"), O("/creators/element"), O("/creators/my-items"), O("/creators/resources"), O("/creators/resources/videos"), O("/creators/resources/videos/*"), O("/creators/verify/*"), O("/creators/inspiration"), O("/creators/inspiration/campaigns/*"), O("/creators/welcome"), O("/creator-hub"), O("/contributors/upload"),
                            O("/earnings"), O("/teams"), O("/teams/apps"), O("/teams/brand-control"), O("/teams/create"), O("/teams/designs"), O("/teams/folders"), O("/teams/groups"), O("/teams/groups/*"), O("/teams/layouts"), O("/teams/members"), O("/teams/settings"), O("/teams/timeline"), O("/groups/*"), O("/groups/*/designs"), O("/groups/*/folders"), O("/groups/*/members"), O("/pro-features"), O("/mockups"), O("/mockups/collection/*"), O("/mockups/mockup/*"), O("/smartmockups"), O("/smartmockups/collection/*"), O("/smartmockups/mockup/*"), O("/starred"),
                            O("/team-stream"), O("/design-stream"), O("/trash"), O("/_design-spec-selector"), O("/your-apps"), O("/your-apps/*"), O("/portfolio"), O("/brand"), O("/brand/*"), O("/brand/brand-templates"), O("/brand/brand-templates/*"), O("/search/templates"), O("/search/designs"), O("/search"), O("/templates")
                        ];
                        const g = Qc(),
                            h = Rc();
                        f = new Xc([...f, g], h);
                        b = new Yc(new Zc({
                            O: c,
                            userAgent: b
                        }));
                        c = Oc({
                            T: a,
                            C: {
                                l: e,
                                j: d
                            }
                        });
                        return new $c({
                            T: a
                        }, f, d, c, b, e)
                    },
                    cd = function({
                        T: a,
                        userAgent: b,
                        O: c,
                        B: d,
                        C: {
                            j: e,
                            l: f
                        },
                        I: g,
                        ma: h
                    }) {
                        a = ad({
                            T: a,
                            userAgent: b,
                            O: c,
                            C: {
                                j: e,
                                l: f
                            }
                        });
                        return {
                            Bf: new bd({
                                ma: h
                            }, d, g, a)
                        }
                    },
                    ed = function({
                        C: {
                            j: a
                        },
                        B: b,
                        I: c
                    }) {
                        return {
                            ig: new dd(b, c, new oc({
                                cacheName: "web_workers"
                            }, a))
                        }
                    },
                    id = function({
                        T: a,
                        N: b,
                        userAgent: c,
                        O: d,
                        B: e,
                        C: {
                            j: f,
                            l: g
                        },
                        $a: h,
                        ga: k,
                        ma: l,
                        ha: n
                    }) {
                        k = Nb({
                            ga: k,
                            B: e,
                            C: {
                                j: f
                            }
                        });
                        ({
                            Bf: a
                        } = cd({
                            T: a,
                            userAgent: c,
                            O: d,
                            B: e,
                            C: {
                                j: f,
                                l: g
                            },
                            I: k,
                            ma: l
                        }));
                        ({
                            ig: c
                        } = ed({
                            B: e,
                            C: {
                                j: f,
                                l: g
                            },
                            I: k
                        }));
                        ({
                            Af: d
                        } = sc({
                            N: b,
                            C: {
                                j: f,
                                l: g
                            },
                            B: e,
                            I: k
                        }));
                        ({
                            ye: n
                        } = qc({
                            B: e,
                            ha: n,
                            C: {
                                j: f,
                                l: g
                            },
                            I: k
                        }));
                        ({
                            ie: b
                        } = gc({
                            B: e,
                            I: k,
                            N: b,
                            C: {
                                j: f,
                                l: g
                            }
                        }));
                        return {
                            yc: new fd([new gd(k), new hd(h), a, c, d, n,
                                b
                            ])
                        }
                    },
                    kd = function({
                        hb: a,
                        T: b,
                        N: c,
                        userAgent: d,
                        O: e,
                        B: f,
                        C: {
                            j: g,
                            l: h
                        },
                        $a: k,
                        ga: l,
                        ha: n,
                        ma: m,
                        qc: t = fetch
                    }) {
                        ({
                            yc: b
                        } = id({
                            T: b,
                            N: c,
                            userAgent: d,
                            O: e,
                            B: f,
                            C: {
                                j: g,
                                l: h
                            },
                            ga: l,
                            ha: n,
                            $a: k,
                            ma: m
                        }));
                        a = Xa({
                            C: {
                                j: g
                            },
                            bb: a
                        });
                        c = $a();
                        return new jd(b, f, g, a, {
                            Xe: async q => {
                                if (f.Pa()) return Response.error();
                                try {
                                    return await t(q, {
                                        redirect: "follow"
                                    })
                                } catch (x) {
                                    return Response.error()
                                }
                            }
                        }, c)
                    },
                    md = function({
                        serviceWorker: a,
                        C: {
                            j: b,
                            Ga: c,
                            ob: d,
                            ra: e
                        },
                        O: f,
                        B: g,
                        N: h,
                        hb: k,
                        te: l,
                        ma: n,
                        ga: m,
                        ha: t
                    }) {
                        c = c.Na("service_worker.fetch_interceptor");
                        b = kd({
                            hb: k,
                            T: `${a.location.origin}/_offline-fallback`,
                            N: h,
                            userAgent: self.navigator.userAgent,
                            O: f,
                            B: g,
                            C: {
                                j: b,
                                l: c
                            },
                            $a: {
                                Pe: l
                            },
                            ma: n,
                            ga: m,
                            ha: t
                        });
                        const q = new ld(b, d, e, c);
                        a.addEventListener("fetch", x => Oa(q, x))
                    },
                    td = function(a, b) {
                        const c = a.l.na("service_worker.handle_message");
                        try {
                            const d = a.l.Ob("process_message", c, e => {
                                try {
                                    const f = nd.P(b.data),
                                        g = f.message,
                                        h = f.requestId;
                                    e.setAttribute("message_type", f.message);
                                    switch (g) {
                                        case "GET_SW_RELEASE":
                                            return new od({
                                                requestId: h,
                                                release: a.options.release
                                            });
                                        case "OVERRIDE_NETWORK_STRATEGY":
                                            return a.B.Db = f.Db, new pd({
                                                requestId: h,
                                                Pa: a.B.Pa()
                                            });
                                        case "SKIP_WAITING":
                                            return a.serviceWorker.skipWaiting(), new qd({
                                                requestId: h
                                            });
                                        default:
                                            throw new E(g);
                                    }
                                } catch (f) {
                                    return e.setStatus("error"), new rd({
                                        If: JSON.stringify(b.data)
                                    })
                                }
                            });
                            a.l.Ob("post_response", c, () => {
                                var e;
                                (e = b.source) === null || e === void 0 || e.postMessage(sd.va(d))
                            })
                        } finally {
                            c.end()
                        }
                    },
                    vd = function({
                        serviceWorker: a,
                        B: b,
                        release: c,
                        C: {
                            Ga: d
                        }
                    }) {
                        d = d.Na("service_worker.message_handler");
                        const e = new ud({
                            release: c
                        }, a, b, d);
                        a.addEventListener("message", f => td(e, f))
                    },
                    wd = function(a, b, c, d) {
                        d = [c instanceof Error ? c : null, a.context, d].filter(Qa);
                        Object.keys(a.tags).length > 0 && d.push(a.tags);
                        return [`[ConsoleErrorClient][${a.name}][${b}]: ${c}`, ...d]
                    },
                    yd = function() {
                        const a = xd();
                        let b = 0;
                        return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, function(c) {
                            c = Number(c);
                            return (c ^ a[b++] & 15 >> c / 4).toString(16)
                        })
                    },
                    xd = function() {
                        if (typeof window !== "undefined" && typeof window.crypto !== "undefined" && typeof window.crypto.getRandomValues === "function") return window.crypto.getRandomValues(new Uint8Array(31));
                        const a = Math.random;
                        return Array.from({
                            length: 31
                        }, () => Math.floor(a() * 255))
                    },
                    zd = function(a) {
                        Object.keys(a).forEach(b => a[b] == null && delete a[b])
                    },
                    Bd = function(a) {
                        if (a instanceof Ad) {
                            const b = [];
                            a.values.forEach(c => {
                                b.push(Bd(c))
                            });
                            return b
                        }
                        if (a instanceof Cd) {
                            const b = {};
                            a.values.forEach(c => {
                                b[c.name] = Bd(c.value)
                            });
                            return b
                        }
                        return a.value
                    },
                    Dd = function(a, b) {
                        let c = b;
                        Object.entries(a.wd).forEach(([d, e]) => {
                            c = c.split(e).join(d)
                        });
                        return c
                    },
                    Ed = function(a, b = {}) {
                        Object.keys(b).forEach(c => {
                            const d = b[c];
                            typeof d ===
                                "string" && (b[c] = Dd(a, d))
                        })
                    },
                    Fd = function(a, b) {
                        var c;
                        return { ...b,
                            frames: b === null || b === void 0 ? void 0 : (c = b.frames) === null || c === void 0 ? void 0 : c.map(d => {
                                for (const [e, f] of Object.entries(a.wd)) {
                                    const g = h => h === null || h === void 0 ? void 0 : h.replace(f, e);
                                    d.module = g(d.module);
                                    d.abs_path = g(d.abs_path);
                                    d.filename = g(d.filename)
                                }
                                return d
                            })
                        }
                    },
                    Gd = function(a, b) {
                        var c, d;
                        b.exception && b.exception.values && (b.exception = { ...b.exception,
                            values: (d = b.exception) === null || d === void 0 ? void 0 : (c = d.values) === null || c === void 0 ? void 0 : c.map(e =>
                                ({ ...e,
                                    ...(e.stacktrace && {
                                        stacktrace: Fd(a, e.stacktrace)
                                    })
                                }))
                        })
                    },
                    Hd = function(a, b) {
                        var c = b.request;
                        c != null && c.url != null && (c.url = Dd(a, c.url));
                        Gd(a, b);
                        b.tags != null && Ed(a, b.tags)
                    },
                    Id = function(a, b) {
                        const c = [];
                        b.message && c.push(b.message);
                        if (b.exception) {
                            const {
                                type: d = "",
                                value: e = ""
                            } = b.exception.values && b.exception.values[0] || {};
                            d !== "Error" && c.push(d, e)
                        }
                        return c.some(d => a.Od.some(e => Object.prototype.toString.call(e) === "[object RegExp]" ? e.test(d) : typeof e === "string" ? d.indexOf(e) !== -1 : !1))
                    },
                    Kd = function(a, b) {
                        var c,
                            d;
                        if ((a === null || a === void 0 ? void 0 : a.message) !== (b === null || b === void 0 ? void 0 : b.message)) return !1;
                        a = (c = a.exception) === null || c === void 0 ? void 0 : c.values;
                        b = (d = b.exception) === null || d === void 0 ? void 0 : d.values;
                        if (a == null || b == null || a.length !== b.length) return !1;
                        for (d = 0; d < a.length; d++)
                            if (a[d].value !== b[d].value || a[d].type !== b[d].type || !Jd(a[d].stacktrace, b[d].stacktrace)) return !1;
                        return !0
                    },
                    Jd = function(a, b) {
                        a = a === null || a === void 0 ? void 0 : a.frames;
                        b = b === null || b === void 0 ? void 0 : b.frames;
                        if (a == null && b == null) return !0;
                        if (a == null || b == null || a.length !== b.length) return !1;
                        for (let c = 0; c < a.length; c++)
                            if (a[c].filename !== b[c].filename || a[c].colno !== b[c].colno || a[c].lineno !== b[c].lineno) return !1;
                        return !0
                    },
                    Md = function(a, b) {
                        const c = a.history.find(f => Kd(f.event, b));
                        if (c == null) return !1;
                        const d = Ld.now(),
                            e = c.timestamp;
                        return Kd(b, c.event) && d - e < a.$f
                    },
                    Pd = function() {
                        return new Nd({
                            Gh: a => Od({
                                frame: a,
                                Sf: "/dist/renderer/"
                            })
                        })
                    },
                    Od = function({
                        frame: a,
                        Sf: b
                    }) {
                        if (a.filename == null) return a;
                        const c = a.filename.replace(/\\/g, "/").split(b);
                        if (c.length <=
                            1) return a;
                        a.filename = "app://" + b + c.pop();
                        return a
                    },
                    Rd = function(a, b) {
                        var c;
                        b === null || b === void 0 || (c = b.breadcrumbs) === null || c === void 0 || c.map((d, e) => {
                            if (b === null || b === void 0 ? 0 : b.breadcrumbs) {
                                var f = b.breadcrumbs;
                                if (d.type === "http") {
                                    var g;
                                    d.data = d.data || {};
                                    var h;
                                    d.data.url = Qd(a, (h = (g = d.data) === null || g === void 0 ? void 0 : g.url) !== null && h !== void 0 ? h : "")
                                }
                                f[e] = d
                            }
                        });
                        b.request && (b.request = a.Ac(b.request));
                        return b
                    },
                    Qd = function(a, b) {
                        try {
                            const c = new URL(b, `${a.location.protocol}//${a.location.host}`);
                            if (!["http:",
                                    "https:"
                                ].includes(c.protocol)) return "";
                            a.Pd.some(d => c.hostname.includes(d)) && c.pathname.startsWith("/_ajax") || (c.pathname = "");
                            c.search = "";
                            return b.includes(c.host) ? c.toString() : c.pathname || "/"
                        } catch (c) {
                            return ""
                        }
                    },
                    Td = function(a) {
                        const b = [];
                        for (const c of Sd) {
                            const d = c(a);
                            d && b.push(d)
                        }
                        return b
                    },
                    Vd = function(a) {
                        return (b, c) => {
                            b.request && (b.request = a.Ac(b.request));
                            if (Ud(a, b)) return null;
                            if (a.kd) {
                                b.tags == null && (b.tags = {});
                                a: switch (a.kd.status) {
                                    case 2:
                                        var d = "OFFLINE";
                                        break a;
                                    case 1:
                                        d = "ONLINE";
                                        break a;
                                    default:
                                        d =
                                            "UNKNOWN"
                                }
                                b.tags.offlineStatus = d
                            }
                            try {
                                Hd(a.ue, b)
                            } catch (e) {
                                a.F(e)
                            }
                            return a.Vd.reduce((e, f) => f(e, c), b)
                        }
                    },
                    fe = function(a, b, c) {
                        var d, e, f, g = (d = a.R) === null || d === void 0 ? void 0 : d.getCurrentHub().getClient();
                        d = g && g.getOptions() || {};
                        var h;
                        g = (h = b.sampleRate) !== null && h !== void 0 ? h : 1;
                        var k;
                        h = [new Wd, new Xd, new Yd, new Zd(2E3), new $d(g, (k = b.rf) !== null && k !== void 0 ? k : g), new ae, new be, new ce(a.allowUrls, location), Pd()];
                        a.S.flags && a.S.flags.De && h.push(new de(ee));
                        a.setTags(a.S.tags);
                        a.setExtras(a.S.extra);
                        if (k = typeof navigator !==
                            "undefined" ? navigator.userAgent : void 0) k = Td(k), a.setTags(k);
                        b = b.Cf;
                        b !== 1 && a.setTag("webx", String(b === 3));
                        a.setTag("iframe", String(typeof window !== "undefined" && window.self !== window.top));
                        c.pd && a.setTag("webview", c.pd);
                        d.beforeSend = Vd(a);
                        c = { ...d,
                            maxValueLength: 1024,
                            dsn: d.dsn || a.S.dsn,
                            environment: d.environment || a.S.environment,
                            release: d.release || a.S.release,
                            tracesSampleRate: 0,
                            sampleRate: 1,
                            integrations: h,
                            allowUrls: a.allowUrls,
                            autoSessionTracking: !1,
                            ignoreErrors: ["variable: _AutofillCallbackHandler", "_AutofillCallbackHandler is not defined",
                                "Non-Error promise rejection captured with value: Object Not Found Matching Id"
                            ]
                        };
                        zd(c);
                        (e = a.R) === null || e === void 0 || e.init(c);
                        (f = a.R) === null || f === void 0 || f.configureScope(l => {
                            l.setUser({
                                id: yd()
                            });
                            l.setExtra("isAnonymousUser", !0);
                            l.setTag("initLocation", "error_client")
                        })
                    },
                    Ud = function(a, b) {
                        const c = b.exception && b.exception.values && b.exception.values.length > 0 && b.exception.values[0],
                            d = c && c.stacktrace || void 0,
                            e = d && d.frames && d.frames[0] && d.frames[0].filename,
                            f = b.message || c && c.value || void 0;
                        return a.Le.some(g =>
                            g({
                                message: f,
                                filename: e,
                                location,
                                tags: b.tags,
                                event: b
                            }))
                    },
                    ge = function(a, b) {
                        var c, d;
                        b instanceof Error ? (c = a.R) === null || c === void 0 || c.captureException(b) : (d = a.R) === null || d === void 0 || d.captureMessage(b)
                    },
                    he = function(a, b, c) {
                        if (b == null) return Error((c ? c + " " : "") + "[null error thrown]");
                        if (typeof b === "object") {
                            const e = b instanceof L ? new L(b.message, b.sampleRate) : Error(b.message);
                            b.stack && (e.stack = b.stack);
                            b.cause && (e.cause = b.cause);
                            if (c) {
                                var d;
                                if ((d = b.message) === null || d === void 0 ? 0 : d.startsWith(c)) return a.setTag("prefixCollision",
                                    "true"), b;
                                a = c + " " + (e.message || "[no message on error]");
                                try {
                                    e.message = a
                                } catch (f) {
                                    if (f instanceof TypeError) return Error(a);
                                    throw f;
                                }
                            }
                            return e
                        }
                        return b.toString()
                    },
                    ie = function(a, b, c, d) {
                        a.R == null ? (console.error(c), d && console.log("errorParams", d)) : a.R && a.R.withScope(e => {
                            typeof d === "string" && (d = {
                                pa: d
                            });
                            c = he(e, c, typeof d === "string" ? d : d === null || d === void 0 ? void 0 : d.pa);
                            d != null && (d.fingerprint && e.setFingerprint(d.fingerprint), d.eg && e.setTag("userFlow", d.eg), d.extra && d.extra.forEach((f, g) => e.setExtra(g, f)),
                                d.tags && d.tags.forEach((f, g) => e.setTag(g, f)));
                            a.Nc.length > 0 && e.setTag("component", a.Nc.join("."));
                            e.setLevel(b);
                            ge(a, c)
                        })
                    },
                    je = function(a) {
                        return a.wa === "span" && a.attrs.get("is_uop") === !0
                    },
                    le = function(a, b) {
                        ke(a, b, () => {
                            const c = a.tb.get(b.context.spanId) || [];
                            for (const d of c) le(a, d)
                        })
                    },
                    ke = function(a, b, c) {
                        var d, e = (d = b.attrs.get("parent_relative_start_ms")) !== null && d !== void 0 ? d : b.duration;
                        e = typeof e === "number" ? ` - ${Math.round(e)}ms` : "";
                        var f = (d = b.parentSpanId != null) ? `${b.wa==="event"?"[ChildEvent]":"[ChildSpan]"}: ` :
                            "[OpenTelemetryClient]: ";
                        const g = je(b) ? "User Operation - " : "";
                        e = `${f}${g}${b.name}${e}`;
                        d && !a.kc.has(b.parentSpanId) ? console.group(e) : console.groupCollapsed(e);
                        console.groupCollapsed("Attributes");
                        d = {
                            name: b.name,
                            Ai: `${b.duration}ms`,
                            ...Object.fromEntries(b.attrs.entries())
                        };
                        e = {};
                        for (const h of Object.keys(d)) f = d[h], e[h] = f instanceof Object ? JSON.stringify(f) : f;
                        console.table(e);
                        console.groupEnd();
                        c === null || c === void 0 || c();
                        console.groupEnd();
                        a.kc.add(b.context.spanId)
                    },
                    P = function(a) {
                        return [
                            ["name",
                                a.name
                            ],
                            ["status", a.status],
                            ["instrumentationScope", a.ja],
                            ["startTime", a.startTime],
                            ["endTime", a.endTime],
                            ["duration", a.duration],
                            ["parentSpanId", a.parentSpanId]
                        ]
                    },
                    me = function(a) {
                        switch (a) {
                            case "unset":
                                return 0;
                            case "ok":
                                return 1;
                            case "error":
                                return 2;
                            default:
                                return 0
                        }
                    },
                    oe = function(a) {
                        const b = [];
                        for (const [c, d] of a.entries()) d != null && b.push({
                            key: c,
                            value: ne(d)
                        });
                        return b
                    },
                    ne = function(a) {
                        const b = typeof a;
                        return b === "string" ? {
                                stringValue: a
                            } : b === "number" ? Number.isInteger(a) ? {
                                intValue: a
                            } : {
                                doubleValue: a
                            } :
                            b === "boolean" ? {
                                boolValue: a
                            } : a instanceof Uint8Array ? {
                                bytesValue: a
                            } : Array.isArray(a) ? {
                                arrayValue: {
                                    values: a.map(ne)
                                }
                            } : b === "object" && a != null ? {
                                kvlistValue: {
                                    values: Object.entries(a).map(([c, d]) => ({
                                        key: c,
                                        value: ne(d)
                                    }))
                                }
                            } : {}
                    },
                    pe = function(a) {
                        const b = new Map;
                        for (const c of a) a = b.get(c.ja), a || (a = [], b.set(c.ja, a)), a.push(c);
                        return b
                    },
                    qe = function(a, b) {
                        b = b(a) / 1E3;
                        a = Math.trunc(b);
                        b = Number((b - a).toFixed(9)) * 1E9;
                        let [c, d] = [a, b];
                        d > 1E9 && (d -= 1E9, c += 1);
                        return c * 1E9 + d
                    },
                    re = function(a, b) {
                        if (a.length === 0) return {
                            resourceSpans: []
                        };
                        const c = [];
                        a = pe(a);
                        for (const [d, e] of a)
                            if (e.length > 0) {
                                a = {
                                    attributes: oe(e[0].Z),
                                    droppedAttributesCount: 0
                                };
                                const f = [{
                                    scope: {
                                        name: d
                                    },
                                    spans: e.map(g => {
                                        var h = g.context;
                                        const k = qe(g.startTime, b);
                                        var l;
                                        const n = qe((l = g.endTime) !== null && l !== void 0 ? l : g.startTime, b);
                                        var m = g.attrs;
                                        g.wa === "event" && (l = g.attrs.get("parent_start"), l != null && typeof l === "number" && (m = new Map([...m.entries(), ["parent_start", qe(l, b)]])));
                                        l = h.traceId;
                                        h = h.spanId;
                                        var t = g.parentSpanId,
                                            q = g.name;
                                        m = oe(m);
                                        var x = {
                                            code: me(g.status)
                                        };
                                        g = g.links;
                                        const w = [];
                                        for (const A of g) w.push({
                                            spanId: A.ag.spanId,
                                            traceId: A.ag.traceId,
                                            droppedAttributesCount: 0
                                        });
                                        return {
                                            traceId: l,
                                            spanId: h,
                                            parentSpanId: t,
                                            name: q,
                                            kind: 3,
                                            startTimeUnixNano: k,
                                            endTimeUnixNano: n,
                                            attributes: m,
                                            droppedAttributesCount: 0,
                                            events: [],
                                            droppedEventsCount: 0,
                                            status: x,
                                            links: w,
                                            droppedLinksCount: 0
                                        }
                                    })
                                }];
                                c.push({
                                    resource: a,
                                    scopeSpans: f
                                })
                            }
                        return {
                            resourceSpans: c
                        }
                    },
                    se = function(a, b) {
                        a.qd.unshift(b);
                        return a
                    },
                    ue = function(a) {
                        try {
                            a.Qa.process(a.buffer)
                        } catch (b) {
                            a.j.F(b, {
                                pa: `Failed to export the span buffer from ${te.name}`,
                                extra: new Map([
                                    ["spans", JSON.stringify(a.buffer.map(P), void 0, 2)],
                                    ["maxBatchSize", a.config.Gb],
                                    ["maxBatchingTimeMs", a.config.Hb]
                                ])
                            })
                        }
                        a.buffer = [];
                        a.Ua != null && clearTimeout(a.Ua);
                        a.Ua = void 0
                    },
                    ve = function(a, b, c, d = !1) {
                        b.aborted || d || !b.qa() || (c.push(b), b.Xa.forEach(e => c.push(e)));
                        for (const e of b.Ka) ve(a, e, c, d || b.aborted);
                        b.G = void 0;
                        b.Ka.length = 0
                    },
                    ze = function({
                        span: a,
                        j: b,
                        Da: c,
                        Gg: d = new Map
                    }) {
                        try {
                            var e, f, g, h, k;
                            ha(!a.cd(), "Span must be ended to create a PerformanceContext");
                            const l = we(c, "LongTaskService"),
                                n = we(c, "VisibilityService"),
                                m = a.startTime,
                                t = a.endTime;
                            ha(t != null, "Span endTime must exist to create a PerformanceContext");
                            const q = new Map([
                                    ["start", xe(m, m)]
                                ]),
                                x = je(a) ? (e = a.ba) === null || e === void 0 ? void 0 : e.ab : void 0;
                            for (const {
                                    name: B,
                                    startTime: M
                                } of a.Xa) q.set(B, xe(m, M));
                            if (x != null)
                                for (const [B, M] of x) q.set(B, xe(m, M));
                            for (const [B, M] of d) q.set(B, xe(m, M));
                            q.set("finish", xe(m, t));
                            if (l == null || n == null) return {
                                nf: q,
                                ...((g = a.la) === null || g === void 0 ? void 0 : (f = g.frameRate) === null || f === void 0 ? void 0 : ye(f))
                            };
                            const w =
                                l.xh(m, t),
                                A = n.Yi(a);
                            return {
                                nf: q,
                                Kh: w.count,
                                Lh: w.duration,
                                Xi: A,
                                resources: void 0,
                                ...((k = a.la) === null || k === void 0 ? void 0 : (h = k.frameRate) === null || h === void 0 ? void 0 : ye(h))
                            }
                        } catch (l) {
                            return c = l instanceof Error ? l.message : "Unknown error creating PerformanceContext", d = c.includes("Invalid metric: adjusted time must not be negative") ? 2E-4 : .2, b.Gd(new L(c, d), {
                                pa: "Error creating PerformanceContext",
                                tags: new Map([
                                    ["span.name", a.name],
                                    ["service.name", String(a.Z.get("service.name"))]
                                ])
                            }), {
                                uh: c
                            }
                        }
                    },
                    xe = function(a,
                        b) {
                        a = b - a;
                        ha(a >= 0, "Invalid metric: adjusted time must not be negative");
                        return Math.round(a)
                    },
                    Be = function(a) {
                        return function() {
                            for (let b = 0; b < a * 2; b++) Ae[b] = Math.floor(Math.random() * 16) + 48, Ae[b] >= 58 && (Ae[b] += 39);
                            return String.fromCharCode.apply(null, Ae.slice(0, a * 2))
                        }
                    },
                    Ce = function(a) {
                        let b, c;
                        a instanceof Map ? b = a : a && (c = a);
                        return {
                            hd: b,
                            jd: c
                        }
                    },
                    De = function(a) {
                        const {
                            hd: b,
                            jd: c
                        } = Ce(a);
                        var d;
                        return { ...c,
                            attrs: (d = b !== null && b !== void 0 ? b : c === null || c === void 0 ? void 0 : c.attrs) !== null && d !== void 0 ? d : new Map
                        }
                    },
                    Ee = function(a) {
                        for (const c of a.ta.plugins) try {
                            var b;
                            (b = c.Vh) === null || b === void 0 || b.call(c, a)
                        } catch (d) {
                            a.j.F(d, {
                                pa: "Plugin.onSpanEnd error",
                                extra: new Map([
                                    ["plugin", c.name], ...P(a)
                                ])
                            })
                        }
                    },
                    He = function(a) {
                        var b;
                        (b = a.ba) === null || b === void 0 || Fe(b, a);
                        a.G instanceof Ge && a.G.ba != null && a.G.ba !== a.ba && Fe(a.G.ba, a)
                    },
                    Je = function(a, b, c, d) {
                        const e = a.ac = {
                            za: a.za,
                            Aa: a.Aa
                        };
                        try {
                            var f;
                            a.timeout && clearTimeout(a.timeout);
                            let g, h, k;
                            b instanceof Map ? h = b : b != null && (g = b);
                            c instanceof Map ? h = c : c != null && (k = c);
                            d != null && (k = d);
                            a.Va = !1;
                            g != null && a.setStatus(g);
                            h && a.Ea(h);
                            if ((f = a.la) ===
                                null || f === void 0 ? 0 : f.frameRate) {
                                Ie(a.la.frameRate);
                                const {
                                    ec: l,
                                    Xc: n,
                                    frameCount: m
                                } = ye(a.la.frameRate);
                                l != null && n != null && m != null && (a.attrs.set("frame_duration_mean", l), a.attrs.set("frame_duration_standard_deviation", n), a.attrs.set("frame_count", m), a.attrs.set("long_frame_duration", l + 2 * n))
                            }
                            a.ended = !0;
                            a.endTime = k !== null && k !== void 0 ? k : a.getCurrentTime();
                            a.duration = a.endTime - a.startTime;
                            Ee(a);
                            He(a);
                            a.ta.Ta.process([a]);
                            a.jb.forEach(l => l(e));
                            a.Va = !0;
                            return e
                        } catch (g) {
                            return a.j.F(g, {
                                pa: "Error ending span",
                                extra: new Map(P(a))
                            }), e
                        }
                    },
                    Me = function({
                        oc: {
                            performance: a,
                            name: b,
                            type: c,
                            attrs: d,
                            startTime: e,
                            timeout: f
                        },
                        l: g,
                        G: h,
                        se: k,
                        j: l,
                        vf: n
                    }) {
                        d = d || new Map;
                        c && d.set("uop_attr_type", c);
                        d.set("sample_rate_override", 1);
                        d.set("is_uop", !0);
                        c = h === null || h === void 0 ? void 0 : h.qa();
                        if (h != null && !h.qa()) {
                            const q = h.Tb();
                            q instanceof Ke && (h = q.X)
                        }
                        const m = h ? g.oa(b, h, {
                            performance: a,
                            attrs: d,
                            startTime: e,
                            timeout: f
                        }) : g.na(b, {
                            performance: a,
                            attrs: d,
                            startTime: e,
                            timeout: f
                        });
                        ha(m instanceof Ge, "User operations can only be created by SpanImpls");
                        const t = [];
                        k.forEach(q => {
                            try {
                                const x = q.Ig();
                                t.push(x)
                            } catch (x) {
                                l.F(x)
                            }
                        });
                        e = new Map(t.flatMap(q => [...q.entries()]));
                        a = new Ke(b, m, l, c, (a === null || a === void 0 ? 0 : a.Ki) ? new Map : void 0);
                        m.ba = a;
                        a.Ja(() => {
                            Le(m, m.attrs.get("uop_attr_type"))
                        });
                        a.Ea(e);
                        a.Ea(d);
                        n === null || n === void 0 || n(m);
                        return a
                    },
                    Ne = function(a) {
                        a = a === null || a === void 0 ? void 0 : a.Tb();
                        return a instanceof Ke ? a : void 0
                    },
                    Fe = function(a, b) {
                        a.$b.delete(b);
                        if (!a.ended) {
                            if (a.ab && b.wa === "span" && !b.aborted) {
                                a.ab.set(`${b.name}_start`, b.startTime);
                                for (var c of b.Xa) a.ab.set(`${b.name}_${c.name}`,
                                    c.startTime);
                                b.endTime != null && a.ab.set(`${b.name}_end`, b.endTime)
                            }
                            c = b.status === "error";
                            b = b.attrs.get("timed_out") === !0;
                            if (a.$b.size === 0 || c || b) {
                                a.ended = !0;
                                const e = Oe(a, a.X);
                                if (e != null) {
                                    b && !a.X.name.endsWith("timed_out") && (a.X.setAttribute("timed_out", !0, !0), a.X.name += ".timed_out");
                                    var d = a.bc = a.X.end(c ? "error" : "ok", e.endTime);
                                    a.jb.forEach(f => f(d))
                                } else a.X.abort(), a.ib.forEach(f => f())
                            }
                        }
                    },
                    Oe = function(a, b) {
                        if (!b.aborted) {
                            var c = b.endTime != null ? b : void 0;
                            for (const d of b.Ka) b = Oe(a, d), b != null && (c == null ||
                                b.endTime > c.endTime) && (c = b);
                            return c
                        }
                    },
                    Le = function(a, b) {
                        if (typeof b === "string") {
                            for (const c of a.Xa) c.setAttribute("uop_attr_type", b, !0);
                            for (const c of a.Ka) c.attrs.get("is_uop") !== !0 && (c.setAttribute("uop_attr_type", b, !0), Le(c, b))
                        }
                    },
                    Pe = function(a) {
                        if (a) {
                            var b = a === null || a === void 0 ? void 0 : a.Tb();
                            return b instanceof Ke ? b.Pb : a.qa()
                        }
                    },
                    ye = function(a) {
                        return {
                            frameCount: a.Fa.count,
                            ec: a.Fa.count > 0 ? a.Fa.lf : void 0,
                            Xc: a.Fa.count > 0 ? a.Fa.Ef : void 0
                        }
                    },
                    Ie = function(a) {
                        a.Vb && a.uc.cancelAnimationFrame(a.Vb);
                        a.document.removeEventListener("visibilitychange",
                            a.ld);
                        a = ye(a);
                        var b = Qe;
                        const c = a.frameCount * a.ec,
                            d = a.ec + 2 * a.Xc;
                        c > 0 && (b.frameCount += a.frameCount, b.gd.add(d, c));
                        for (const e of b.ad) e(a)
                    },
                    Re = async function(a, b, c, d) {
                        let e, f;
                        typeof d === "function" ? f = d : e = De(d);
                        const g = a.oa(b, c, e);
                        return f(g).catch(h => {
                            g.setStatus("error");
                            throw h;
                        }).finally(() => g.end())
                    },
                    we = function(a, b) {
                        try {
                            return a.config.plugins.find(d => d.name === b)
                        } catch (d) {
                            var c;
                            a.j.F(d, {
                                extra: new Map([
                                    ["attrs", Object.fromEntries((c = a.config) === null || c === void 0 ? void 0 : c.Z)]
                                ])
                            })
                        }
                    },
                    Se = function(a) {
                        var b =
                            Date.now(),
                            c = performance.now();
                        Math.abs(a.Gc + (c - a.sc) - b) < a.threshold || (a.Gc = b, a.sc = c)
                    },
                    cf = function({
                        S: a,
                        cb: b,
                        cc: c,
                        userAgent: d,
                        C: {
                            j: e
                        }
                    }) {
                        let f, g = new Map;
                        switch (a.M) {
                            case "NOOP":
                                return new Te;
                            case "CONSOLE":
                                f = new Ue;
                                break;
                            case "HTTP":
                                var h;
                                f = new Ve({
                                    url: a.endpoint,
                                    Yb: (h = a.He) !== null && h !== void 0 ? h : 1
                                }, e, new We, Xe({
                                    url: a.endpoint,
                                    Yf: c !== null && c !== void 0 ? c : 3E4,
                                    cb: b !== null && b !== void 0 ? b : .01
                                }));
                                var k, l, n, m;
                                g = new Map([
                                    ["telemetry_version", "v2"],
                                    ["app.component", a.app],
                                    ["service.name", a.app],
                                    ["app.release",
                                        (k = a.release) !== null && k !== void 0 ? k : ""
                                    ],
                                    ["app.source", (l = a.source) !== null && l !== void 0 ? l : "web"],
                                    ["app.flavor", (n = a.Ne) !== null && n !== void 0 ? n : ""],
                                    ["app.build.variant", (m = a.variant) !== null && m !== void 0 ? m : "baseline"],
                                    ["session_id", yd()],
                                    ["x-canva-tenant", "canva-app"],
                                    ["device.platform", a.platform],
                                    ["device.id", a.deviceId]
                                ]);
                                d != null && (g.set("browser.name", d.be), g.set("browser.version_major", d.$d), g.set("browser.version_minor", d.ae));
                                break;
                            default:
                                throw new E(a);
                        }
                        b = se(se(new Ye, q => new Ze(q)), q => {
                            var x, w;
                            return new te(q, {
                                Gb: (x = a.Gb) !== null && x !== void 0 ? x : 20,
                                Hb: (w = a.Hb) !== null && w !== void 0 ? w : 5E3
                            }, e)
                        }).build(f);
                        var t;
                        c = a.M === "HTTP" ? (t = a.bg) !== null && t !== void 0 ? t : .01 : 1;
                        return new $e(new af({
                            Ta: b,
                            zc: new bf(c, e),
                            Z: g
                        }), e)
                    },
                    La = function(a, b) {
                        b.request.mode !== "navigate" && (b = b.clientId, a.Cd.xc(b), a.Bd.xc(b))
                    },
                    Na = function(a, b, c) {
                        if (b.request.mode !== "navigate") throw Error("Navigation event expected");
                        c.then(d => {
                            d.ok && (d = b.resultingClientId, a.Cd.wc(d), a.Bd.wc(d))
                        }).catch(() => {})
                    },
                    df = function(a, b) {
                        const c = a.La.get(b);
                        if (c != null) {
                            var d =
                                performance.now() - 5E3,
                                e = c.Ab.filter(f => f >= d);
                            c.Ab = e;
                            e.length >= 3 ? c.Ua = self.setTimeout(() => df(a, b), 5E3) : (e = Math.max(...e), c.span.end(void 0, void 0, e), a.La.delete(b))
                        }
                    },
                    hf = function({
                        Ga: a
                    }) {
                        a = a.Na("service_worker.network_behavior_tracer");
                        return {
                            ra: new ef(new ff(a), new gf(a))
                        }
                    },
                    Ka = function(a) {
                        if (a.Sc) return performance.now();
                        a.Sc = !0;
                        return a.Wb == null || Date.now() - a.Wb < 500 ? 0 : performance.now()
                    },
                    lf = function({
                        location: a,
                        S: b,
                        cb: c,
                        cc: d,
                        userAgent: e,
                        C: {
                            j: f
                        }
                    }) {
                        a = a.origin.includes("localhost");
                        if (b == null || a) b = new jf({});
                        b = cf({
                            S: b,
                            cb: c,
                            cc: d,
                            userAgent: e,
                            C: {
                                j: f
                            }
                        });
                        ({
                            ra: c
                        } = hf({
                            Ga: b
                        }));
                        return {
                            Ga: b,
                            ob: new kf,
                            ra: c
                        }
                    },
                    ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
                        if (a == Array.prototype || a == Object.prototype) return a;
                        a[b] = c.value;
                        return a
                    },
                    ba = aa(this);
                da("String.prototype.replaceAll", function(a) {
                    return a ? a : function(b, c) {
                        if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
                        return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
                    }
                });
                da("Object.fromEntries", function(a) {
                    return a ? a : function(b) {
                        var c = {};
                        if (!(Symbol.iterator in b)) throw new TypeError("" + b + " is not iterable");
                        b = b[Symbol.iterator].call(b);
                        for (var d = b.next(); !d.done; d = b.next()) {
                            d = d.value;
                            if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                            c[d[0]] = d[1]
                        }
                        return c
                    }
                });
                var Nd = __webpack_require__(336105).RewriteFrames;
                var Xd = __webpack_require__(681196).ExtraErrorData;
                var Yd = __webpack_require__(802011).Dedupe;
                __webpack_require__.p = self.__canva_public_path__;
                var E = class extends Error {
                    constructor(a) {
                        super(`unhandled case: ${JSON.stringify(a)}`)
                    }
                };
                var mf = class {
                    constructor(a) {
                        this.type = a
                    }
                };
                var nf = class extends mf {
                        required(a, b) {
                            b = b[a];
                            if (b == null || typeof b !== this.type) throw new TypeError(`expected ${this.type} for property "${a}", found: ${JSON.stringify(b)}`);
                            return b
                        }
                        optional(a, b) {
                            b = b[a];
                            if (b != null) {
                                if (typeof b !== this.type) throw new TypeError(`expected optional ${this.type} for property "${a}", found: ${JSON.stringify(b)}`);
                                return b
                            }
                        }
                    },
                    la = new nf("object");
                var ka = {},
                    ja = {};
                typeof window !== "undefined" && window.location && oa();
                var pa = class {
                        get ok() {
                            return !0
                        }
                        map(a) {
                            return new pa(a(this.value))
                        }
                        constructor(a) {
                            this.value = a
                        }
                    },
                    ra = class {
                        get ok() {
                            return !1
                        }
                        map() {
                            return this
                        }
                        constructor(a) {
                            this.error = a
                        }
                    },
                    ua = qa,
                    va = sa;
                var za = {
                        A: "string"
                    },
                    of = {
                        A: "boolean",
                        defaultValue: !1,
                        Me: 1
                    },
                    pf = {
                        A: "number",
                        defaultValue: 0,
                        Me: 8
                    },
                    qf = {
                        A: "number",
                        defaultValue: 0
                    },
                    rf = {
                        A: "number",
                        defaultValue: 0
                    },
                    sf = a => {
                        const {
                            tag: b,
                            D: c,
                            U: d
                        } = r(a);
                        return xa(qf, c, b, d)
                    },
                    tf = a => {
                        const {
                            tag: b,
                            D: c,
                            U: d
                        } = r(a);
                        return xa(rf, c, b, d)
                    },
                    Q = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return ya(pf, c, b)
                    },
                    R = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return ya(qf, c, b)
                    },
                    uf = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return ya(rf, c, b)
                    },
                    vf = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return {
                            tag: b,
                            K: 4,
                            D: c,
                            A: qf.A
                        }
                    },
                    S = a => {
                        const {
                            tag: b,
                            D: c,
                            U: d
                        } = r(a);
                        return xa(za, c, b, d)
                    },
                    T = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return ya(za, c, b)
                    },
                    wf = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return {
                            tag: b,
                            K: 4,
                            D: c,
                            A: za.A
                        }
                    },
                    U = a => {
                        const {
                            tag: b,
                            D: c,
                            U: d
                        } = r(a);
                        return xa( of , c, b, d)
                    },
                    V = a => {
                        const {
                            tag: b,
                            D: c
                        } = r(a);
                        return ya( of , c, b)
                    },
                    xf = Aa(za),
                    yf = Aa("object");
                var zf = I(() => ({
                    M: u(2, "CONSOLE")
                }));
                var Af = K(() => [1, 2, 3], 1);
                var Bf = I(() => ({
                    name: S(1),
                    value: S(2)
                }));
                var Cf = I(() => ({
                    De: V(1)
                }));
                var Df = I(() => ({
                    Xg: V(1),
                    Sh: R(2),
                    Th: R(3),
                    Uh: R(4)
                }));
                var Ef = I(() => ({
                    type: u(1, "STRING"),
                    value: S(1)
                }));
                var Ff = I(() => ({
                    type: u(2, "BOOL"),
                    value: U(1)
                }));
                var Gf = I(() => ({
                    type: u(3, "INT"),
                    value: sf(1)
                }));
                var Hf = I(() => {
                    const {
                        tag: a,
                        D: b,
                        U: c
                    } = r(1);
                    return {
                        type: u(4, "DOUBLE"),
                        value: xa(pf, b, a, c)
                    }
                });
                var Ad = I(() => ({
                    type: u(5, "ARRAY"),
                    values: z(1, If)
                }));
                var Cd = I(() => ({
                    type: u(6, "KVLIST"),
                    values: z(1, Jf)
                }));
                var If = J(() => ({
                    type: [1, Ef, 2, Ff, 3, Gf, 4, Hf, 5, Ad, 6, Cd]
                }), () => ({}));
                var Jf = I(() => ({
                    name: S(1),
                    value: v(2, If)
                }));
                var Kf = I(() => ({
                    M: u(3, "SENTRY"),
                    dsn: T(28),
                    environment: T(30),
                    release: T(34),
                    sampleRate: Q(29),
                    tracesSampleRate: Q(31),
                    Ug: V(32),
                    Cf: D(33, Af),
                    tags: z(35, Bf),
                    flags: y(36, Cf),
                    Rh: y(37, Df),
                    extra: z(38, Jf),
                    rf: Q(39)
                }));
                var Lf = J(() => ({
                    M: [2, zf, 3, Kf]
                }), () => ({}));
                var Mf = () => ({
                    dh: V(5),
                    Hb: R(6),
                    Gb: R(7),
                    He: R(8),
                    ah: V(9),
                    ni: Q(10),
                    bg: Q(11),
                    source: T(13),
                    ca: T(14),
                    ea: T(4),
                    yf: T(17),
                    deviceId: T(18),
                    sg: T(15),
                    qh: V(16),
                    ih: V(19),
                    Tg: V(20),
                    jh: V(21),
                    hh: V(22),
                    pg: wf(23)
                });
                var Nf = I(() => ({ ...Mf(),
                    M: u(1, "HTTP"),
                    app: S(27),
                    endpoint: S(28),
                    release: T(29),
                    Ne: T(31),
                    $g: V(32),
                    bh: V(33),
                    platform: T(35),
                    variant: T(36)
                }));
                var Of = I(() => ({ ...Mf(),
                    M: u(2, "CONSOLE"),
                    app: S(27)
                }));
                var jf = I(() => ({ ...Mf(),
                    M: u(3, "NOOP")
                }));
                var Pf = J(() => ({
                    M: [1, Nf, 2, Of, 3, jf]
                }), Mf);
                var ld = class {
                    constructor(a, b, c, d) {
                        this.requestHandler = a;
                        this.ob = b;
                        this.ra = c;
                        this.l = d
                    }
                };
                var Va = class {
                    constructor({
                        bb: a
                    }) {
                        this.bb = a
                    }
                };
                var L = class extends Error {
                        constructor(a, b) {
                            super(a);
                            this.sampleRate = b;
                            this.sampleRate = Ra(b)
                        }
                    },
                    $d = class {
                        setupOnce(a, b) {
                            a((c, d) => {
                                const e = b().getIntegration($d);
                                if (!e) return c;
                                if (!(Math.random() < Sa(e, d === null || d === void 0 ? void 0 : d.originalException, c.level))) return null;
                                d = {
                                    sampleRate: Sa(this, d === null || d === void 0 ? void 0 : d.originalException)
                                };
                                c.extra = c.extra != null ? { ...c.extra,
                                    ...d
                                } : d;
                                c.tags = c.tags != null ? { ...c.tags,
                                    ...d
                                } : d;
                                return c
                            })
                        }
                        constructor(a, b) {
                            this.Pc = a;
                            this.Oc = b;
                            this.name = $d.id;
                            this.Pc = Ra(a);
                            this.Oc =
                                Ra(b)
                        }
                    };
                $d.id = "Sampling";
                var Wa = class {
                    constructor(a) {
                        this.j = a
                    }
                };
                var jd = class {
                    constructor(a, b, c, d, e, f) {
                        this.yc = a;
                        this.B = b;
                        this.j = c;
                        this.Fe = d;
                        this.qf = e;
                        this.Kf = f
                    }
                };
                var Ya = class {
                        Dd(a) {
                            if (a.status !== 401) return a
                        }
                    },
                    Za = class {
                        Dd(a) {
                            return a
                        }
                    };
                var Qf = class {
                        async
                        continue (a) {
                            a = await db(this, a);
                            if (a != null) return new Qf(a)
                        }
                        async update(a) {
                            a = this.cursor.update(a);
                            return this.J(a)
                        }
                        async delete() {
                            const a = this.cursor.delete();
                            return this.J(a)
                        }
                        constructor(a) {
                            this.cursor = a;
                            this.J = cb
                        }
                    },
                    Rf = class extends Qf {
                        async
                        continue (a) {
                            a = await db(this, a);
                            if (a != null) return new Rf(a)
                        }
                        get value() {
                            return this.cursor.value
                        }
                        constructor(a) {
                            super(a);
                            this.cursor = a
                        }
                    };
                var Sf = class {
                    async get(a) {
                        a = this.index.get(a);
                        return this.J(a)
                    }
                    async getAll(a, b) {
                        a = this.index.getAll(a, b);
                        return this.J(a)
                    }
                    async getAllKeys(a, b) {
                        a = this.index.getAllKeys(a, b);
                        return this.J(a)
                    }
                    async count(a) {
                        a = this.index.count(a);
                        return this.J(a)
                    }
                    async openCursor(a, b) {
                        a = this.index.openCursor(a, b);
                        a = await this.J(a);
                        return a != null ? new Rf(a) : void 0
                    }
                    async openKeyCursor(a, b) {
                        a = this.index.openKeyCursor(a, b);
                        a = await this.J(a);
                        return a != null ? new Qf(a) : void 0
                    }
                    constructor(a) {
                        this.index = a;
                        this.J = cb
                    }
                };
                var Tf = class {
                    index(a) {
                        return new Sf(this.store.index(a))
                    }
                    async put(a, b) {
                        a = this.store.put(a, b);
                        return this.J(a)
                    }
                    async get(a) {
                        a = this.store.get(a);
                        return this.J(a)
                    }
                    async delete(a) {
                        a = this.store.delete(a);
                        return this.J(a)
                    }
                    async clear() {
                        const a = this.store.clear();
                        return this.J(a)
                    }
                    async getAll(a, b) {
                        a = this.store.getAll(a, b);
                        return this.J(a)
                    }
                    async getAllKeys(a, b) {
                        a = this.store.getAllKeys(a, b);
                        return this.J(a)
                    }
                    async count(a) {
                        a = this.store.count(a);
                        return this.J(a)
                    }
                    async openCursor(a, b) {
                        a = this.store.openCursor(a,
                            b);
                        a = await this.J(a);
                        return a != null ? new Rf(a) : void 0
                    }
                    async openKeyCursor(a, b) {
                        a = this.store.openKeyCursor(a, b);
                        a = await this.J(a);
                        return a != null ? new Qf(a) : void 0
                    }
                    createIndex(a, b, c) {
                        return this.store.createIndex(a, b, c)
                    }
                    deleteIndex(a) {
                        return this.store.deleteIndex(a)
                    }
                    constructor(a) {
                        this.store = a;
                        this.J = cb
                    }
                };
                var Uf = class {
                        objectStore(a) {
                            a = this.Y.objectStore(a);
                            return new Tf(a)
                        }
                        abort() {
                            this.Y.abort()
                        }
                        commit() {
                            this.Y.commit()
                        }
                        get error() {
                            return this.Y.error
                        }
                        constructor(a) {
                            this.Y = a;
                            this.jg = fb(this)
                        }
                    },
                    eb = class extends Error {
                        constructor() {
                            super("Transaction was aborted")
                        }
                    };
                var gb = class {
                    transaction(a, b) {
                        return new Uf(this.db.transaction(a, b))
                    }
                    createObjectStore(a, b) {
                        return new Tf(this.db.createObjectStore(a, b))
                    }
                    get objectStoreNames() {
                        return this.db.objectStoreNames
                    }
                    close() {
                        this.db.close()
                    }
                    addEventListener(a, b, c) {
                        this.db.addEventListener(a, b, c)
                    }
                    removeEventListener(a, b, c) {
                        this.db.removeEventListener(a, b, c)
                    }
                    constructor(a) {
                        this.db = a
                    }
                };
                var ib = class extends Error {
                        constructor(a) {
                            super("Quota exceeded");
                            this.cause = a
                        }
                    },
                    jb, tb = class extends Error {
                        constructor() {
                            super("Consent required")
                        }
                    },
                    lb = class extends L {
                        constructor(a) {
                            super("IndexedDb Database Error", 0);
                            this.cause = a
                        }
                    },
                    mb, vb = class extends Error {
                        constructor() {
                            super("Maximum number of rows exceeded for put request")
                        }
                    },
                    ub = class extends Error {
                        constructor(a) {
                            super("Failed to deserialize stored data");
                            this.cause = a
                        }
                    };
                var ob = class {
                    get cf() {
                        return this.connection != null
                    }
                    transaction(a, b) {
                        if (this.connection == null) throw Error("Attempted to open a transaction on a closed connection");
                        self.clearTimeout(this.ub);
                        this.ub = void 0;
                        const c = this.connection;
                        try {
                            this.mc++;
                            const d = c.transaction(a, b),
                                e = d.jg;
                            e.catch(() => this.dispose()).finally(() => {
                                this.mc--;
                                this.mc <= 0 && (this.ub = self.setTimeout(() => {
                                    this.dispose()
                                }, 2500))
                            });
                            return {
                                transaction: d,
                                Id: e
                            }
                        } catch (d) {
                            throw this.dispose(), d;
                        }
                    }
                    dispose() {
                        var a;
                        (a = this.connection) === null || a ===
                            void 0 || a.close();
                        this.connection = void 0;
                        self.clearTimeout(this.ub)
                    }
                    constructor(a) {
                        this.connection = a;
                        this.mc = 0
                    }
                };
                var yb = class {
                    constructor(a, b) {
                        this.Ze = a;
                        this.l = b
                    }
                };
                var xb = class {
                    constructor(a, b) {
                        this.Yc = a;
                        this.l = b
                    }
                };
                var wb = class {
                    async put(a, b, c) {
                        await Bb(this);
                        const d = Db(a, this.Rb.va(b));
                        return N(this.ia, {
                            H: this.H,
                            mode: "readwrite",
                            V: async e => {
                                const {
                                    Ii: f
                                } = c !== null && c !== void 0 ? c : {};
                                if (f != null) {
                                    p(f > 0);
                                    const [g, h] = await Promise.all([e.get(a).then(k => !!k), e.count()]);
                                    if (h + (g ? 0 : 1) > f) throw new vb;
                                }
                                await e.put(d)
                            },
                            methodName: "put"
                        })
                    }
                    async get(a) {
                        const b = await N(this.ia, {
                            H: this.H,
                            mode: "readonly",
                            V: async c => c.get(a),
                            methodName: "get"
                        });
                        return b != null ? this.P(Cb(b)) : void 0
                    }
                    async delete(a) {
                        return N(this.ia, {
                            H: this.H,
                            mode: "readwrite",
                            V: async b => {
                                Array.isArray(a) ? await Promise.all(a.map(c => b.delete(c))) : await b.delete(a)
                            },
                            methodName: "delete"
                        })
                    }
                    async count() {
                        return N(this.ia, {
                            H: this.H,
                            mode: "readonly",
                            V: async a => a.count(),
                            methodName: "count"
                        })
                    }
                    async update(a, b) {
                        await Bb(this);
                        return N(this.ia, {
                            H: this.H,
                            mode: "readwrite",
                            V: async c => {
                                var d = await c.get(a);
                                d = d ? {
                                    value: this.P(Cb(d))
                                } : void 0;
                                d = b(d);
                                d != null ? await c.put(Db(a, this.Rb.va(d.value))) : await c.delete(a)
                            },
                            methodName: "update"
                        })
                    }
                    async getAll(a, b) {
                        const c = await N(this.ia, {
                                H: this.H,
                                mode: "readonly",
                                V: async f => {
                                    const g = typeof b === "string" ? f.index(b) : f;
                                    try {
                                        return (await g.getAll(a)).map(h => ua(h))
                                    } catch (h) {
                                        return f = await g.getAllKeys(a), Promise.all(f.map(async k => {
                                            try {
                                                const l = await g.get(k);
                                                return ua(l)
                                            } catch (l) {
                                                return va({
                                                    key: String(k),
                                                    error: l instanceof Error ? l : Error(String(l))
                                                })
                                            }
                                        }))
                                    }
                                },
                                methodName: "getAll"
                            }),
                            d = [],
                            e = [];
                        for (const f of c)
                            if (f.ok) try {
                                d.push({
                                    key: Fb(f.value),
                                    rd: this.P(Cb(f.value))
                                })
                            } catch (g) {
                                e.push({
                                    key: Fb(f.value),
                                    error: g instanceof Error ? g : Error(String(g))
                                })
                            } else e.push({
                                key: f.error.key,
                                error: f.error.error
                            });
                        return {
                            items: d,
                            errors: e
                        }
                    }
                    async getAllKeys() {
                        return N(this.ia, {
                            H: this.H,
                            mode: "readonly",
                            V: async a => (await a.getAllKeys()).map(b => String(b)) || [],
                            methodName: "getAllKeys"
                        })
                    }
                    async clear() {
                        return N(this.ia, {
                            H: this.H,
                            mode: "readwrite",
                            V: async a => a.clear(),
                            methodName: "clear"
                        })
                    }
                    close() {}
                    P(a) {
                        try {
                            return this.Rb.P(a)
                        } catch (b) {
                            throw new ub(b instanceof Error ? b : Error(String(b)));
                        }
                    }
                    constructor(a, b, c, d) {
                        this.H = a;
                        this.Rb = b;
                        this.ia = c;
                        this.xb = d
                    }
                };
                var Lb = class {
                    async fetch(a) {
                        if (this.B.Pa()) throw Error("Is force offline");
                        if (a.request.mode === "navigate") {
                            const b = await a.preloadResponse;
                            if (b != null && b.status !== 401) return b;
                            if (this.ud != null) return a = await Kb(this.ud, a.request), this.qc(a)
                        }
                        return this.qc(a.request, {
                            redirect: "follow"
                        })
                    }
                    constructor(a, b, c) {
                        this.B = a;
                        this.ud = b;
                        this.qc = c
                    }
                };
                var Mb = class {
                    constructor(a) {
                        this.options = {
                            Rf: self.navigator.userAgent,
                            targetOrigin: self.location.origin
                        };
                        this.Df = a
                    }
                };
                var Vf = K(() => [1, 2, {
                    Ha: !0
                }, 3, {
                    Ha: !0
                }]);
                var Wf = I(() => ({
                    status: C(1, Vf)
                }));
                var Tb = class {
                    async hc(a) {
                        a = await this.store.get(a);
                        return a === null || a === void 0 ? void 0 : a.status
                    }
                    constructor(a, b = {
                        Ca: (...c) => Ab(...c)
                    }) {
                        this.store = b.Ca("private_data_persist_consent", Wf, void 0, [], a)
                    }
                };
                var Xf = I(() => ({
                    ca: S(1),
                    ea: S(2)
                }));
                var Sb = class {
                    async put(a, {
                        ca: b,
                        ea: c
                    }) {
                        await this.store.put(a, new Xf({
                            ca: b,
                            ea: c
                        }))
                    }
                    async getAll() {
                        const {
                            items: a,
                            errors: b
                        } = await this.store.getAll();
                        if (b.length > 0) throw b[0].error;
                        return a.map(c => ({
                            Ei: c.key,
                            rd: c.rd
                        }))
                    }
                    async delete(a) {
                        await this.store.delete(a)
                    }
                    constructor(a, b = {
                        Ca: (...c) => Ab(...c)
                    }) {
                        this.store = b.Ca("storage_layer_name", Xf, void 0, [], a)
                    }
                };
                var Yf = {
                        editor_page_bootstraps: !0,
                        homepage_bootstraps: !1,
                        lesson_config: !1,
                        offline_designs: !0,
                        offline_document_response: !0,
                        document_resources: !0
                    },
                    Zf = {
                        editor_page_bootstraps: [],
                        homepage_bootstraps: [],
                        lesson_config: [],
                        offline_designs: [],
                        offline_document_response: [],
                        document_resources: [{
                            name: "documents",
                            Cb: "E",
                            multiEntry: !0
                        }],
                        storage_layer_name: [],
                        private_data_persist_consent: [],
                        active_user_brand_hint_for_service_worker_to_serve_pages: [],
                        offline_fallback_bootstrap: [],
                        config: [],
                        asset_metadata: [],
                        manifests: [],
                        leadership_lock: [],
                        index_example: [{
                            name: "indexName",
                            Cb: "values",
                            multiEntry: !0
                        }],
                        design_asset_references: [{
                            name: "referrer_ids_idx",
                            Cb: "A",
                            multiEntry: !0
                        }],
                        page_asset_references: [{
                            name: "referrer_ids_idx",
                            Cb: "A",
                            multiEntry: !0
                        }]
                    };
                var Ub = class {
                    constructor(a, b, c, d, e, f = {
                        Ca: (...k) => Ab(...k)
                    }, g = Yf, h = Zf) {
                        this.Ic = a;
                        this.Vf = b;
                        this.xb = c;
                        this.j = d;
                        this.l = e;
                        this.fd = f;
                        this.ne = g;
                        this.Zc = h
                    }
                };
                var Kc = class extends Ub {
                    constructor(a, b, c, d, e, f = {
                        Ca: (...k) => Ab(...k)
                    }, g = Yf, h = Zf) {
                        super(a, b, c, d, e, f, g, h);
                        this.Ic = a
                    }
                };
                var Xb;
                var ac = class {
                    get vc() {
                        return [...this.Kc]
                    }
                    constructor({
                        vc: a,
                        Oa: b,
                        Eb: c
                    }) {
                        this.Kc = new Set(a.filter(d => !!d));
                        this.Eb = c || void 0;
                        this.Oa = b
                    }
                };
                var ec = class {
                        async fc() {
                            this.fa == null && (this.fa = self.caches.open(this.cacheName), self.setTimeout(() => {
                                this.fa = void 0
                            }, 5E3));
                            return this.fa
                        }
                        constructor(a, b) {
                            this.l = b;
                            this.options = void 0;
                            this.cacheName = $f[1];
                            this.db = Pb(a, ag[1], ac)
                        }
                    },
                    ag = {
                        [0]: "design_asset_references",
                        [1]: "page_asset_references"
                    },
                    $f = {
                        [0]: "media",
                        [1]: "assets-2"
                    };
                var fc = class {
                    ya({
                        url: a
                    }) {
                        return this.B.options.he !== 1 ? a.hostname.startsWith("chunk-composing.") && a.searchParams.get("preserve-source-map-comments") !== "true" : !1
                    }
                    async handle(a, b) {
                        return this.I.fetch(a).then(c => {
                            a.waitUntil(dc(this, c, b));
                            return c
                        })
                    }
                    constructor(a, b, c, d, e, f, g) {
                        this.B = a;
                        this.N = b;
                        this.I = c;
                        this.ge = d;
                        this.je = e;
                        this.j = f;
                        this.l = g;
                        this.name = "chunk-composing"
                    }
                };
                var hd = class {
                    ya(a) {
                        return a.url.pathname === "/__sw_debug_info"
                    }
                    async handle() {
                        return new Response(this.$a.Pe(), {
                            headers: {
                                "content-type": "text/plain"
                            }
                        })
                    }
                    constructor(a) {
                        this.$a = a;
                        this.name = "debug_info"
                    }
                };
                var bg = /[^a-zA-Z0-9]/g,
                    oc = class {
                        async match(a, {
                            G: b
                        } = {}) {
                            const c = async d => {
                                try {
                                    const e = await (await this.fc()).match(this.Hc(a));
                                    d === null || d === void 0 || d.setAttribute("cache_hit", e != null);
                                    return e
                                } catch (e) {
                                    this.fa = null, d === null || d === void 0 || d.setStatus("error"), this.j.error(new L(e instanceof Error ? e.message : String(e), .01))
                                }
                            };
                            if (this.l != null && b != null) {
                                const d = `browser_cache_storage.${this.cacheName.replace(bg,"_")}.match`;
                                return this.l.Nb(d, b, c)
                            }
                            return c()
                        }
                        async fc() {
                            this.fa == null && (this.fa = caches.open(this.cacheName),
                                setTimeout(() => {
                                    this.fa = null
                                }, 1E3));
                            return this.fa
                        }
                        constructor({
                            cacheName: a,
                            Hc: b = e => e
                        }, c, d) {
                            this.j = c;
                            this.l = d;
                            this.fa = null;
                            this.cacheName = a;
                            this.Hc = b
                        }
                    };
                var cg = new Set("audio-private audio-public audio-upload blobs document-export font-private font-public media media-private media-public media-transformation mockup-assets print-product-assets template upload video-placeholders video-private-assets video-public video-upload".split(" ")),
                    pc = class {
                        ya({
                            url: a
                        }) {
                            if (this.B.options.Qc === 1) return !1;
                            if (a.hostname === "localhost" && !/\.js$|\.css$/.test(a.pathname)) return !0;
                            [a] = a.hostname.split(".");
                            return cg.has(a)
                        }
                        async handle(a, b) {
                            if (this.B.options.Qc === 2) try {
                                return await this.I.fetch(a)
                            } catch (c) {
                                a =
                                    await ic(this, a, b);
                                if (a != null) return a;
                                throw c;
                            }
                            b = await ic(this, a, b);
                            return b !== null && b !== void 0 ? b : this.I.fetch(a)
                        }
                        constructor(a, b, c, d) {
                            this.B = a;
                            this.mf = b;
                            this.Mb = c;
                            this.I = d;
                            this.name = "design_asset"
                        }
                    };
                var kc = /^bytes=(\d+)?-(\d+)?$/;
                var lc = ["X-Shaka-From-Cache", "true"],
                    mc = class {
                        constructor({
                            j: a
                        }) {
                            this.j = a
                        }
                    };
                var rc = class {
                    ya({
                        url: a
                    }) {
                        return this.B.options.nd !== 1 ? a.hostname === "localhost" && /\.js$|\.css$/.test(a.pathname) && !a.pathname.includes("_web_worker") ? !0 : a.href.startsWith(this.options.N) : !1
                    }
                    async handle(a, b) {
                        if (this.B.options.nd === 2) try {
                            return await this.I.fetch(a)
                        } catch (c) {
                            a = await this.Lc.match(a.request.url, {
                                G: b
                            });
                            if (a != null) return a;
                            throw c;
                        }
                        b = await this.Lc.match(a.request.url, {
                            G: b
                        });
                        return b != null ? b : this.I.fetch(a)
                    }
                    constructor(a, b, c, d) {
                        this.options = a;
                        this.B = b;
                        this.I = c;
                        this.Lc = d;
                        this.name = "page_asset"
                    }
                };
                var tc = class {
                    constructor(a) {
                        this.path = a;
                        this.Sa = new Map
                    }
                };
                var dg = K(() => [1, 2], 1);
                var Qb = I(() => ({
                    app: S(1),
                    url: S(2),
                    title: S(3),
                    locale: S(4),
                    direction: C(5, dg),
                    timestamp: tf(7),
                    xa: S(8),
                    Fc: S(9),
                    kb: S(10),
                    dc: T(11)
                }));
                var yc = class {
                    async eb(a) {
                        a = await this.db.get(this.cg.normalizeUrl(a.href));
                        const b = Date.now() / 1E3;
                        if (this.options.mb || a && a.timestamp + 1209600 > b) return a
                    }
                    constructor(a, b, c = {
                        normalizeUrl: d => d
                    }) {
                        this.options = a;
                        this.db = b;
                        this.cg = c
                    }
                };
                var W = I(() => ({
                    filename: S(1),
                    Fh: V(4),
                    locale: T(5),
                    zd: T(6)
                }));
                var eg = I(() => ({
                    Ya: z(1, W),
                    Ba: z(2, W)
                }));
                var fg = I(() => ({
                    bf: v(1, eg),
                    Rd: v(2, eg)
                }));
                var gg = I(() => ({
                    Hd: v(1, fg)
                }));
                var hg = I(() => ({
                    Di: S(1)
                }));
                var ig = I(() => ({
                    Ni: uf(1)
                }));
                var jg = I(() => ({
                    Ya: wf(1),
                    Ba: wf(2),
                    Bi: xf(3)
                }));
                var kg = I(() => ({
                    rel: S(1),
                    href: S(2),
                    zd: T(6)
                }));
                var lg = I(() => ({
                    Ya: z(1, W),
                    Ba: z(2, W)
                }));
                var mg = I(() => ({
                    id: S(1),
                    Fg: z(2, W),
                    Hh: z(3, W),
                    Be: z(4, W),
                    Jh: yf(5, lg),
                    Mh: v(6, lg),
                    ri: v(7, lg),
                    Ci: wf(8),
                    Ih: sf(9),
                    mi: V(10)
                }));
                var ng = I(() => ({
                    app: S(1),
                    Mc: v(9, eg),
                    vd: v(8, gg),
                    Be: z(10, W),
                    li: z(13, W),
                    fonts: y(14, hg),
                    build: v(3, ig),
                    df: yf(4, jg),
                    tc: T(6),
                    ci: T(15),
                    di: T(16),
                    viewport: T(7),
                    links: z(11, kg),
                    kh: T(18),
                    yg: yf(17, mg),
                    dj: yf(25, mg)
                }));
                var Lc = I(() => ({
                    Fb: v(1, ng),
                    commit: S(5),
                    variant: T(4),
                    timestamp: tf(2),
                    locale: S(3),
                    direction: C(6, dg),
                    Cc: S(7)
                }));
                var Nc = class {
                    constructor(a, b) {
                        this.db = a;
                        this.l = b
                    }
                };
                var Jc = I(() => ({
                    ca: S(1),
                    ea: S(2)
                }));
                var og = K(() => [0, "CLIENT_FULL", 1, "CLIENT_HYDRATE", 2, "SERVER_FULL"]);
                var pg = K(() => [1, 3, 2], 1);
                var qg = I(() => ({
                    action: u(1, "REGISTER"),
                    si: S(1),
                    scope: S(2)
                }));
                var rg = I(() => ({
                    action: u(2, "UNREGISTER")
                }));
                var sg = I(() => ({
                    action: u(3, "UPDATE")
                }));
                var tg = I(() => ({
                    action: u(4, "RETAIN")
                }));
                var ug = J(() => ({
                    action: [1, qg, 2, rg, 3, sg, 4, tg]
                }), () => ({}));
                var vg = I(() => ({
                    fj: S(1),
                    ej: R(2)
                }));
                var wg = K(() => [1, 2]);
                var xg = K(() => [1, 2, 3, 4]);
                var yg = I(() => ({
                    category: C(1, xg),
                    name: S(2)
                }));
                var zg = I(() => ({
                    og: U(15),
                    zi: U(12),
                    Qi: U(13),
                    xg: U(1),
                    Pg: U(2),
                    Sg: U(7),
                    Wg: U(14),
                    Bg: S(3),
                    Nh: S(9),
                    ei: S(10),
                    ji: z(5, yg),
                    $h: T(6),
                    Ch: vf(16),
                    Ag: vf(17),
                    Og: V(18),
                    wh: V(19),
                    fh: V(20),
                    gh: V(21)
                }));
                var Ag = I(() => ({
                    traceId: S(1),
                    spanId: S(2),
                    Dc: sf(3)
                }));
                var Bg = I(() => ({
                    href: S(1),
                    zd: T(3)
                }));
                var Cg = () => ({
                    oi: U(12),
                    Yg: U(14),
                    commit: S(5),
                    timestamp: uf(11),
                    j: v(6, Lf),
                    ki: C(7, og),
                    O: C(9, pg),
                    xi: y(15, ug),
                    cj: y(4, vg),
                    Wh: T(13),
                    $c: D(17, wg),
                    Li: y(18, zg),
                    Ad: y(20, Pf),
                    Zh: y(24, Ag),
                    bi: z(21, Bg),
                    Ri: wf(22),
                    ee: T(34)
                });
                var Dg = I(() => ({
                    Ji: S(1),
                    ph: tf(2)
                }));
                var Eg = I(() => ({
                    Qd: T(1),
                    tg: T(9),
                    Td: T(2),
                    Ud: T(3),
                    Nd: T(14),
                    fg: T(12),
                    Zd: T(4),
                    ff: T(10),
                    app: T(11),
                    ce: T(5),
                    de: T(6),
                    wi: T(7),
                    Eg: yf(8, Dg)
                }));
                var Fg = I(() => ({
                    Qd: T(1),
                    Td: T(2),
                    Ud: T(3),
                    Nd: T(10),
                    fg: T(9),
                    Zd: T(4),
                    ff: T(5),
                    app: T(6),
                    ce: T(7),
                    de: T(8)
                }));
                var Gg = I(() => ({
                    url: S(1),
                    context: y(2, Fg)
                }));
                var Hg = I(() => ({
                    Ge: S(27)
                }));
                var Ig = I(() => ({
                    Ge: S(27),
                    Cg: T(28),
                    locale: S(29),
                    zg: R(30),
                    ea: T(31),
                    yf: T(37),
                    ca: T(34),
                    nh: T(32),
                    sh: T(33),
                    deviceId: T(35)
                }));
                var Jg = () => ({
                    Ui: y(3, Hg),
                    mh: v(4, Ig),
                    oh: xf(5),
                    appName: T(9),
                    Dh: vf(16),
                    Hi: vf(17),
                    Rg: U(18),
                    Mg: V(19)
                });
                var Kg = I(() => ({ ...Jg(),
                    M: u(2, "CONSOLE")
                }));
                var Lg = I(() => ({ ...Jg(),
                    M: u(8, "NOOP")
                }));
                var Mg = I(() => ({
                    containerId: S(1)
                }));
                var Ng = I(() => ({
                    mg: S(1),
                    projectId: S(2)
                }));
                var Og = I(() => ({
                    Sd: S(1)
                }));
                var Pg = I(() => ({}));
                var Qg = I(() => ({
                    zh: y(2, Mg),
                    Xh: y(4, Ng),
                    ug: y(6, Og),
                    yh: y(7, Pg)
                }));
                var Rg = I(() => ({ ...Jg(),
                    M: u(14, "PRODUCT_ANALYTICS"),
                    plugins: y(32, Qg),
                    aj: R(36),
                    eh: U(37),
                    bj: U(40),
                    Vg: U(45),
                    Qg: U(47)
                }));
                var Sg = J(() => ({
                    M: [2, Kg, 8, Lg, 14, Rg]
                }), Jg);
                var Tg = I(() => ({
                    M: u(1, "NONE")
                }));
                var Ug = I(() => ({
                    M: u(2, "FULLSTORY"),
                    Yh: S(28)
                }));
                var Vg = J(() => ({
                    M: [1, Tg, 2, Ug]
                }), () => ({}));
                var X = K(() => [1, 2, 3, 4]);
                var Wg = I(() => ({
                    Kg: D(1, X),
                    hi: D(2, X),
                    Ph: D(4, X),
                    Oh: D(8, X),
                    Ti: D(5, X),
                    pi: D(6, X),
                    Jg: D(7, X),
                    Hg: D(10, X),
                    yi: D(9, X),
                    Vi: D(11, X),
                    Lg: D(12, X),
                    wg: D(13, X),
                    Dg: D(14, X),
                    ng: D(15, X)
                }));
                var Xg = I(() => ({
                    ai: v(1, Wg),
                    gi: U(2)
                }));
                var Yg = I(() => ({
                    ca: T(1),
                    Sd: S(2),
                    Pi: U(3),
                    Si: y(4, Xg)
                }));
                var Zg = I(() => ({
                    url: S(1),
                    rg: T(2),
                    Oi: U(3),
                    Zi: T(4)
                }));
                var $g = I(() => ({ ...Cg(),
                    mode: u(2, "REAL"),
                    Bh: v(27, Eg),
                    $i: v(30, Gg),
                    qg: v(28, Sg),
                    Eh: y(29, Vg),
                    vg: y(32, Yg),
                    ui: y(31, Zg)
                }));
                var ah = I(() => ({ ...Cg(),
                    mode: u(3, "FAKE"),
                    Fi: sf(27),
                    hostname: T(28)
                }));
                var Hc = J(() => ({
                    mode: [2, $g, 3, ah]
                }), Cg);
                var Mc = class {
                    constructor(a, b, c) {
                        this.options = a;
                        this.Yd = b;
                        this.hf = c
                    }
                };
                var Xc = class {
                    constructor(a, b) {
                        this.rules = a;
                        this.fallback = b
                    }
                };
                var bh = ["iOi0iWfdfKTOZE7Vp8+d8Cvsk9vE8DL4J4a5fgzlsUk="],
                    ch = class {
                        createPolicy({
                            page: a,
                            nonce: b
                        }) {
                            return [
                                ["frame-ancestors", "'none'"],
                                ["base-uri", "'self'"],
                                ["object-src", "'none'"],
                                ["script-src", `'report-sample' 'strict-dynamic' 'unsafe-eval' 'nonce-${b}' ${bh.map(c=>`'sha256-${c}'`).join(" ")}`],
                                ["report-uri", `https://csp.canva.com/_cspreport?app=sw_${a}&ro=true`]
                            ].map(([c, d]) => `${c} ${d}`).join("; ")
                        }
                    };
                var Zc = class {
                    constructor(a) {
                        this.config = a
                    }
                };
                var dh = class {
                    constructor() {
                        this.crypto = self.crypto
                    }
                };
                var Yc = class {
                    constructor(a) {
                        this.Rc = a
                    }
                };
                var $c = class {
                    constructor(a, b, c, d, e, f) {
                        var g = new dh,
                            h = new ch;
                        this.config = a;
                        this.Mf = b;
                        this.j = c;
                        this.od = d;
                        this.tf = e;
                        this.sf = g;
                        this.qe = h;
                        this.l = f
                    }
                };
                var bd = class {
                    ya({
                        request: a
                    }) {
                        return this.B.options.Jb !== 1 ? a.mode === "navigate" : !1
                    }
                    async handle(a, b) {
                        let c;
                        try {
                            if (c = await this.I.fetch(a), (c === null || c === void 0 ? void 0 : c.status) !== 0 || (c === null || c === void 0 ? 0 : c.type.includes("opaque"))) return c
                        } catch (e) {}
                        var d = this.B;
                        return d.options.Jb !== 5 && d.options.Jb !== 1 && (d = this.options.ma, a = Wc(this.zf, new URL(a.request.url), {
                            G: b
                        }), a = d != null && d > 500 ? await Promise.race([a, ab(d)]) : await a, a === null || a === void 0 ? 0 : a.ok) ? a : c !== null && c !== void 0 ? c : Response.error()
                    }
                    constructor(a,
                        b, c, d) {
                        this.options = a;
                        this.B = b;
                        this.I = c;
                        this.zf = d;
                        this.name = "page"
                    }
                };
                var gd = class {
                    ya({
                        url: a
                    }) {
                        return a.pathname === "/popout"
                    }
                    async handle(a) {
                        try {
                            return await this.I.fetch(a)
                        } catch (b) {
                            return new Response(null, {
                                headers: {
                                    "content-type": "text/plain",
                                    "content-security-policy": "frame-ancestors 'self'; base-uri 'self'; object-src 'none'; script-src 'none'; report-uri https://csp.canva.com/_cspreport?app=popout;"
                                }
                            })
                        }
                    }
                    constructor(a) {
                        this.I = a;
                        this.name = "popout"
                    }
                };
                var eh = ["/_ajax/", "/local-intercept/", "/_online"],
                    fh = new Set(["GET"]),
                    fd = class {
                        resolve(a) {
                            if (fh.has(a.method)) {
                                var b = new URL(a.url);
                                if (!eh.some(c => b.pathname.startsWith(c)) && (b.hostname !== "localhost" || b.origin === this.options.Qf)) return this.Lf.find(c => c.ya({
                                    request: a,
                                    url: b
                                }))
                            }
                        }
                        constructor(a) {
                            this.options = {
                                Qf: self.location.origin
                            };
                            this.Lf = a
                        }
                    };
                var dd = class {
                    ya({
                        url: a
                    }) {
                        return this.B.options.hg !== 1 ? a.pathname.startsWith("/_web_worker/") : !1
                    }
                    async handle(a, b) {
                        try {
                            return await this.I.fetch(a)
                        } catch (c) {
                            a = await this.gg.match(a.request.url, {
                                G: b
                            });
                            if (a != null) return a;
                            throw c;
                        }
                    }
                    constructor(a, b, c) {
                        this.B = a;
                        this.I = b;
                        this.gg = c;
                        this.name = "web_worker"
                    }
                };
                var gh = () => ({
                    requestId: S(1)
                });
                var hh = I(() => ({ ...gh(),
                    message: u(2, "OVERRIDE_NETWORK_STRATEGY"),
                    Db: U(2)
                }));
                var ih = I(() => ({ ...gh(),
                    message: u(3, "GET_SW_RELEASE")
                }));
                var jh = I(() => ({ ...gh(),
                    message: u(4, "SKIP_WAITING")
                }));
                var nd = J(() => ({
                    message: [2, hh, 3, ih, 4, jh]
                }), gh);
                var od = I(() => ({
                    message: u(3, "GET_SW_RELEASE"),
                    requestId: S(1),
                    release: S(2)
                }));
                var pd = I(() => ({
                    message: u(2, "OVERRIDE_NETWORK_STRATEGY"),
                    requestId: S(1),
                    Pa: U(2)
                }));
                var qd = I(() => ({
                    message: u(4, "SKIP_WAITING"),
                    requestId: S(1)
                }));
                var rd = I(() => ({
                    message: u(1, "MESSAGE_NOT_RECOGNISED"),
                    If: S(1)
                }));
                var sd = J(() => ({
                    message: [1, rd, 2, pd, 3, od, 4, qd]
                }), () => ({}));
                var ud = class {
                    constructor(a, b, c, d) {
                        this.options = a;
                        this.serviceWorker = b;
                        this.B = c;
                        this.l = d
                    }
                };
                var kh = class {
                    Pa() {
                        return this.Db
                    }
                    constructor(a) {
                        this.options = a;
                        this.Db = !1
                    }
                };
                var lh = K(() => [1, "N", 2, "O", 3, "A", 4, "C", {
                    Ha: !0
                }, 5, "B", 6, "D"]);
                var mh = I(() => ({
                    be: S(1),
                    $d: R(2),
                    ae: R(3),
                    gj: T(4)
                }));
                var nh = () => ({
                    j: v(1, Lf),
                    O: C(8, pg),
                    Ve: C(11, lh),
                    We: C(12, lh),
                    Ue: C(7, lh),
                    Ye: C(40, lh),
                    Te: D(41, lh),
                    Zg: U(38),
                    ha: U(39),
                    hb: T(14),
                    Je: R(18),
                    Tc: U(20),
                    Ce: U(31),
                    Ee: U(21),
                    release: S(22),
                    Ad: y(26, Pf),
                    Wf: Q(36),
                    Xf: R(37),
                    ga: U(30),
                    userAgent: y(35, mh)
                });
                var oh = I(() => ({ ...nh(),
                    mode: u(2, "REAL"),
                    N: S(27)
                }));
                var ph = I(() => ({ ...nh(),
                    mode: u(3, "FAKE")
                }));
                var qh = J(() => ({
                    mode: [2, oh, 3, ph]
                }), nh);
                var rh = !1,
                    sh = class {
                        setTag(a, b) {
                            this.tags[a] = b
                        }
                        setContext(a) {
                            this.context = a
                        }
                        error(a, b) {
                            this.console.error(...wd(this, "error", a, b))
                        }
                        F(a, b) {
                            this.console.error(...wd(this, "error", a, b))
                        }
                        Gd(a, b) {
                            this.console.warn(...wd(this, "warning", a, b))
                        }
                        info(a, b) {
                            this.console.info(...wd(this, "info", a, b))
                        }
                        debug(a, b) {
                            this.console.debug(...wd(this, "debug", a, b))
                        }
                        toJSON() {
                            return {
                                name: this.name,
                                context: this.context,
                                tags: this.tags
                            }
                        }
                        constructor() {
                            var a = console;
                            this.name = "default";
                            this.tags = {};
                            if (!rh && typeof window === "object") {
                                const b =
                                    window.onerror;
                                window.onerror = (...d) => {
                                    typeof b === "function" && b(...d);
                                    console.error("unhandled error:", ...d)
                                };
                                const c = window.onunhandledrejection;
                                window.onunhandledrejection = d => {
                                    typeof c === "function" && c(d);
                                    console.error("[ConsoleErrorClient]: Unhandled promise rejection", d)
                                };
                                rh = !0
                            }
                            p(!0, "name must not contain a dot");
                            a instanceof sh ? (this.name = `${a.name}.${"default"}`, this.console = a.console) : this.console = a
                        }
                    };
                var th = class {
                    constructor() {
                        this.wd = {}
                    }
                };
                var de = class {
                    setupOnce(a, b) {
                        a(c => {
                            const d = b().getIntegration(de);
                            return d ? Id(d, c) ? null : c : c
                        })
                    }
                    constructor(a = []) {
                        this.Od = a;
                        this.name = de.id
                    }
                };
                de.id = "FilterErrors";
                var ae = class {
                    setupOnce(a, b) {
                        a(c => {
                            b().getIntegration(ae);
                            return c
                        })
                    }
                    constructor() {
                        this.name = ae.id
                    }
                };
                ae.id = "HostRpcServiceErrors";
                var be = class {
                    setupOnce(a, b) {
                        a(c => {
                            b().getIntegration(be);
                            return c
                        })
                    }
                    constructor() {
                        this.name = be.id
                    }
                };
                be.id = "HttpServiceErrors";
                var Ld = {
                    now: () => Date.now()
                };
                var uh = class {
                        add(a) {
                            this.Za = this.Qe(this.Za);
                            this.list[this.Za] = a
                        }
                        find(a) {
                            let b = this.Za;
                            do {
                                if (this.list[b] && a(this.list[b])) return this.list[b];
                                b = this.Re(b)
                            } while (b !== this.Za)
                        }
                        constructor() {
                            this.Xb = 10;
                            this.Za = 0;
                            this.Qe = a => (a + 1) % this.Xb;
                            this.Re = a => (a + this.Xb - 1) % this.Xb;
                            this.list = Array(10)
                        }
                    },
                    Zd = class {
                        setupOnce(a, b) {
                            a(c => {
                                const d = b().getIntegration(Zd);
                                d && (Md(d, c) ? c = null : d.history.add({
                                    event: c,
                                    timestamp: Ld.now()
                                }));
                                return c
                            })
                        }
                        constructor(a) {
                            this.$f = a;
                            this.name = Zd.id;
                            this.history = new uh
                        }
                    };
                Zd.id = "NoSuccessiveEvent";
                var Wd = class {
                    setupOnce(a, b) {
                        a(c => {
                            var d, e;
                            if (!b().getIntegration(Wd)) return c;
                            var f;
                            c.tags = (f = c.tags) !== null && f !== void 0 ? f : {};
                            c.tags["prior.unhandled.error.count"] = this.td;
                            ((e = c.exception) === null || e === void 0 ? 0 : (d = e.values) === null || d === void 0 ? 0 : d.some(g => {
                                var h;
                                return ((h = g.mechanism) === null || h === void 0 ? void 0 : h.handled) === !1
                            })) && this.td++;
                            return c
                        })
                    }
                    constructor() {
                        this.name = Wd.id;
                        this.td = 0
                    }
                };
                var ce = class {
                    setupOnce(a, b) {
                        a(c => {
                            const d = b().getIntegration(ce);
                            return d ? Rd(d, c) : c
                        })
                    }
                    Ac(a) {
                        var b, c, d;
                        const e = (a === null || a === void 0 ? 0 : a.url) ? Qd(this, a === null || a === void 0 ? void 0 : a.url) : void 0,
                            f = {};
                        if (a === null || a === void 0 ? 0 : (b = a.headers) === null || b === void 0 ? 0 : b["User-Agent"]) f["User-Agent"] = a === null || a === void 0 ? void 0 : a.headers["User-Agent"];
                        if (a === null || a === void 0 ? 0 : (c = a.headers) === null || c === void 0 ? 0 : c.Referer) f.Referer = Qd(this, a === null || a === void 0 ? void 0 : (d = a.headers) === null || d === void 0 ? void 0 : d.Referer);
                        return {
                            url: e,
                            headers: f
                        }
                    }
                    constructor(a, b) {
                        this.Pd = a;
                        this.location = b;
                        this.name = ce.id
                    }
                };
                ce.id = "UrlScrubber";
                var Sd = [function(a) {
                    if (a = /canvaeditor\/(\d+\.\d+\.\d+)/.exec(a)) return {
                        name: "mobile_app_version",
                        value: a[1]
                    }
                }, function(a) {
                    if (a = /com.canva.editor\s\(version\/(\d+\.\d+\.\d+)/.exec(a)) return {
                        name: "mobile_app_version",
                        value: a[1]
                    }
                }];
                var ee = ["TimeoutError", "HttpTimeoutError", /^ResizeObserver loop/, /^WHEN_CANCELLED$/, "ChunkLoadError", /^NetworkError: Failed to execute 'importScripts' on 'WorkerGlobalScope':/, /Failed to register a ServiceWorker.*(The document is in an invalid state|An unknown error occurred when fetching the script|Failed to access storage|The URL protocol of the current origin \('null'\) is not supported|Timed out while trying to start the Service Worker)\.$/, /^(Can't find variable: indexedDB|Internal error opening backing store for indexedDB.open.|Encountered full disk while opening backing store for indexedDB.open.|An internal error was encountered in the Indexed Database server)/,
                        /Non-Error promise rejection captured with value: [Tt]imeout( \(.\))?/
                    ],
                    vh = class {
                        Ac(a) {
                            var b, c, d;
                            if (!a.url) return {
                                headers: {
                                    "User-Agent": (d = a === null || a === void 0 ? void 0 : (b = a.headers) === null || b === void 0 ? void 0 : b["User-Agent"]) !== null && d !== void 0 ? d : ""
                                }
                            };
                            b = /^(\/design\/[a-zA-Z0-9_-]+\/)([a-zA-Z0-9_-]{22})(.*)/;
                            d = new URL(a.url);
                            d.search = "";
                            b.test(d.pathname) && (d.pathname = d.pathname.replace(b, "$1<REDACTED>$3"));
                            var e;
                            return {
                                url: d.toString(),
                                headers: {
                                    "User-Agent": (e = a === null || a === void 0 ? void 0 : (c = a.headers) ===
                                        null || c === void 0 ? void 0 : c["User-Agent"]) !== null && e !== void 0 ? e : ""
                                }
                            }
                        }
                        setContext({
                            user: a,
                            locale: b,
                            th: c
                        }) {
                            var d, e;
                            (e = this.R) === null || e === void 0 || (d = e.getCurrentHub()) === null || d === void 0 || d.configureScope(f => {
                                a && (f.setUser(a), f.setExtra("isAnonymousUser", !1));
                                b && f.setTag("locale", b);
                                c === null || c === void 0 || c.forEach((g, h) => f.setExtra(h, g))
                            })
                        }
                        setTags(a) {
                            for (const b of a) this.setTag(b.name, b.value)
                        }
                        setTag(a, b) {
                            if (this.R != null) {
                                {
                                    var c = a.length <= 32;
                                    const d = b.length <= 200;
                                    c && d ? c = ua(!0) : (c = (c ? "" : "Key name length cannot exceed 32 characters.\n") +
                                        (d ? "" : "Key value length cannot exceed 200 characters.\n"), c = va(Error(c + `Tag: ${a}:${b}`)))
                                }
                                c.ok ? this.R.setTag(a, b) : ge(this, c.error)
                            }
                        }
                        setExtras(a) {
                            for (const b of a) this.setExtra(b.name, b.value)
                        }
                        setExtra(a, b) {
                            this.R != null && this.R.setExtra(a, Bd(b))
                        }
                        error(a, b) {
                            ie(this, "error", a instanceof Error ? a : Error(a), b)
                        }
                        F(a, b) {
                            ie(this, "error", a, b)
                        }
                        Gd(a, b) {
                            ie(this, "warning", a, b)
                        }
                        info(a, b) {
                            ie(this, "info", a instanceof Error ? a : Error(a), b)
                        }
                        debug(a, b) {
                            ie(this, "debug", a instanceof Error ? a : Error(a), b)
                        }
                        constructor(a) {
                            var b =
                                self.Sentry,
                                c = new th;
                            a: {
                                var d = self;
                                if (typeof d.Android === "object" && typeof d.Android.getPageLocation === "function") {
                                    let e;
                                    try {
                                        e = d.Android.getPageLocation()
                                    } catch (f) {
                                        d = void 0;
                                        break a
                                    }
                                    d = typeof e === "string" ? e : void 0
                                } else d = void 0
                            }
                            this.S = a;
                            this.Nc = [];
                            this.Le = [];
                            this.R = b;
                            this.ue = c;
                            this.Vd = [];
                            this.$c = this.kd = void 0;
                            this.allowUrls = "/dist/renderer/ canva.com canva.cn canva-dev.com canva-staging.com canva-staging.cn www.features.canva-internal.com www.features.canva-internal-staging.com canva-apps.com canva-apps.cn canva-apps-dev.com canva-apps-staging.com canva-apps-staging.cn".split(" ");
                            this.R ? fe(this, a, {
                                pd: d
                            }) : typeof self.suppressSentryInitializationError !== "undefined" && self.suppressSentryInitializationError === !0 || console.error("Sentry can not be found on the global scope.")
                        }
                    };
                var Te = class {
                        Na() {
                            return new wh
                        }
                    },
                    wh = class {
                        na() {
                            return new xh
                        }
                        oa() {
                            return new xh
                        }
                        Ob(a, b, c) {
                            let d;
                            typeof c === "function" && (d = c);
                            return d(new xh)
                        }
                        async Nb(a, b, c) {
                            let d;
                            typeof c === "function" && (d = c);
                            return d(new xh)
                        }
                        async flush() {}
                    },
                    xh = class {
                        Tb() {
                            return new yh
                        }
                        abort() {}
                        Ea() {}
                        setAttribute() {
                            return this
                        }
                        setStatus() {
                            return this
                        }
                        cd() {
                            return !1
                        }
                        qa() {
                            return !1
                        }
                        end() {
                            return {
                                za: () => ({}),
                                Aa: () => ({})
                            }
                        }
                        Ja() {}
                        Wa() {}
                        constructor() {
                            this.name = "";
                            this.attrs = new Map;
                            this.ja = "NOOP";
                            this.Xa = [];
                            this.status = "unset";
                            this.Z = new Map;
                            this.startTime = performance.now();
                            this.wa = "span";
                            this.context = {
                                traceId: "",
                                spanId: "",
                                Dc: 0
                            };
                            this.links = []
                        }
                    },
                    yh = class {
                        Ja() {}
                        Wa() {}
                        setAttribute() {}
                        Ea() {}
                    };
                var Ue = class {
                    Uc(a) {
                        var b = [];
                        for (const c of a) c.parentSpanId && !this.kc.has(c.parentSpanId) ? (a = this.tb.get(c.parentSpanId) || [], a.push(c), this.tb.set(c.parentSpanId, a)) : b.push(c);
                        for (const c of b) b = c.context.spanId, le(this, c), this.tb.delete(b)
                    }
                    async flush() {}
                    constructor() {
                        this.tb = new Map;
                        this.kc = new Set
                    }
                };
                var zh = class extends Error {
                        constructor(a, b) {
                            super(a);
                            this.oc = b;
                            this.name = "TelemetryExportError";
                            Object.setPrototypeOf(this, zh.prototype)
                        }
                    },
                    Ah = class extends L {
                        constructor(a, b, c) {
                            super(a, b);
                            this.oc = c;
                            this.name = "SampledTracingExportError";
                            Object.setPrototypeOf(this, Ah.prototype)
                        }
                    };
                var Ve = class {
                    async Uc(a) {
                        if (a.length !== 0)
                            if (this.wb.size < this.Yb) {
                                try {
                                    Se(this.Ed);
                                    var b = re(a, c => {
                                        var d = this.Ed;
                                        return d.Gc + (c - d.sc)
                                    })
                                } catch (c) {
                                    this.j.F(c, {
                                        pa: "OTLPSpanAdapter: Unable to convert spans",
                                        extra: new Map([
                                            ["spans", JSON.stringify(a.map(P), void 0, 2)]
                                        ])
                                    });
                                    return
                                }
                                try {
                                    const c = this.send(b);
                                    this.wb.add(c);
                                    c.catch(d => {
                                        this.j.F(d)
                                    }).finally(() => {
                                        this.wb.delete(c)
                                    })
                                } catch (c) {
                                    this.j.F(c)
                                }
                            } else this.j.F(new zh("OTLPExporter: Concurrency Limit Reached"))
                    }
                    async flush() {
                        await Promise.all(this.wb)
                    }
                    constructor(a,
                        b, c, d) {
                        this.config = a;
                        this.j = b;
                        this.Ed = c;
                        this.send = d;
                        this.wb = new Set;
                        var e;
                        this.Yb = (e = a.Yb) !== null && e !== void 0 ? e : Infinity
                    }
                };
                var Xe = ({
                    Yf: a,
                    url: b,
                    cb: c,
                    fetch: d = self.fetch
                }) => async e => {
                    var f, g;
                    e = new Request(b, {
                        method: "POST",
                        body: JSON.stringify(e),
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json"
                        },
                        priority: "low",
                        signal: (f = (g = AbortSignal).timeout) === null || f === void 0 ? void 0 : f.call(g, a)
                    });
                    try {
                        const h = await d(e);
                        if (h.status > 299 || h.status < 200) throw c != null ? new Ah(`SendWithFetch: Failed to export (status: ${h.status})`, c) : new zh(`SendWithFetch: Failed to export (status: ${h.status})`);
                    } catch (h) {
                        throw f = h instanceof
                        Error && h.name === "AbortError" ? `SendWithFetch: Fetch request timeout: ${a}ms` : "SendWithFetch: Failed to export", c != null ? new Ah(f, c) : new zh(f);
                    }
                };
                var Ye = class {
                    build(a) {
                        return this.qd.reduce((b, c) => c(b), {
                            Ra: () => {},
                            process: b => a.Uc(b),
                            flush: () => a.flush()
                        })
                    }
                    constructor() {
                        this.qd = []
                    }
                };
                var te = class {
                    Ra() {}
                    process(a) {
                        for (const b of a) b.qa() && (this.buffer.push(b), this.buffer.length >= this.config.Gb && ue(this));
                        this.buffer.length > 0 && this.Ua == null && (this.Ua = setTimeout(() => ue(this), this.config.Hb))
                    }
                    async flush() {
                        ue(this);
                        await this.Qa.flush()
                    }
                    constructor(a, b, c) {
                        this.Qa = a;
                        this.config = b;
                        this.j = c;
                        this.buffer = []
                    }
                };
                var Ze = class {
                        Ra(a) {
                            const b = a.context.traceId,
                                c = this.Sb.get(b);
                            c != null ? (c.Ib += 1, a.G === void 0 && (c.root = a)) : this.Sb.set(b, {
                                Ib: 1,
                                root: a
                            });
                            this.Qa.Ra(a)
                        }
                        process(a) {
                            for (const c of a) {
                                a = c.context.traceId;
                                var b = this.Sb.get(a);
                                b != null && (--b.Ib, b.Ib === 0 && (b = this.Hf.process(b), this.Qa.process(b), this.Sb.delete(a)))
                            }
                        }
                        flush() {
                            return this.Qa.flush()
                        }
                        constructor(a) {
                            var b = new Bh;
                            this.Qa = a;
                            this.Hf = b;
                            this.Sb = new Map
                        }
                    },
                    Bh = class {
                        process(a) {
                            const b = [];
                            ve(this, a.root, b);
                            return b
                        }
                    };
                var Ch = Be(16),
                    Dh = Be(8),
                    Ae = Array(32);
                var Ge = class {
                    Tb() {
                        return this.ba || new yh
                    }
                    Ea(a) {
                        this.Va || (this.attrs = new Map([...this.attrs, ...a]))
                    }
                    setAttribute(a, b, c = !1) {
                        if (this.Va && !c) return this;
                        this.attrs.set(a, b);
                        return this
                    }
                    setStatus(a) {
                        try {
                            if (this.Va) return this;
                            this.status = a;
                            return this
                        } catch (b) {
                            return this.status = "error", this.j.F(b), this
                        }
                    }
                    cd() {
                        return !this.ended
                    }
                    qa() {
                        return (this.context.Dc & 1) !== 0
                    }
                    abort() {
                        try {
                            var a;
                            if (!this.aborted) {
                                this.aborted = !0;
                                this.setAttribute("span_aborted", !0);
                                for (const b of this.Ka) b.abort();
                                this.ended || (this.Va =
                                    this.ended = !0, this.timeout && clearTimeout(this.timeout), ((a = this.la) === null || a === void 0 ? 0 : a.frameRate) && Ie(this.la.frameRate), this.endTime = this.getCurrentTime(), this.duration = this.endTime - this.startTime, Ee(this), He(this), this.ib.forEach(b => b()), this.ta.Ta.process([this]))
                            }
                        } catch (b) {
                            this.j.F(b)
                        }
                    }
                    end(a, b, c) {
                        try {
                            if (this.ended) return {
                                za: this.za,
                                Aa: this.Aa
                            };
                            this.ended = !0;
                            return Je(this, a, b, c)
                        } catch (d) {
                            return this.j.F(d, {
                                pa: "Error ending span",
                                extra: new Map(P(this))
                            }), {
                                za: this.za,
                                Aa: this.Aa
                            }
                        }
                    }
                    Ja(a) {
                        try {
                            this.ended &&
                                this.aborted || (this.ended && this.ac ? a(this.ac) : this.jb.push(a))
                        } catch (b) {
                            this.j.F(b)
                        }
                    }
                    Wa(a) {
                        try {
                            this.ended && this.aborted ? a() : this.ib.push(a)
                        } catch (b) {
                            this.j.F(b)
                        }
                    }
                    get Z() {
                        return this.fb()
                    }
                    constructor(a) {
                        var b;
                        this.Va = this.aborted = this.ended = !1;
                        this.attrs = new Map;
                        this.Xa = [];
                        this.Ka = [];
                        this.status = "unset";
                        this.ac = void 0;
                        this.jb = [];
                        this.ib = [];
                        this.za = f => ze({
                            span: this,
                            j: this.j,
                            Da: this.Da,
                            ...f
                        });
                        this.Aa = () => this.qa() ? this.context : void 0;
                        this.name = a.name;
                        this.ended = !1;
                        this.ta = a.ta;
                        var c;
                        this.getCurrentTime =
                            (c = a.getCurrentTime) !== null && c !== void 0 ? c : f => {
                                var g;
                                return (g = f === null || f === void 0 ? void 0 : f.rc) !== null && g !== void 0 ? g : performance.now()
                            };
                        c = Dh();
                        this.identifier = `${this.name}_${c}`;
                        this.startTime = this.getCurrentTime({
                            id: this.identifier,
                            rc: a.startTime
                        });
                        this.ja = a.ja;
                        this.ba = a.ba;
                        this.wa = a.wa;
                        this.j = a.j;
                        this.la = a.la;
                        const d = ((b = a.G) === null || b === void 0 ? void 0 : b.context.traceId) || Ch();
                        a.attrs && (this.attrs = new Map(a.attrs));
                        this.attrs.set("span_type", this.wa);
                        b = a.ta.zc.xd({
                            traceId: d,
                            Tf: this.name,
                            attributes: this.attrs,
                            G: a.G
                        }) ? 1 : 0;
                        this.context = {
                            spanId: c,
                            traceId: d,
                            Dc: b
                        };
                        this.links = a.links || [];
                        a.G && (this.parentSpanId = a.G.context.spanId, this.G = a.G);
                        this.fb = a.fb;
                        this.Da = a.Da;
                        this.setStatus("ok");
                        this.timeout = setTimeout(() => {
                            this.name += ".timed_out";
                            this.setAttribute("timed_out", !0);
                            this.end("ok")
                        }, a.timeout || 12E4);
                        for (const f of this.ta.plugins) try {
                            var e;
                            (e = f.Ra) === null || e === void 0 || e.call(f, this)
                        } catch (g) {
                            this.j.F(g, {
                                pa: "Error calling plugin onSpanStart",
                                extra: new Map([
                                    ["plugin", f.name], ...P(this)
                                ])
                            })
                        }
                        this.ta.Ta.Ra(this)
                    }
                };
                var Ke = class {
                    get aborted() {
                        return this.X.aborted
                    }
                    Ja(a) {
                        try {
                            this.ended && this.aborted || (this.ended && this.bc ? a(this.bc) : this.jb.push(a))
                        } catch (b) {
                            this.j.F(b, {
                                tags: new Map([
                                    ["user_operation", this.name]
                                ])
                            })
                        }
                    }
                    Wa(a) {
                        try {
                            this.ended && this.aborted ? a() : this.ib.push(a)
                        } catch (b) {
                            this.j.F(b, {
                                tags: new Map([
                                    ["user_operation", this.name]
                                ])
                            })
                        }
                    }
                    Ea(a) {
                        this.X.Ea(a)
                    }
                    setAttribute(a, b) {
                        this.X.setAttribute(a, b)
                    }
                    constructor(a, b, c, d, e) {
                        var f = new Set;
                        this.name = a;
                        this.X = b;
                        this.j = c;
                        this.Pb = d;
                        this.ab = e;
                        this.$b = f;
                        this.jb = [];
                        this.ib = [];
                        this.bc = void 0;
                        this.ended = !1
                    }
                };
                var bf = class {
                    xd({
                        Tf: a,
                        attributes: b,
                        G: c
                    }) {
                        b = b === null || b === void 0 ? void 0 : b.get("sample_rate_override");
                        if (b != null && typeof b === "number") {
                            if (b < 0 || b > 1) this.j.error(Error(`Invalid sample rate (${b}) for ${a}`)), b = this.sampleRate;
                            return Math.random() < b
                        }
                        a = this.jf(c);
                        return a != null ? a : Math.random() < this.sampleRate
                    }
                    constructor(a = 0, b) {
                        var c = Pe;
                        this.sampleRate = a;
                        this.j = b;
                        this.jf = c;
                        this.sampleRate = Math.min(Math.max(0, this.sampleRate), 1)
                    }
                };
                var Eh = class {
                    add(a, b = 1) {
                        p(isFinite(a));
                        p(b > 0);
                        if (this.da === 0) this.da = b, this.qb = this.rb = this.Ia = a, this.sb = 0;
                        else {
                            this.da += b;
                            const c = a - this.Ia;
                            this.Ia += b * c / this.da;
                            this.sb += b * c * (a - this.Ia);
                            this.rb = Math.min(this.rb, a);
                            this.qb = Math.max(this.qb, a)
                        }
                    }
                    addAll(a) {
                        for (const b of a) this.add(b)
                    }
                    get count() {
                        return this.da
                    }
                    get lf() {
                        return this.Ia
                    }
                    get min() {
                        return this.rb
                    }
                    get max() {
                        return this.qb
                    }
                    get Ff() {
                        return this.da === 0 ? NaN : this.da === 1 ? 0 : Math.max(this.sb, 0) / this.da
                    }
                    get Ef() {
                        return Math.sqrt(this.Ff)
                    }
                    constructor() {
                        this.da =
                            0;
                        this.Ia = NaN;
                        this.sb = 0;
                        this.qb = this.rb = NaN
                    }
                };
                var Fh = class {
                        start() {
                            this.Fa = new Eh;
                            this.Kb = void 0;
                            this.Vb = this.uc.requestAnimationFrame(this.sd);
                            this.document.addEventListener("visibilitychange", this.ld)
                        }
                        get bd() {
                            return this.document.visibilityState === "visible"
                        }
                        constructor() {
                            var a = window.document;
                            this.uc = window;
                            this.document = a;
                            this.Fa = new Eh;
                            this.sd = b => {
                                this.Kb !== void 0 && this.Fa.add(Math.min(b - this.Kb, 5E3));
                                this.Kb = this.bd ? b : void 0;
                                this.Vb = this.uc.requestAnimationFrame(this.sd)
                            };
                            this.ld = () => {
                                this.bd || (this.Kb = void 0)
                            }
                        }
                    },
                    Gh = class {
                        reset() {
                            this.frameCount =
                                0;
                            this.gd = new Eh;
                            this.ad.clear()
                        }
                        constructor() {
                            this.frameCount = 0;
                            this.gd = new Eh;
                            this.ad = new Set
                        }
                    },
                    Qe = new Gh;
                var Hh = class {
                    Ra() {}
                    process() {}
                    async flush() {}
                };
                var Ih = class {
                    xd() {
                        return !0
                    }
                };
                var Jh = class {
                    na(a, b) {
                        return this.oa(a, void 0, b)
                    }
                    oa(a, b, c) {
                        try {
                            var d;
                            const {
                                hd: e,
                                jd: f
                            } = Ce(c), g = ia(this.ja(b), "No instrumentation scope found for '{}' of parent '{}:{}'", a, b === null || b === void 0 ? void 0 : b.ja, b === null || b === void 0 ? void 0 : b.context.spanId), h = (f === null || f === void 0 ? 0 : (d = f.performance) === null || d === void 0 ? 0 : d.Qh) ? this.Zb.frameRate() : void 0;
                            h === null || h === void 0 || h.start();
                            const k = (f === null || f === void 0 ? 0 : f.Uf) ? Me({
                                    oc: { ...f.Uf,
                                        startTime: f.startTime,
                                        timeout: f.timeout
                                    },
                                    l: this.Jc,
                                    G: b,
                                    se: [this.config.Ub,
                                        this.Ub
                                    ].filter(Qa),
                                    j: this.j,
                                    vf: n => {
                                        b = n
                                    }
                                }) : Ne(b),
                                l = new Ge({
                                    name: a,
                                    G: b,
                                    ta: this.config,
                                    fb: this.fb,
                                    ja: g,
                                    j: this.j,
                                    getCurrentTime: this.getCurrentTime,
                                    startTime: f === null || f === void 0 ? void 0 : f.startTime,
                                    timeout: f === null || f === void 0 ? void 0 : f.timeout,
                                    Da: this.Da,
                                    attrs: (f === null || f === void 0 ? void 0 : f.attrs) || e,
                                    links: f === null || f === void 0 ? void 0 : f.links,
                                    ba: k,
                                    wa: "span",
                                    la: {
                                        frameRate: h
                                    }
                                });
                            k !== null && k !== void 0 && (l.attrs.get("is_uop") || l.setAttribute("user_operation", k.name), k.Pb == null && (k.Pb = l.qa(), k.Pb && k.X.setAttribute("uop_persist", !0)), k.$b.add(l));
                            b != null && b instanceof Ge && b.Ka.push(l);
                            return l
                        } catch (e) {
                            return this.j.F(e), new xh
                        }
                    }
                    Ob(a, b, c) {
                        {
                            let e, f;
                            typeof c === "function" ? f = c : e = De(c);
                            a = this.oa(a, b, e);
                            try {
                                var d = f(a)
                            } catch (g) {
                                throw a.setStatus("error"), g;
                            } finally {
                                a.end()
                            }
                        }
                        return d
                    }
                    async Nb(a, b, c) {
                        return Re(this, a, b, c)
                    }
                    async flush() {
                        try {
                            await this.config.Ta.flush()
                        } catch (a) {
                            this.j.F(a)
                        }
                    }
                    constructor(a, b, c, d, e, f, g, h = l => {
                        var n;
                        return (n = l === null || l === void 0 ? void 0 : l.rc) !== null && n !== void 0 ? n : performance.now()
                    }, k = {
                        frameRate: () => new Fh
                    }) {
                        this.ja =
                            a;
                        this.Da = b;
                        this.config = c;
                        this.fb = d;
                        this.j = e;
                        this.Jc = f;
                        this.Ub = g;
                        this.getCurrentTime = h;
                        this.Zb = k
                    }
                };
                var af = class {
                        constructor(a) {
                            var b;
                            this.zc = (b = a.zc) !== null && b !== void 0 ? b : new Ih;
                            var c;
                            this.Ta = (c = a.Ta) !== null && c !== void 0 ? c : new Hh;
                            var d;
                            this.plugins = (d = a.plugins) !== null && d !== void 0 ? d : [];
                            var e;
                            this.Z = (e = a.Z) !== null && e !== void 0 ? e : new Map;
                            this.Ub = a.Ub
                        }
                    },
                    $e = class {
                        Na(a) {
                            try {
                                return new Jh(() => a, this, this.config, () => new Map([...this.config.Z, ["service.name", this.Pf + " | " + a]]), this.j, this.Jc, void 0, this.getCurrentTime, this.Zb)
                            } catch (c) {
                                var b;
                                this.j.F(c, {
                                    extra: new Map([
                                        ["attrs", Object.fromEntries((b = this.config) ===
                                            null || b === void 0 ? void 0 : b.Z)]
                                    ])
                                });
                                return new wh
                            }
                        }
                        constructor(a, b, c = e => {
                            var f;
                            return (f = e === null || e === void 0 ? void 0 : e.rc) !== null && f !== void 0 ? f : performance.now()
                        }, d = {
                            frameRate: () => new Fh
                        }) {
                            this.config = a;
                            this.j = b;
                            this.getCurrentTime = c;
                            this.Zb = d;
                            this.Pf = (a = this.config.Z.get("service.name")) && typeof a === "string" ? a : "no_service_name";
                            this.Jc = this.Na("telemetry.user_operation")
                        }
                    };
                var We = class {
                    constructor() {
                        var a = Date.now(),
                            b = performance.now();
                        this.Gc = a;
                        this.sc = b;
                        this.threshold = 1E4
                    }
                };
                var ef = class {
                    constructor(a, b) {
                        this.Cd = a;
                        this.Bd = b
                    }
                };
                var gf = class {
                    wc(a) {
                        const b = this.l.na("time_until_idle");
                        b.Ja(() => this.La.delete(a));
                        b.Wa(() => this.La.delete(a));
                        this.La.set(a, {
                            span: b,
                            Ua: self.setTimeout(() => df(this, a), 5E3),
                            Ab: [performance.now()]
                        })
                    }
                    xc(a) {
                        a = this.La.get(a);
                        a != null && (a.Ab = a.Ab.slice(-5).concat(performance.now()))
                    }
                    constructor(a) {
                        this.l = a;
                        this.La = new Map
                    }
                };
                var ff = class {
                    wc(a) {
                        const b = this.l.na("time_to_second_fetch_event", {
                            timeout: this.options.Zf
                        });
                        b.Ja(() => this.nb.delete(a));
                        b.Wa(() => this.nb.delete(a));
                        this.nb.set(a, b)
                    }
                    xc(a) {
                        const b = this.nb.get(a);
                        b != null && (b.end(), this.nb.delete(a))
                    }
                    constructor(a) {
                        this.options = {
                            Zf: 3E4
                        };
                        this.l = a;
                        this.nb = new Map
                    }
                };
                var kf = class {
                    constructor() {
                        this.Sc = !1;
                        this.Wb = null
                    }
                };
                (function() {
                    var a;
                    const b = performance.now(),
                        c = ma("page", qh.P);
                    var d;
                    const e = (d = c.release) !== null && d !== void 0 ? d : self.bootstrap.release;
                    var f;
                    d = (f = c.j) !== null && f !== void 0 ? f : ma("errorService", Lf.P);
                    var g;
                    f = (g = c.Ad) !== null && g !== void 0 ? g : ma("telemetryService", Pf.P);
                    a: switch (d.M) {
                        case "CONSOLE":
                            g = new sh;
                            break a;
                        case "SENTRY":
                            g = new vh(d);
                            break a;
                        default:
                            throw new E(d);
                    }
                    const h = g,
                        {
                            Ga: k,
                            ob: l,
                            ra: n
                        } = lf({
                            location: self.location,
                            S: f,
                            cb: c.Wf,
                            cc: c.Xf,
                            userAgent: c.userAgent,
                            C: {
                                j: h
                            }
                        });
                    g = k.Na("service_worker.install");
                    var m;
                    const t = g.na(`boot.${(m=(a=self.serviceWorker)===null||a===void 0?void 0:a.state)!==null&&m!==void 0?m:"na"}`, {
                        startTime: 0
                    });
                    a = g.oa("main", t, {
                        startTime: b
                    });
                    const q = new kh({
                        nd: c.Ve,
                        Qc: c.Ue,
                        Jb: c.We,
                        hg: c.Ye,
                        he: c.Te || 1
                    });
                    if (c.Tc) try {
                        md({
                            serviceWorker: self,
                            C: {
                                j: h,
                                Ga: k,
                                ob: l,
                                ra: n
                            },
                            O: c.O,
                            B: q,
                            N: c.mode === "REAL" ? c.N : location.origin,
                            hb: c.hb,
                            te: () => JSON.stringify(c, void 0, 2),
                            ma: c.Je,
                            ga: c.ga,
                            ha: c.ha
                        })
                    } catch (x) {
                        h.F(x)
                    }
                    vd({
                        serviceWorker: self,
                        B: q,
                        release: e,
                        C: {
                            Ga: k
                        }
                    });
                    self.addEventListener("activate", x => {
                        x.waitUntil(async function() {
                            var w,
                                A;
                            c.Ce && await self.clients.claim().catch(B => h.F(B));
                            c.Tc && q.options.Jb !== 1 ? await ((w = self.registration.navigationPreload) === null || w === void 0 ? void 0 : w.enable().catch(() => {})) : await ((A = self.registration.navigationPreload) === null || A === void 0 ? void 0 : A.disable().catch(() => {}))
                        }())
                    });
                    self.addEventListener("install", () => {
                        c.Ee && self.skipWaiting()
                    });
                    a.end();
                    Promise.resolve().then(() => {
                        t.end();
                        l.Wb = Date.now()
                    })
                })();
            }).call(self, self._5c0f058b2d917619b177d32cbc4c572b);
        },

        /***/
        692950:
            (_, __, r) => r(476834)

    },
    /******/
    __webpack_require__ => { // webpackRuntimeModules
        /******/
        var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
        /******/
        __webpack_require__.O(0, [95433], () => (__webpack_exec__(476834), __webpack_exec__(692950)));
        /******/
        var __webpack_exports__ = __webpack_require__.O();
        /******/
    }
])
//# sourceMappingURL=sourcemaps/hjfept.6cb8b3457fba3374.js.map