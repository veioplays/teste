(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [32915], {

        /***/
        88780: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(878415);
            __web_req__(914242);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var Kf = __c.Kf;
                var E = __c.E;
                var w = __c.w;
                var VBb = function(a) {
                        return () => a
                    },
                    i7 = function(a, b, c, d) {
                        return new WBb(a, b, c, d)
                    },
                    j7 = function(a, b) {
                        return b(a)
                    },
                    XBb = function(a, b, c) {
                        return c(a, b)
                    },
                    YBb = function(a, b) {
                        return b(a)
                    },
                    k7 = function(a, b) {
                        return a === b || b.map(c => a.maa(ZBb(c)))
                    },
                    aCb = function(a, b) {
                        return a.Hba(b).map(c => new $Bb(c, d => d.props[b]))
                    },
                    ZBb = function(a) {
                        w(a instanceof l7);
                        return a
                    },
                    n7 = function(a, b) {
                        if (a === b) return !0;
                        switch (typeof a) {
                            case "string":
                            case "number":
                            case "boolean":
                            case "undefined":
                                return !1;
                            case "object":
                                if (typeof b !== "object" ||
                                    a.kind !== b.kind) return !1;
                                switch (a.kind) {
                                    case "array":
                                        return b.kind === "array" && m7(a.items, b.items);
                                    case "set":
                                        var c;
                                        if (c = b.kind === "set") a = a.items, b = b.items, c = a === b ? !0 : a.size !== b.size ? !1 : m7([...a], [...b]);
                                        return c;
                                    case "map":
                                        if (c = b.kind === "map") a = a.items, b = b.items, c = a === b ? !0 : a.size !== b.size ? !1 : m7([...a.keys(), ...a.values()], [...b.keys(), ...b.values()]);
                                        return c;
                                    case "record":
                                        return b.kind === "record" && bCb(a.fields, b.fields);
                                    case "instance":
                                        return b.kind === "instance" && a.instance === b.instance;
                                    default:
                                        throw new E(a);
                                }
                            default:
                                throw new E(a);
                        }
                    },
                    m7 = function(a, b) {
                        if (a === b) return !0;
                        if (a.length !== b.length) return !1;
                        for (let c = 0; c < a.length; c++)
                            if (!n7(a[c], b[c])) return !1;
                        return !0
                    },
                    bCb = function(a, b) {
                        if (a === b) return !0;
                        const c = Object.keys(a),
                            d = Object.keys(b),
                            e = new Set([...c, ...d]);
                        if (c.length !== e.size || d.length !== e.size) return !1;
                        for (const f of e)
                            if (!n7(a[f], b[f])) return !1;
                        return !0
                    },
                    o7 = function(a) {
                        return typeof a === "string" ? JSON.stringify(a) : String(a)
                    },
                    p7 = function(a, b, c) {
                        switch (c.kind) {
                            case 0:
                                return cCb(c.value);
                            case 1:
                                const f =
                                    p7(a, b, c.yr);
                                return dCb[c.name].map(r => q7(r, f));
                            case 2:
                                const g = p7(a, b, c.bGa),
                                    h = p7(a, b, c.cGa);
                                return eCb[c.name].map(r => fCb(r, g, h));
                            case 3:
                                const k = c.args.map(r => r.kind !== 13 ? new gCb(p7(a, b, r)) : new hCb(p7(a, b, r.W6a))),
                                    l = c.name;
                                switch (l) {
                                    case 0:
                                    case 1:
                                        var d = k.map(r => r.D9(t => t.type, t => t.type.bH()));
                                        return j7(d, r => r7.union(...r).map(t => iCb[l](t).map(v => jCb(v, k))));
                                    default:
                                        return kCb[l].map(r => jCb(r, k))
                                }
                            case 4:
                                return lCb(p7(a, b, c.fX), (r, t) => mCb(a, b, c.param, t, c.body).map(v => nCb[c.name](t, v.resultType).map(u =>
                                    oCb(u, r, v))));
                            case 5:
                                const m = c.entries.map(([r, t]) => [p7(a, b, r), p7(a, b, t)]);
                                d = r7.union(...m.map(([r]) => r.type));
                                var e = r7.union(...m.map(([, r]) => r.type));
                                return XBb(d, e, (r, t) => pCb[0](r, t).map(v => qCb(v, m)));
                            case 6:
                                const n = Kf(c.fields, r => p7(a, b, r));
                                d = Kf(n, r => r.type);
                                return YBb(d, r => rCb[0](r).map(t => sCb(t, n)));
                            case 7:
                                d = a.types.resolve(c.name);
                                if (!d) throw Error(`cannot instantiate unknown type: ${c.name}`);
                                const p = p7(a, b, {
                                    kind: 6,
                                    fields: c.args
                                });
                                return d.FRa.map(r => q7(r, p, {
                                    Pn: !0
                                }));
                            case 8:
                                return d = p7(a,
                                    b, c.base), tCb(d, c.U9a);
                            case 9:
                                return uCb(b, c.name);
                            case 10:
                                return d = __c.Hd(c.defs, r => p7(a, b, r)), vCb(a, b, d, c.body);
                            case 11:
                                d = p7(a, b, c.test).as(r7.Hg);
                                e = p7(a, b, c.L1a);
                                const q = p7(a, b, c.alternate);
                                return wCb(d, e, q);
                            case 12:
                                return p7(a, b, c.body).computed();
                            default:
                                throw new E(c);
                        }
                    },
                    mCb = function(a, b, c, d, e) {
                        return p7(a, b.define(c, d), e).map(f => xCb.of(d, f.type, g => h => f.eval(g.define(c, h))))
                    },
                    cCb = function(a) {
                        switch (typeof a) {
                            case "string":
                                return s7(r7.string, a);
                            case "number":
                                return s7(r7.number, a);
                            case "boolean":
                                return s7(r7.Hg,
                                    a);
                            case "undefined":
                                return s7(r7.undefined, a);
                            default:
                                throw new E(a);
                        }
                    },
                    tCb = function(a, b) {
                        return a.map(c => aCb(c.type, b).map(({
                            type: d,
                            get: e
                        }) => q7(new t7(c.type, d, e), c)))
                    },
                    uCb = function(a, b) {
                        return a.resolve(b).map(c => u7.of(c, d => d.resolve(b)))
                    },
                    vCb = function(a, b, c, d) {
                        const e = __c.Hd(c, f => f.type);
                        return yCb(p7(a, new v7(new Map(e), b), d), f => {
                            const g = __c.Hd(c, h => h.eval(f));
                            return new v7(new Map(g), f)
                        })
                    },
                    wCb = function(a, b, c) {
                        return b.map(d => c.map(e => {
                            const f = r7.union(d.type, e.type);
                            return u7.of(f, g => {
                                const h =
                                    a.eval(g),
                                    k = d.eval(g),
                                    l = e.eval(g);
                                return () => h() ? k() : l()
                            })
                        }))
                    },
                    q7 = function({
                        p6: a,
                        resultType: b,
                        apply: c
                    }, d, e) {
                        const f = d.as(a);
                        return new u7(b, g => {
                            const h = f.eval(g);
                            if (e === null || e === void 0 ? 0 : e.Pn) {
                                const k = zCb(c);
                                return () => k(h())
                            }
                            return () => c(h())
                        })
                    },
                    fCb = function({
                        p6: a,
                        dGa: b,
                        resultType: c,
                        apply: d
                    }, e, f) {
                        const g = e.as(a),
                            h = f.as(b);
                        return new u7(c, k => {
                            const l = g.eval(k),
                                m = h.eval(k);
                            return () => d(l(), m())
                        })
                    },
                    jCb = function({
                        fGa: a,
                        resultType: b,
                        apply: c
                    }, d) {
                        let e;
                        const f = d.map(g => g.E6(h => h.as(a), h => h.as(e !== null && e !==
                            void 0 ? e : e = r7.fX(a))));
                        return new u7(b, g => {
                            const h = l => l.eval(g),
                                k = f.map(l => l.E6(h, h));
                            return () => {
                                const l = [];
                                k.forEach(m => {
                                    m.D9(n => l.push(n()), n => l.push(...n()))
                                });
                                return c(l)
                            }
                        })
                    },
                    oCb = function({
                        xGa: a,
                        resultType: b,
                        reduce: c
                    }, d, e) {
                        const f = ACb(e, a);
                        return u7.of(b, g => {
                            const h = d.eval(g),
                                k = f.eval(g),
                                l = zCb(m => {
                                    m = m.map(VBb);
                                    return [m, m.map(k)]
                                });
                            return () => {
                                const [m, n] = l(h());
                                return c(m, n)
                            }
                        })
                    },
                    qCb = function({
                        keyType: a,
                        valueType: b,
                        resultType: c,
                        apply: d
                    }, e) {
                        const f = e.map(([g, h]) => [g.as(a), h.as(b)]);
                        return new u7(c,
                            g => {
                                const h = f.map(([k, l]) => [k.eval(g), l.eval(g)]);
                                return () => d(h.map(([k, l]) => [k(), l()]))
                            })
                    },
                    sCb = function({
                        eGa: a,
                        resultType: b,
                        apply: c
                    }, d) {
                        const e = Object.keys(a).filter(g => !d.hasOwnProperty(g));
                        if (e.length) throw Error(`too few arguments (missing ${e})`);
                        const f = BCb(a, (g, h) => d[h].as(g));
                        return new u7(b, g => {
                            const h = CCb(f, k => k.eval(g));
                            return () => c(DCb(h, k => k()))
                        })
                    },
                    s7 = function(a, b) {
                        const c = VBb(b);
                        return new u7(a, () => c)
                    },
                    lCb = function(a, b) {
                        return a.type.bH().map(c => b(a.as(r7.fX(c)), c))
                    },
                    yCb = function(a, b) {
                        return new u7(a.type,
                            c => a.eval(b(c)))
                    },
                    ACb = function(a, b) {
                        if (!k7(a.resultType, b)) throw Error(`type ${a.resultType} is not assignable to expected type: ${b}`);
                        return a
                    },
                    zCb = function(a) {
                        let b;
                        return c => {
                            if (b && w7.pi(b.u, c)) return b.v;
                            const d = a(c);
                            b = {
                                u: c,
                                v: d
                            };
                            return d
                        }
                    },
                    BCb = function(a, b) {
                        return Kf(a, b)
                    },
                    CCb = function(a, b) {
                        return Kf(a, b)
                    },
                    DCb = function(a, b) {
                        return Kf(a, b)
                    },
                    ICb = function(a) {
                        const b = a.types,
                            c = a.values;
                        class d {
                            optional() {
                                const G = this.A3,
                                    I = this.q1,
                                    J = this.Mia,
                                    L = b.union(this.type, b.undefined);
                                return new d(L, R => R != null ?
                                    G(R) : void 0, (R, S, V) => V != null ? I(R, S, V) : void 0, (R, S, V, ea) => V != null ? J(R, S, V, ea) : ea.delete(S))
                            }
                            qx() {
                                return new d(this.type, this.A3, this.q1, (G, I) => {
                                    throw G.error(I, "read-only field");
                                })
                            }
                            aV(G) {
                                return G ? new d(this.type, this.A3, (I, J, L) => {
                                    L = this.q1(I, J, L);
                                    L != null && G(I, J, L);
                                    return L
                                }, (I, J, L, R) => {
                                    L != null && G(I, J, L);
                                    this.Mia(I, J, L, R)
                                }) : this
                            }
                            VWa(G, I) {
                                const J = this.A3,
                                    L = this.q1,
                                    R = this.Mia;
                                return ECb(this.type, S => {
                                    const V = () => L(G, I, S.Kf.get(I));
                                    return {
                                        cNa: () => J(V()),
                                        Mqa: V,
                                        nVa: ea => R(G, I, ea, S.Kf)
                                    }
                                })
                            }
                            constructor(G, I,
                                J, L) {
                                this.type = G;
                                this.A3 = I;
                                this.q1 = J;
                                this.Mia = L
                            }
                        }
                        a = new d(b.string, G => G, x7("string", G => G.value), y7("string"));
                        const e = new d(b.Hg, G => G, x7("boolean", G => G.value), y7("boolean")),
                            f = (new d(b.number, G => G, x7("int32", G => G.value), y7("int32"))).aV(G => Number.isInteger(G)),
                            g = (new d(b.number, G => G, x7("double", G => G.value), y7("double"))).aV(G => Number.isFinite(G)),
                            h = new d(b.instance("Fill"), G => c.instance("Fill", G), x7("fill", G => G.value), y7("fill")),
                            k = a.optional(),
                            l = e.optional(),
                            m = f.optional(),
                            n = g.optional(),
                            p = h.optional(),
                            q = a.qx(),
                            r = e.qx(),
                            t = f.qx(),
                            v = g.qx(),
                            u = h.qx(),
                            x = k.qx(),
                            y = l.qx(),
                            z = m.qx(),
                            C = n.qx(),
                            D = p.qx(),
                            F = {
                                [0]: {
                                    [0]: {
                                        string: a,
                                        boolean: e,
                                        int32: f,
                                        double: g,
                                        fill: h
                                    },
                                    [1]: {
                                        string: q,
                                        boolean: r,
                                        int32: t,
                                        double: v,
                                        fill: u
                                    }
                                },
                                [1]: {
                                    [0]: {
                                        string: k,
                                        boolean: l,
                                        int32: m,
                                        double: n,
                                        fill: p
                                    },
                                    [1]: {
                                        string: x,
                                        boolean: y,
                                        int32: z,
                                        double: C,
                                        fill: D
                                    }
                                }
                            };
                        return (G, I) => {
                            const J = new FCb(G),
                                L = Kf(I, S => S.key),
                                R = Kf(I, S => {
                                    var V = S.fxa;
                                    const ea = S.ava;
                                    switch (S.type) {
                                        case "string":
                                            V = F[V][ea].string.aV(GCb(S.LD));
                                            break;
                                        case "boolean":
                                            V = F[V][ea]["boolean"];
                                            break;
                                        case "double":
                                            V =
                                                F[V][ea]["double"].aV(HCb(S.range));
                                            break;
                                        case "int32":
                                            V = F[V][ea].int32.aV(HCb(S.range));
                                            break;
                                        case "fill":
                                            V = F[V][ea].fill;
                                            break;
                                        default:
                                            throw new E(S);
                                    }
                                    return V.VWa(J, S.key)
                                });
                            return {
                                OHa: new Map(Object.entries(R).map(([S, V]) => [L[S], V.type])),
                                eval: S => {
                                    const V = Kf(R, pa => pa.eval(S)),
                                        ea = Kf(V, pa => ({
                                            get: pa.Mqa
                                        })),
                                        ta = Kf(V, pa => ({
                                            get: pa.Mqa,
                                            set: pa.nVa
                                        }));
                                    return {
                                        zUa: new Map(Object.entries(V).map(([pa, za]) => [L[pa], za.cNa])),
                                        data: Object.create(null, ea),
                                        r8a: Object.create(null, ta)
                                    }
                                }
                            }
                        }
                    },
                    x7 = function(a, b) {
                        return (c,
                            d, e) => {
                            if (e == null) throw c.error(d, "not found");
                            if (e.type !== a) throw c.error(d, `type error: expected ${a}, was ${e.type}`);
                            return b(e)
                        }
                    },
                    y7 = function(a) {
                        return (b, c, d, e) => {
                            if (d == null) throw b.error(a, "value is nullish");
                            if (a === "string" && typeof d === "string" || a === "boolean" && typeof d === "boolean" || a === "double" && typeof d === "number" || a === "int32" && typeof d === "number") b = {
                                type: a,
                                value: d
                            };
                            else {
                                if (a === "fill" && typeof d === "object") throw b.error(a, "Write for fill is not yet supported");
                                throw b.error(a, `type error: expected ${a}, but received ${typeof d}`);
                            }
                            e.set(c, b)
                        }
                    },
                    HCb = function(a) {
                        if (a) {
                            var b = a.min,
                                c = a.max;
                            w(b == null || c == null || b <= c);
                            return (d, e, f) => {
                                if (b != null && f < b) throw d.error(e, `value below min ${b}: ${f}`);
                                if (c != null && f > c) throw d.error(e, `value above max ${b}: ${f}`);
                            }
                        }
                    },
                    GCb = function(a) {
                        if (a) return (b, c, d) => {
                            if (!a.test(d)) throw b.error(c, `value does not match regex ${a}: '${d}'`);
                        }
                    },
                    ECb = function(a, b) {
                        return {
                            type: a,
                            eval: b
                        }
                    },
                    KCb = function() {
                        return (new JCb({})).add((a, b) => ({
                            Fill: new a("Fill", {
                                color: b.string
                            }, c => __c.OQ.create({ ...__c.QQ,
                                color: c.color
                            }))
                        })).add((a,
                            b) => ({
                            RectElement: new a("RectElement", {
                                top: b.number,
                                left: b.number,
                                width: b.number,
                                height: b.number,
                                rotation: b.union(b.number, b.undefined),
                                fill: b.instance("Fill"),
                                P: b.union(b.array(b.number), b.undefined)
                            }, c => {
                                var d, e, f;
                                const g = __c.wL.create({ ...__c.rS,
                                    top: c.top,
                                    left: c.left,
                                    width: c.width,
                                    height: c.height,
                                    rotation: (e = c.rotation) !== null && e !== void 0 ? e : __c.rS.rotation,
                                    fill: __c.QQ,
                                    P: (f = (d = c.P) === null || d === void 0 ? void 0 : d.items) !== null && f !== void 0 ? f : __c.rS.P
                                });
                                Object.defineProperties(g, {
                                    fill: {
                                        value: c.fill.instance
                                    }
                                });
                                return g
                            })
                        }))
                    },
                    z7 = function() {
                        throw Error("ref not found");
                    },
                    MCb = function(a, b) {
                        return class extends LCb {
                            componentDidCatch(c) {
                                a.error(c);
                                this.setState({
                                    hasError: !0
                                })
                            }
                            render() {
                                return this.state.hasError ? A7(__c.Dk, {
                                    background: "criticalLow",
                                    width: "full",
                                    height: "full",
                                    padding: "0.25u",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    role: "alert",
                                    children: A7(__c.Ak, {
                                        size: "xsmall",
                                        alignment: "center",
                                        children: __c.O("Q6XSow")
                                    })
                                }) : A7(b, { ...this.props
                                })
                            }
                            constructor(...c) {
                                super(...c);
                                this.state = {
                                    hasError: !1
                                }
                            }
                        }
                    },
                    NCb = function(a, b) {
                        var c = a.vDa.get(b.id);
                        if (c) return c;
                        c = a.PIa(b.id, b.HF);
                        a.vDa.set(b.id, c);
                        return c
                    },
                    OCb = __webpack_require__(519427),
                    B7 = OCb.computed,
                    PCb = OCb.observable;
                var A7 = __webpack_require__(443763).jsx;
                var C7 = __webpack_require__(875604),
                    QCb = C7.memo,
                    LCb = C7.PureComponent,
                    RCb = C7.useState;
                var t7 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.p6 = a;
                            this.resultType = b;
                            this.apply = c
                        }
                    },
                    D7 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c, d) {
                            this.p6 = a;
                            this.dGa = b;
                            this.resultType = c;
                            this.apply = d
                        }
                    },
                    E7 = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.fGa = a;
                            this.resultType = b;
                            this.apply = c
                        }
                    },
                    TCb = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            var d = SCb;
                            this.keyType = a;
                            this.valueType = b;
                            this.resultType = c;
                            this.apply = d
                        }
                    },
                    VCb = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b) {
                            var c = UCb;
                            this.eGa = a;
                            this.resultType =
                                b;
                            this.apply = c
                        }
                    },
                    WBb = class {
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c, d) {
                            this.itemType = a;
                            this.xGa = b;
                            this.resultType = c;
                            this.reduce = d
                        }
                    };
                var $Bb = class {
                    map(a) {
                        return a(this)
                    }
                    constructor(a, b) {
                        this.type = a;
                        this.get = b
                    }
                };
                var WCb = class {},
                    gCb = class extends WCb {
                        E6(a) {
                            return new gCb(a(this.value))
                        }
                        D9(a) {
                            return a(this.value)
                        }
                        constructor(a) {
                            super();
                            this.value = this.value = a
                        }
                    },
                    hCb = class extends WCb {
                        E6(a, b) {
                            return new hCb(b(this.value))
                        }
                        D9(a, b) {
                            return b(this.value)
                        }
                        constructor(a) {
                            super();
                            this.value = this.value = a
                        }
                    };
                var l7 = class {
                        map(a) {
                            return a(this)
                        }
                    },
                    F7 = class extends l7 {
                        maa(a) {
                            return this === a || a.Hea(b => this.wR(b))
                        }
                        bH() {
                            throw Error(`${this} is not iterable`);
                        }
                        Hba(a) {
                            var b;
                            const c = (b = this.propTypes) !== null && b !== void 0 ? b : this.propTypes = this.z_();
                            if (!c) throw Error(`${this} is not navigable"`);
                            if (!c.hasOwnProperty(a)) throw Error(`${this} has no navigable property "${a}"`);
                            return c[a]
                        }
                        z_() {
                            throw Error(`${this} is not navigable`);
                        }
                        K9(a) {
                            a(this)
                        }
                        Hea(a) {
                            return a(this)
                        }
                        constructor() {
                            super();
                            this.kind = "simple";
                            this.propTypes =
                                void 0
                        }
                    },
                    G7 = class extends F7 {
                        wR(a) {
                            return a instanceof G7 && this.name === a.name
                        }
                        toString() {
                            return this.name
                        }
                        constructor(a) {
                            super();
                            this.name = a
                        }
                    },
                    H7 = class extends F7 {
                        wR(a) {
                            return a instanceof H7 && this.Uy === a.Uy
                        }
                        toString() {
                            return this.Uy.name
                        }
                        constructor(a) {
                            super();
                            this.Uy = a
                        }
                    },
                    I7 = class extends F7 {
                        wR(a) {
                            return a instanceof I7 && this.Uy === a.Uy && k7(this.yr, a.yr)
                        }
                        toString() {
                            return `${this.Uy}<${this.yr}>`
                        }
                        constructor(a, b) {
                            super();
                            this.Uy = a;
                            this.yr = b
                        }
                    },
                    XCb = class extends I7 {
                        bH() {
                            return this.yr
                        }
                        z_() {
                            const a = this.yr;
                            return {
                                size: r7.number,
                                empty: r7.Hg,
                                get first() {
                                    return r7.optional(a)
                                }
                            }
                        }
                        constructor(a) {
                            super("array", a)
                        }
                    },
                    YCb = class extends I7 {
                        bH() {
                            return this.yr
                        }
                        z_() {
                            const a = this.yr;
                            return {
                                size: r7.number,
                                empty: r7.Hg,
                                get first() {
                                    return r7.optional(a)
                                }
                            }
                        }
                        constructor(a) {
                            super("set", a)
                        }
                    },
                    ZCb = class extends F7 {
                        wR(a) {
                            return a instanceof ZCb && k7(this.key, a.key) && k7(this.value, a.value)
                        }
                        toString() {
                            return `map<${this.key}, ${this.value}>`
                        }
                        constructor(a, b) {
                            super();
                            this.key = a;
                            this.value = b
                        }
                    },
                    $Cb = class extends F7 {
                        wR(a) {
                            return a instanceof
                            $Cb ? Object.entries(a.fields).every(([b, c]) => this.fields.hasOwnProperty(b) && k7(this.fields[b], c)) : !1
                        }
                        z_() {
                            return this.fields
                        }
                        toString() {
                            const a = Object.entries(this.fields);
                            return a.length ? `{ ${a.map(([b,c])=>`${b}: ${c}`).join(", ")} }` : "{}"
                        }
                        constructor(a) {
                            super();
                            this.fields = a
                        }
                    },
                    J7 = class extends l7 {
                        maa(a) {
                            return this === a || this.Pk.every(b => b.maa(a))
                        }
                        bH() {
                            const a = this.Pk.map(b => b.bH());
                            return j7(a, b => r7.union(...b))
                        }
                        Hba(a) {
                            const b = this.Pk.map(c => c.Hba(a));
                            return j7(b, c => r7.union(...c))
                        }
                        K9(a) {
                            this.Pk.forEach(b =>
                                b.K9(a))
                        }
                        Hea(a) {
                            return this.Pk.some(b => b.Hea(a))
                        }
                        toString() {
                            return this.Pk.length ? this.Pk.map(a => a.toString()).join(" | ") : "never"
                        }
                        constructor(a) {
                            super();
                            this.Pk = a;
                            this.kind = "disjunction";
                            w(a.length !== 1)
                        }
                    },
                    K7 = new J7([]),
                    aDb = new G7("string"),
                    bDb = new G7("number"),
                    cDb = new G7("boolean"),
                    dDb = new G7("undefined"),
                    eDb = class {
                        get never() {
                            return K7
                        }
                        get string() {
                            return aDb
                        }
                        get number() {
                            return bDb
                        }
                        get Hg() {
                            return cDb
                        }
                        get undefined() {
                            return dDb
                        }
                        optional(a) {
                            return r7.union(a, r7.undefined)
                        }
                        array(a) {
                            return new XCb(a)
                        }
                        set(a) {
                            return new YCb(a)
                        }
                        fX(a) {
                            return new J7([new XCb(a),
                                new YCb(a)
                            ])
                        }
                        map(a, b) {
                            return new ZCb(a, b)
                        }
                        yc(a) {
                            return new $Cb({ ...a
                            })
                        }
                        union(...a) {
                            if (a.length === 0) return K7;
                            if (a.length === 1) return a[0];
                            const b = new Set;
                            for (const d of a) ZBb(d).K9(e => b.add(e));
                            a = [...b];
                            if (a.length === 0) return K7;
                            if (a.length === 1) return a[0];
                            if (a.length === 2) {
                                const [d, e] = a;
                                return k7(d, e) ? e : k7(e, d) ? d : new J7(a)
                            }
                            const c = new Set;
                            for (const d of a)[...c].some(e => k7(d, e)) || (c.forEach(e => k7(e, d) && c.delete(e)), c.add(d));
                            return c.size === 1 ? [...c][0] : new J7([...c])
                        }
                    },
                    fDb = class extends eDb {
                        instance(a) {
                            return new H7(a)
                        }
                    },
                    r7 = new fDb,
                    gDb = class extends eDb {
                        instance(a) {
                            return new H7(__c.B(this.classes[a]))
                        }
                        constructor(a) {
                            super();
                            this.classes = a
                        }
                    };
                var L7 = Symbol("value"),
                    M7 = class {
                        get props() {
                            var a;
                            return (a = this.rFa) !== null && a !== void 0 ? a : this.rFa = this.s6()
                        }
                    },
                    hDb = class {
                        get size() {
                            return this[L7].length
                        }
                        get empty() {
                            return this[L7].length === 0
                        }
                        get first() {
                            return this[L7][0]
                        }
                        constructor(a) {
                            this[L7] = a
                        }
                    },
                    iDb = class extends M7 {
                        s6() {
                            return new hDb(this.items)
                        }
                        map(a) {
                            return this.items.map(a)
                        }[Symbol.iterator]() {
                            return this.items[Symbol.iterator]()
                        }
                        toString() {
                            return this.items.length ? `[${Array.from(this.items,o7).join(", ")}]` : "[]"
                        }
                        constructor(a) {
                            super();
                            this.kind = "array";
                            this.items = [...a]
                        }
                    },
                    jDb = class {
                        get size() {
                            return this[L7].size
                        }
                        get empty() {
                            return this[L7].size === 0
                        }
                        get first() {
                            return this[L7][Symbol.iterator]().next().value
                        }
                        constructor(a) {
                            this[L7] = a
                        }
                    },
                    kDb = class extends M7 {
                        s6() {
                            return new jDb(this.items)
                        }
                        map(a) {
                            return Array.from(this.items, a)
                        }[Symbol.iterator]() {
                            return this.items[Symbol.iterator]()
                        }
                        toString() {
                            return this.items.size ? `Set [${Array.from(this.items,o7).join(", ")}]` : "Set []"
                        }
                        constructor(a) {
                            super();
                            this.kind = "set";
                            this.items = new Set(a)
                        }
                    },
                    lDb = class {
                        toString() {
                            return this.items.size ? `Map {${Array.from(this.items,([a,b])=>`[${o7(a)}]: ${o7(b)}`).join(", ")}}` : "Map {}"
                        }
                        constructor(a) {
                            this.items = a;
                            this.kind = "map"
                        }
                    },
                    mDb = class extends M7 {
                        s6() {
                            return this.fields
                        }
                        toString() {
                            const a = Object.entries(this.fields);
                            return a.length ? `{ ${[...a].map(([b,c])=>`${b}: ${o7(c)}`).join(", ")} }` : "{}"
                        }
                        constructor(a) {
                            super();
                            this.fields = a;
                            this.kind = "record"
                        }
                    },
                    nDb = class {
                        toString() {
                            return `[instance ${this.Uy.name}]`
                        }
                        constructor(a, b) {
                            this.Uy = a;
                            this.instance =
                                b;
                            this.kind = "instance"
                        }
                    },
                    oDb = class {
                        array(a) {
                            return new iDb(a)
                        }
                        arrayOf(...a) {
                            return new iDb(a)
                        }
                        set(a) {
                            return new kDb(a)
                        }
                        map(a) {
                            return new lDb(new Map(a))
                        }
                        yc(a) {
                            return new mDb({ ...a
                            })
                        }
                    },
                    pDb = class extends oDb {
                        instance(a, b) {
                            return new nDb(a, b)
                        }
                        stringify(a) {
                            return o7(a)
                        }
                        constructor() {
                            super();
                            this.pi = n7
                        }
                    },
                    w7 = new pDb,
                    qDb = class extends oDb {
                        instance(a, b) {
                            a = __c.B(this.classes[a]);
                            return new nDb(a, b)
                        }
                        constructor(a) {
                            super();
                            this.classes = a
                        }
                    };
                var dCb = {
                        [0]: new t7(r7.number, r7.number, a => -a),
                        [1]: new t7(r7.string, r7.number, a => a.length),
                        [2]: new t7(r7.Hg, r7.Hg, a => !a)
                    },
                    eCb = {
                        [0]: new D7(r7.number, r7.number, r7.number, (a, b) => a + b),
                        [1]: new D7(r7.number, r7.number, r7.number, (a, b) => a - b),
                        [2]: new D7(r7.number, r7.number, r7.number, (a, b) => a * b),
                        [3]: new D7(r7.number, r7.number, r7.number, (a, b) => a / b),
                        [4]: new D7(r7.number, r7.number, r7.number, (a, b) => a % b),
                        [5]: new D7(r7.string, r7.string, r7.string, (a, b) => a + b),
                        [6]: new D7(r7.number, r7.number, r7.Hg, (a, b) => a === b),
                        [7]: new D7(r7.number,
                            r7.number, r7.Hg, (a, b) => a !== b),
                        [8]: new D7(r7.number, r7.number, r7.Hg, (a, b) => a < b),
                        [9]: new D7(r7.number, r7.number, r7.Hg, (a, b) => a <= b),
                        [10]: new D7(r7.number, r7.number, r7.Hg, (a, b) => a > b),
                        [11]: new D7(r7.number, r7.number, r7.Hg, (a, b) => a >= b),
                        [12]: new D7(r7.Hg, r7.Hg, r7.Hg, (a, b) => a && b),
                        [13]: new D7(r7.Hg, r7.Hg, r7.Hg, (a, b) => a || b)
                    },
                    kCb = {
                        [2]: new E7(r7.number, r7.number, a => a.reduce((b, c) => b + c, 0)),
                        [3]: new E7(r7.number, r7.number, a => a.reduce((b, c) => b * c, 1)),
                        [4]: new E7(r7.number, r7.number, a => Math.max(...a)),
                        [5]: new E7(r7.number,
                            r7.number, a => Math.min(...a)),
                        [6]: new E7(r7.string, r7.string, a => a.join(""))
                    },
                    rDb = a => w7.array(a),
                    sDb = a => w7.set(a),
                    iCb = {
                        [0]: a => new E7(a, r7.array(a), rDb),
                        [1]: a => new E7(a, r7.set(a), sDb)
                    },
                    SCb = a => w7.map(a),
                    pCb = {
                        [0]: (a, b) => new TCb(a, b, r7.map(a, b))
                    },
                    UCb = a => w7.yc(a),
                    rCb = {
                        [0]: a => new VCb(a, r7.yc(a))
                    },
                    tDb = (a, b) => w7.array(b.map(c => c())),
                    uDb = (a, b) => w7.array(b.flatMap(c => c().items)),
                    vDb = (a, b) => w7.array(a.filter((c, d) => b[d]()).map(c => c())),
                    wDb = (a, b) => b.some(c => c()),
                    xDb = (a, b) => b.every(c => c()),
                    yDb = (a, b) => {
                        var c;
                        return (c =
                            a.find((d, e) => b[e]())) === null || c === void 0 ? void 0 : c()
                    },
                    nCb = {
                        [0]: (a, b) => i7(a, b, r7.array(b), tDb),
                        [1]: (a, b) => b.bH().map(c => i7(a, r7.array(c), r7.array(c), uDb)),
                        [2]: a => i7(a, r7.Hg, r7.array(a), vDb),
                        [3]: a => i7(a, r7.Hg, r7.Hg, wDb),
                        [4]: a => i7(a, r7.Hg, r7.Hg, xDb),
                        [5]: a => i7(a, r7.Hg, r7.optional(a), yDb)
                    };
                var v7 = class {
                    define(a, b) {
                        return new v7(new Map([
                            [a, b]
                        ]), this)
                    }
                    resolve(a) {
                        const b = this.defs.get(a);
                        if (b) return b;
                        if (this.parent) return this.parent.resolve(a);
                        throw Error(`undefined symbol: ${a}`);
                    }
                    constructor(a, b) {
                        this.defs = a;
                        this.parent = b
                    }
                };
                var ADb = (a, b, c) => {
                        const d = new v7(new Map(b.OHa)),
                            e = new zDb(a);
                        return {
                            compile: f => {
                                const g = p7(e, d, f).as(c);
                                return {
                                    eval: h => {
                                        h = new v7(new Map(b.eval(h).zUa));
                                        return g.eval(h)
                                    }
                                }
                            }
                        }
                    },
                    zDb = class {
                        constructor(a) {
                            this.types = a
                        }
                    },
                    u7 = class {
                        static of (a, b) {
                            return new u7(a, b)
                        }
                        as(a) {
                            if (!k7(this.type, a)) throw Error(`inferred type ${this.type} does not match expected type: ${a}`);
                            return this
                        }
                        eval(a) {
                            return this.E5(a)
                        }
                        computed() {
                            return new u7(this.type, a => {
                                const b = B7(this.eval(a), {
                                    equals: w7.pi
                                });
                                return () => b.get()
                            })
                        }
                        map(a) {
                            return a(this)
                        }
                        constructor(a,
                            b) {
                            this.type = a;
                            this.E5 = b
                        }
                    },
                    xCb = class {
                        static of (a, b, c) {
                            return new xCb(a, b, c)
                        }
                        eval(a) {
                            return this.E5(a)
                        }
                        map(a) {
                            return a(this)
                        }
                        constructor(a, b, c) {
                            this.resultType = b;
                            this.E5 = c
                        }
                    };
                var JCb = class {
                        add(a) {
                            a = a(BDb, this.types);
                            return new JCb({ ...this.classes,
                                ...a
                            })
                        }
                        resolve(a) {
                            return this.classes[a]
                        }
                        constructor(a) {
                            this.classes = a;
                            this.types = new gDb(this.classes);
                            this.values = new qDb(this.classes)
                        }
                    },
                    BDb = class {
                        constructor(a, b, c) {
                            this.name = a;
                            this.create = c;
                            this.FRa = new t7(r7.yc(b), r7.instance(this), d => w7.instance(this, c(d.fields)))
                        }
                    };
                var FCb = class {
                    error(a, b) {
                        return Error(`widget '${this.LYa}': schema error on key '${a}': ${b}`)
                    }
                    constructor(a) {
                        this.LYa = a
                    }
                };
                var CDb = Object.freeze({
                    empty: !0,
                    count() {
                        return 0
                    },
                    toArray() {
                        return []
                    },
                    Ss() {
                        return new Map
                    },
                    first() {},
                    last() {},
                    next() {
                        z7()
                    },
                    Qc() {
                        z7()
                    },
                    Qd() {
                        z7()
                    },
                    Ew() {
                        z7()
                    },
                    has() {
                        return !1
                    },
                    yC() {
                        return this
                    },
                    map() {
                        return []
                    },
                    flatMap() {
                        return []
                    },
                    filter() {
                        return []
                    },
                    forEach() {},
                    reduce(a, b) {
                        return b
                    },
                    some() {
                        return !1
                    },
                    every() {
                        return !0
                    },
                    [Symbol.iterator]() {
                        return [][Symbol.iterator]()
                    }
                });
                var DDb = class {
                    static A(a) {
                        __c.P(a, {
                            Id: B7,
                            Wt: B7
                        })
                    }
                    get Id() {
                        return this.jGa().map(a => {
                            let b = this.Ara.get(a);
                            b == null && (b = `${this.MNa++}`, this.Ara.set(a, b));
                            return {
                                id: b,
                                ref: a
                            }
                        })
                    }
                    get Wt() {
                        const a = new Map;
                        this.Id.forEach((b, c) => b && a.set(b.ref, c));
                        return a
                    }
                    xk(a) {
                        return __c.B(this.Wt.get(a), "ref not found")
                    }
                    get empty() {
                        return !this.Id.length
                    }
                    count() {
                        return this.Id.length
                    }
                    toArray() {
                        return this.Id.map(a => a.ref)
                    }
                    Ss() {
                        return new Map(this.map((a, b) => [b, a]))
                    }
                    get JY() {
                        const a = this.Id[0];
                        return a && a.ref
                    }
                    get o_() {
                        const a =
                            this.Id[this.Id.length - 1];
                        return a && a.ref
                    }
                    first(a) {
                        if (!a) return this.JY;
                        const b = this.Id.find(c => a(c.ref));
                        return b && b.ref
                    }
                    last(a) {
                        if (!a) return this.o_;
                        const b = this.Id;
                        for (let c = b.length - 1; c >= 0; c--) {
                            const d = b[c];
                            if (a(d.ref)) return d.ref
                        }
                    }
                    next(a, b) {
                        const c = this.Id;
                        for (a = this.xk(a) + 1; a < c.length; a++) {
                            const d = c[a];
                            if (!b || b(d.ref)) return d.ref
                        }
                    }
                    Qc(a, b) {
                        const c = this.Id;
                        for (a = this.xk(a) - 1; a >= 0; a--) {
                            const d = c[a];
                            if (!b || b(d.ref)) return d.ref
                        }
                    }
                    Qd(a, b) {
                        a = this.Wt.get(a);
                        b = this.Wt.get(b);
                        w(a != null);
                        w(b != null);
                        return a < b ? -1 : a > b ? 1 : 0
                    }
                    Ew(a) {
                        return this.Id[this.xk(a)].id
                    }
                    has(a) {
                        return this.Wt.has(a)
                    }
                    yC(a) {
                        return new __c.QP(this, a)
                    }
                    map(a) {
                        return this.Id.map(({
                            ref: b,
                            id: c
                        }) => a(b, c))
                    }
                    flatMap(a) {
                        return this.Id.flatMap(({
                            ref: b,
                            id: c
                        }) => a(b, c))
                    }
                    filter(a) {
                        return this.Id.filter(b => a(b.ref, b.id)).map(b => b.ref)
                    }
                    forEach(a) {
                        this.Id.forEach((b, c) => a(b.ref, b.id, c))
                    }
                    reduce(a, b) {
                        return this.Id.reduce((c, d) => a(c, d.ref, d.id), b)
                    }
                    some(a) {
                        return this.Id.some(b => a(b.ref, b.id))
                    }
                    every(a) {
                        return this.Id.every(b => a(b.ref, b.id))
                    }[Symbol.iterator]() {
                        return this.toArray()[Symbol.iterator]()
                    }
                    constructor(a) {
                        this.jGa =
                            a;
                        this.MNa = (DDb.A(this), 0);
                        this.Ara = new WeakMap
                    }
                };
                var EDb = new Set,
                    FDb = {
                        At: () => ({
                            gb: CDb
                        })
                    },
                    GDb = class {
                        static A(a) {
                            __c.P(a, {
                                Eda: PCb.shallow
                            })
                        }
                        Wra(a) {
                            if (!EDb.has(a.id)) {
                                var b = a.map(c => {
                                    const d = NCb(this.uDa, c);
                                    if (c.At) {
                                        const e = c.At;
                                        if (typeof e === "function") return {
                                            type: 0,
                                            At: ({
                                                W: h
                                            }) => e({
                                                data: d.eval(h).data
                                            })
                                        };
                                        c = this.Tj.types;
                                        const f = c.instance("RectElement"),
                                            g = this.V7(this.Tj, d, c.fX(f)).compile(e);
                                        return {
                                            type: 0,
                                            At: ({
                                                W: h
                                            }) => {
                                                const k = g.eval(h);
                                                return {
                                                    gb: new __c.cFa(new DDb(() => Array.from(k()).map(l => l.instance)))
                                                }
                                            }
                                        }
                                    }
                                    if (c.Component) {
                                        const e = c.Component;
                                        return {
                                            type: 1,
                                            Component: MCb(this.L, QCb(function({
                                                XJa: f
                                            }) {
                                                const [g] = RCb(() => d.eval({
                                                    Kf: f
                                                }).data);
                                                return A7(e, {
                                                    data: g
                                                })
                                            }))
                                        }
                                    }
                                    throw new E(c);
                                });
                                this.Eda.set(a.id, b);
                                EDb.add(a.id);
                                __c.bS.set(a.id, FDb)
                            }
                        }
                        oLa(a) {
                            return this.Eda.get(a)
                        }
                        constructor(a, b, c, d) {
                            this.uDa = a;
                            this.Tj = b;
                            this.V7 = c;
                            this.L = d;
                            this.Eda = (GDb.A(this), new Map)
                        }
                    };
                var HDb = class {
                    constructor(a) {
                        this.PIa = a;
                        this.vDa = new Map
                    }
                };
                __c.Vza = {
                    FOa: function({
                        L: a
                    }) {
                        var b = {
                            Tj: KCb(),
                            V7: ADb
                        };
                        const {
                            Tj: c,
                            V7: d
                        } = b;
                        b = ICb(c);
                        b = new HDb(b);
                        a = new GDb(b, c, d, a);
                        return {
                            uDa: b,
                            lV: a,
                            mV: a
                        }
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/f54b1a73272d81d8.js.map