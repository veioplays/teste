(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [12942], {

        /***/
        900337: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var jkb = function(a) {
                        if (!a) return a;
                        try {
                            var b = new URL(a)
                        } catch (c) {
                            return a
                        }
                        if (typeof b.pathname === "undefined") return "unsupported";
                        typeof b.search !== "undefined" ? b.search && (b.search = hkb(b.search)) : (b = a.indexOf("?"), a = b === -1 ? a : a.substring(0, b), b = new URL(a));
                        b.pathname = ikb(b.pathname);
                        return b.toString()
                    },
                    ikb = function(a) {
                        if (a.includes("/dist/renderer/")) return "/dist/renderer/" + a.split("/dist/renderer/").pop();
                        if (!a.startsWith("/design/")) return a;
                        const b = a.split("/");
                        if (b.length < 4 || kkb.has(b[3])) return a;
                        b[3] = "*****";
                        return b.join("/")
                    },
                    hkb = function(a) {
                        if (!a || a.length === 0 || !a.startsWith("?")) return a;
                        a = a.slice(a.indexOf("?") + 1).split("&").filter(function(b) {
                            [b] = b.split("=");
                            return lkb.has(b)
                        });
                        return a.length > 0 ? `?${a.join("&")}` : ""
                    },
                    kkb = new Set("share acl remix view edit screen render animate watch published draft".split(" ")),
                    lkb = new Set("utm_source utm_medium utm_campaign utm_content utm_term gclid fbclid msclkid q query clickId referrer signup_referrer redirect origin type category schema dclid _channel_track_key callback_id channel_account_id channel_ad_id channel_adgroup_id channel_campaign_id channel_keyword channel_keyword_id channel_link_type channel_name channel_utm_campaign channel_utm_content channel_utm_medium channel_utm_source channel_utm_term hash_key sat_cf tid link_version utm_adgroup utm_keyword template media create touchpoint_label touchpoint_correlation_id cta_source".split(" "));
                __c.mkb = {
                    Vk: "resource_loaded",
                    Su(a) {
                        return __c.Yw({
                            source: a.source,
                            resource_id: a.pya,
                            success: a.Nc,
                            resource_type: a.resourceType,
                            version: a.version,
                            url: jkb(a.url),
                            watermarked: a.ph,
                            spritesheet: a.ze,
                            height: a.height,
                            width: a.width,
                            quality: a.quality,
                            restricted_access: a.J1,
                            file_size: a.fileSize,
                            failure_reason: a.o9,
                            resource_already_loaded: a.m$a,
                            performance_context: a.cg == null ? void 0 : __c.$w(a.cg),
                            editing_context: a.Ei == null ? void 0 : __c.Zw(a.Ei)
                        })
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/033478e1ac51ecea.js.map