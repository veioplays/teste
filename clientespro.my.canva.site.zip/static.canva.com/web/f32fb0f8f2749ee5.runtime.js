(() => {
    "use strict";
    var e, r, t, n, f, s = {},
        i = {};

    function c(e) {
        var r = i[e];
        if (void 0 !== r) return r.exports;
        var t = i[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return s[e].call(t.exports, t, t.exports, c), t.loaded = !0, t.exports
    }
    c.m = s, c.amdD = function() {
        throw new Error("define cannot be used indirect")
    }, c.amdO = {}, e = [], c.O = (r, t, n, f) => {
        if (!t) {
            var s = 1 / 0;
            for (u = 0; u < e.length; u++) {
                for (var [t, n, f] = e[u], i = !0, a = 0; a < t.length; a++)
                    if ((!1 & f || s >= f) && Object.keys(c.O).every((e => c.O[e](t[a])))) t.splice(a--, 1);
                    else if (i = !1, f < s) s = f;
                if (i) {
                    e.splice(u--, 1);
                    var d = n();
                    if (void 0 !== d) r = d
                }
            }
            return r
        } else {
            f = f || 0;
            for (var u = e.length; u > 0 && e[u - 1][2] > f; u--) e[u] = e[u - 1];
            e[u] = [t, n, f]
        }
    }, c.n = e => {
        var r = e && e.__esModule ? () => e.default : () => e;
        return c.d(r, {
            a: r
        }), r
    }, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, c.t = function(e, n) {
        if (1 & n) e = this(e);
        if (8 & n) return e;
        if ("object" == typeof e && e) {
            if (4 & n && e.__esModule) return e;
            if (16 & n && "function" == typeof e.then) return e
        }
        var f = Object.create(null);
        c.r(f);
        var s = {};
        r = r || [null, t({}), t([]), t(t)];
        for (var i = 2 & n && e;
            "object" == typeof i && !~r.indexOf(i); i = t(i)) Object.getOwnPropertyNames(i).forEach((r => s[r] = () => e[r]));
        return s.default = () => e, c.d(f, s), f
    }, c.d = (e, r) => {
        for (var t in r)
            if (c.o(r, t) && !c.o(e, t)) Object.defineProperty(e, t, {
                enumerable: !0,
                get: r[t]
            })
    }, c.f = {}, c.e = e => Promise.all(Object.keys(c.f).reduce(((r, t) => (c.f[t](e, r), r)), [])), c.u = e => {
        if (50869 === e) return "cc5180c4fc1d7ad4.js";
        if (61454 === e) return "048252aca513298a.vendor.js";
        if (68772 === e) return "68f927d4d76307b6.vendor.js";
        if (71059 === e) return "7ade644b161ae32b.js";
        if (50971 === e) return "3bc1edfcb7dc450b.js";
        if (84437 === e) return "1645c9d0830a89cb.js";
        if (30270 === e) return "6f5b84faf4db8472.js";
        if (32915 === e) return "f54b1a73272d81d8.js";
        if (28646 === e) return "92ecdd8efbf27346.js";
        if (12942 === e) return "033478e1ac51ecea.js";
        if (49830 === e) return "7ee4f8a424e5c794.js";
        if (39314 === e) return "074585094a20250d.js";
        if (85225 === e) return "5f26f08a2a1a45a1.vendor.js";
        if (45085 === e) return "7a5676f9866c7bfd.js";
        if (61615 === e) return "eee6dc3439d31d8b.js";
        if (52358 === e) return "98f8ecb84d76dada.js";
        if (52356 === e) return "6c75dacba2fca984.js";
        if (49392 === e) return "f82a3872a01f6382.js";
        if (70665 === e) return "6df1d2c6337283a1.js";
        if (81623 === e) return "92b8a6b0215b5622.js";
        if (97751 === e) return "5199d6b78c716de4.js";
        if (48376 === e) return "7d238f0789edddd9.js";
        if (63891 === e) return "48ba787d618dcdff.js";
        if (47604 === e) return "25e8945b41b90890.js";
        if (6151 === e) return "2285afdcf56090f0.js";
        if (61442 === e) return "572732def9f27ea0.js";
        if (29046 === e) return "eaf1f407acf32a8a.js";
        if (10412 === e) return "db08178f79ba9fdb.js";
        if (3465 === e) return "aada5ae3bc7a3882.js";
        if (83191 === e) return "a349eab20e85fc02.js";
        if (32255 === e) return "54b5d501be88e5ab.js";
        if (33581 === e) return "dcd09bb3c5d52abf.js";
        if (73539 === e) return "7d457f28ac1cd58b.js";
        if (35672 === e) return "e418b21f61116cf6.js";
        if (83126 === e) return "92d55f7e40df9d5d.js";
        if (49210 === e) return "d344e60c138388e4.js";
        if (49350 === e) return "983d866b72961030.js";
        if (42283 === e) return "3690248450484a85.js";
        if (89840 === e) return "c5a7d0f2069bca72.js";
        if (10785 === e) return "ddbe22175e457eaf.js";
        if (42617 === e) return "f9da6c888b9bdb4c.js";
        if (19326 === e) return "ef8a30a084dea3c2.js";
        if (25360 === e) return "a175473ae3db03d3.js";
        if (15816 === e) return "359130f910ec7b77.js";
        if (83785 === e) return "015f4923752ca510.js";
        if (98384 === e) return "b513093d6cf9637a.js";
        if (39927 === e) return "44f0a274639f30df.js";
        if (30203 === e) return "cd71918460438b51.js";
        if (58899 === e) return "e7914451306e9b90.js";
        if (80978 === e) return "8e4251d73e04191f.js";
        if (34449 === e) return "e474bf09b4343549.js";
        if (5925 === e) return "a4f266a7fbf1ba2a.js";
        if (52595 === e) return "772f109f8259547a.js";
        if (39412 === e) return "41c82a5007502c25.js";
        if (70038 === e) return "4c2c9d8e6acaa3d3.js";
        if (21877 === e) return "5c1c3023fdbe62fe.js";
        if (12894 === e) return "33f90cbc32a16656.js";
        if (44374 === e) return "a4c17b7ededc0ace.js";
        if (67587 === e) return "4d25f7156aedcd0c.js";
        if (38207 === e) return "6fc4a6a18e75fbc9.js";
        if (99925 === e) return "b84e516b81d2c1fa.js";
        if (46384 === e) return "891f853e397162e2.js";
        if (67896 === e) return "b5fe4de42e1333ec.js";
        if (84151 === e) return "af094adcc39cf6f8.js";
        if (63963 === e) return "ee49fdad65e08155.js";
        if (61372 === e) return "67cc0b7cae5971a3.js";
        if (14433 === e) return "e54c6946eb36e039.js";
        if (63299 === e) return "04e3076fcf1eb386.js";
        if (90063 === e) return "50cb16ca51c1ca10.js";
        if (68255 === e) return "77ddca8a58d2ff4a.js";
        if (10188 === e) return "bdc94144972627f2.js";
        if (58911 === e) return "743097edb27da183.js";
        if (20284 === e) return "9dc362b47c539587.js";
        if (67810 === e) return "44ad2f275c678c38.js";
        if (77367 === e) return "b7831a4dcc1d02a1.js";
        if (69774 === e) return "efa5b33a91503571.js";
        if (46492 === e) return "69bd28984a4b1988.js";
        if (85140 === e) return "cb138cee8d5ae653.js";
        if (27172 === e) return "53c6a5bdb6f981c3.js";
        if (97412 === e) return "9160fff556b146a5.js";
        if (87669 === e) return "dafce6840eb801c3.js";
        if (99137 === e) return "1a6f0801356056bf.js";
        if (57257 === e) return "a6aa08e076aed6c6.js";
        if (22221 === e) return "7ca0c51198af91f8.js";
        if (83296 === e) return "95d2164694e9d713.js";
        if (79101 === e) return "c39ed23425048f54.js";
        if (38423 === e) return "55928f75d0a4d070.js";
        if (28338 === e) return "00e163f890ad8570.js";
        if (26271 === e) return "a7e095ea68d7bde6.js";
        if (61433 === e) return "3c977f30d0287ae9.js";
        if (49235 === e) return "2259d9df0c79004d.js";
        if (19750 === e) return "06ed2e81522e8340.js";
        if (65133 === e) return "bb005baa5e92cb7e.js";
        if (10242 === e) return "21924b11f447cc79.js";
        if (19827 === e) return "8ecf585060a775b5.js";
        if (25119 === e) return "92bd099f8f280327.js";
        if (20520 === e) return "97f3cfde3df022ea.js";
        if (80117 === e) return "afc8cd3ab342fcf1.js";
        if (92815 === e) return "a0277a18683f9cee.js";
        if (35011 === e) return "f7f4923df2ab05cb.js";
        if (59981 === e) return "e49518b0eab699fb.vendor.js";
        if (2956 === e) return "2b48f39ef3d88294.vendor.js";
        if (45699 === e) return "f6e4d3fbc4cd81f5.js";
        if (45366 === e) return "7cdcd7b0a429cbae.vendor.js";
        if (21829 === e) return "8be9f6fc3c9fdacf.js";
        if (56782 === e) return "ee0411bbf5bdf21f.js";
        if (50634 === e) return "ea30c6af6b3f4687.js";
        if (87246 === e) return "6bb7df1aefe2bbed.js";
        if (38660 === e) return "8e9a6a90983b6b5f.js";
        if (37438 === e) return "3d9baf3ebe0746f7.js";
        if (76301 === e) return "1103cc9922559a78.js";
        if (24459 === e) return "2e4739bc1307d0b5.js";
        if (1794 === e) return "7ca18cee227e6676.js";
        if (96826 === e) return "c98064e9889c02b9.vendor.js";
        if (47798 === e) return "ca28da7c6c3ed930.js";
        if (14408 === e) return "4449a15712070741.js";
        if (91969 === e) return "21e8899554a99b5a.js";
        if (89303 === e) return "b8ce26fd07bc890b.js";
        if (57399 === e) return "259c7a4a345df707.js";
        if (19289 === e) return "6c978a0ec0acce1e.js";
        if (60205 === e) return "e1eaeef01833c457.js";
        if (13794 === e) return "2d395eae5a8b1220.js";
        if (10316 === e) return "8e2babe484d380d7.js";
        if (61316 === e) return "79eccd82a0c43ede.js";
        if (47523 === e) return "b484cc66462541b5.js";
        if (2906 === e) return "0ce359a439fdb6f9.js";
        if (4450 === e) return "99ed2a56a27b5af7.js";
        if (45749 === e) return "2b2beda052670ebf.js";
        if (50463 === e) return "3306fe457aff725c.js";
        if (38734 === e) return "e650b3683e8a526a.js";
        if (11298 === e) return "5583ca9d40d88002.js";
        if (13073 === e) return "e368aa53cfc7a9bf.js";
        if (53256 === e) return "daf2ad5e0e50df9b.js";
        if (14902 === e) return "4db41390bd8ff12f.js";
        if (14955 === e) return "db1dbdb80a696349.js"
    }, c.miniCssF = e => {
        if (50869 === e) return "d47fa7f5e61148d4.ltr.css";
        if ({
                61454: 1,
                68772: 1,
                85225: 1,
                59981: 1,
                2956: 1,
                45366: 1,
                96826: 1
            }[e]) return "ef46db3751d8e999.vendor.ltr.css";
        if ({
                71059: 1,
                84437: 1,
                30270: 1,
                32915: 1,
                28646: 1,
                12942: 1,
                49830: 1,
                39314: 1,
                45085: 1,
                61615: 1,
                52358: 1,
                52356: 1,
                70665: 1,
                81623: 1,
                97751: 1,
                48376: 1,
                63891: 1,
                47604: 1,
                6151: 1,
                61442: 1,
                10412: 1,
                3465: 1,
                83191: 1,
                32255: 1,
                33581: 1,
                73539: 1,
                35672: 1,
                83126: 1,
                49350: 1,
                42283: 1,
                89840: 1,
                10785: 1,
                42617: 1,
                19326: 1,
                25360: 1,
                15816: 1,
                83785: 1,
                98384: 1,
                39927: 1,
                30203: 1,
                58899: 1,
                80978: 1,
                34449: 1,
                5925: 1,
                52595: 1,
                39412: 1,
                70038: 1,
                21877: 1,
                12894: 1,
                44374: 1,
                67587: 1,
                38207: 1,
                99925: 1,
                46384: 1,
                67896: 1,
                84151: 1,
                63963: 1,
                61372: 1,
                14433: 1,
                63299: 1,
                90063: 1,
                68255: 1,
                10188: 1,
                58911: 1,
                20284: 1,
                67810: 1,
                77367: 1,
                69774: 1,
                46492: 1,
                85140: 1,
                27172: 1,
                97412: 1,
                87669: 1,
                99137: 1,
                57257: 1,
                22221: 1,
                83296: 1,
                79101: 1,
                38423: 1,
                26271: 1,
                61433: 1,
                49235: 1,
                19750: 1,
                10242: 1,
                19827: 1,
                25119: 1,
                92815: 1,
                45699: 1,
                21829: 1,
                56782: 1,
                87246: 1,
                38660: 1,
                37438: 1,
                24459: 1,
                47798: 1,
                89303: 1,
                57399: 1,
                19289: 1,
                13794: 1,
                10316: 1,
                61316: 1,
                47523: 1,
                2906: 1,
                4450: 1,
                45749: 1,
                50463: 1,
                38734: 1,
                11298: 1,
                13073: 1,
                53256: 1,
                14902: 1,
                14955: 1
            }[e]) return "ef46db3751d8e999.ltr.css";
        if (50971 === e) return "638e8938c76a575e.ltr.css";
        if (49392 === e) return "e71066744fca056b.ltr.css";
        if (29046 === e) return "f6e522ba1b73f662.ltr.css";
        if (49210 === e) return "5f1d4839e07de62c.ltr.css";
        if (28338 === e) return "71dec1f5d11e3f66.ltr.css";
        if (65133 === e) return "05624d166fe81780.ltr.css";
        if (20520 === e) return "f8678f5d2a496896.ltr.css";
        if (80117 === e) return "aed61a49fdfc513b.ltr.css";
        if (35011 === e) return "ca10385ab7f3657c.ltr.css";
        if (50634 === e) return "5b2241d885919c07.ltr.css";
        if (76301 === e) return "9abc6146f4633109.ltr.css";
        if (1794 === e) return "5b7fe8f909b06739.ltr.css";
        if (14408 === e) return "9094dc9ec76e31ae.ltr.css";
        if (91969 === e) return "924c43291449318d.ltr.css";
        if (60205 === e) return "ee8b17ce4967cfe1.ltr.css"
    }, c.miniCssFRtl = e => {
        if (98581 === e) return "c166e5d20ad58f4e.runtime.rtl.css";
        if (69588 === e) return "c166e5d20ad58f4e.i3d79q.vendor.rtl.css";
        if (25436 === e) return "8e54262212aed57f.vendor.rtl.css";
        if (95433 === e) return "c166e5d20ad58f4e.5a9ync.vendor.rtl.css";
        if (21389 === e) return "06955deed45986f6.rtl.css";
        if (50869 === e) return "4f05c1b2bf63d608.rtl.css";
        if ({
                61454: 1,
                68772: 1,
                85225: 1,
                59981: 1,
                2956: 1,
                45366: 1,
                96826: 1
            }[e]) return "c166e5d20ad58f4e.vendor.rtl.css";
        if ({
                71059: 1,
                84437: 1,
                30270: 1,
                32915: 1,
                28646: 1,
                12942: 1,
                49830: 1,
                39314: 1,
                45085: 1,
                61615: 1,
                52358: 1,
                52356: 1,
                70665: 1,
                81623: 1,
                97751: 1,
                48376: 1,
                63891: 1,
                47604: 1,
                6151: 1,
                61442: 1,
                10412: 1,
                3465: 1,
                83191: 1,
                32255: 1,
                33581: 1,
                73539: 1,
                35672: 1,
                83126: 1,
                49350: 1,
                42283: 1,
                89840: 1,
                10785: 1,
                42617: 1,
                19326: 1,
                25360: 1,
                15816: 1,
                83785: 1,
                98384: 1,
                39927: 1,
                30203: 1,
                58899: 1,
                80978: 1,
                34449: 1,
                5925: 1,
                52595: 1,
                39412: 1,
                70038: 1,
                21877: 1,
                12894: 1,
                44374: 1,
                67587: 1,
                38207: 1,
                99925: 1,
                46384: 1,
                67896: 1,
                84151: 1,
                63963: 1,
                61372: 1,
                14433: 1,
                63299: 1,
                90063: 1,
                68255: 1,
                10188: 1,
                58911: 1,
                20284: 1,
                67810: 1,
                77367: 1,
                69774: 1,
                46492: 1,
                85140: 1,
                27172: 1,
                97412: 1,
                87669: 1,
                99137: 1,
                57257: 1,
                22221: 1,
                83296: 1,
                79101: 1,
                38423: 1,
                26271: 1,
                61433: 1,
                49235: 1,
                19750: 1,
                10242: 1,
                19827: 1,
                25119: 1,
                92815: 1,
                45699: 1,
                21829: 1,
                56782: 1,
                87246: 1,
                38660: 1,
                37438: 1,
                24459: 1,
                47798: 1,
                89303: 1,
                57399: 1,
                19289: 1,
                13794: 1,
                10316: 1,
                61316: 1,
                47523: 1,
                2906: 1,
                4450: 1,
                45749: 1,
                50463: 1,
                38734: 1,
                11298: 1,
                13073: 1,
                53256: 1,
                14902: 1,
                14955: 1
            }[e]) return "c166e5d20ad58f4e.rtl.css";
        if (50971 === e) return "1e246b15020f607d.rtl.css";
        if (49392 === e) return "b53e0b8f14174717.rtl.css";
        if (29046 === e) return "1991a15a9b55f670.rtl.css";
        if (49210 === e) return "b4bd268b7e5afaa4.rtl.css";
        if (28338 === e) return "7cf7805937173758.rtl.css";
        if (65133 === e) return "5e44a47af6e0da97.rtl.css";
        if (20520 === e) return "29bdbb1d75c8c7a3.rtl.css";
        if (80117 === e) return "7dac84e36568326f.rtl.css";
        if (35011 === e) return "be92cdc2c813e15f.rtl.css";
        if (50634 === e) return "3759df5a77daebac.rtl.css";
        if (76301 === e) return "7358c135fc748141.rtl.css";
        if (1794 === e) return "b197b394e4f55ce1.rtl.css";
        if (14408 === e) return "918171a1aa694966.rtl.css";
        if (91969 === e) return "d41a1c13df702638.rtl.css";
        if (60205 === e) return "272adea3752f60f0.rtl.css"
    }, c.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), c.hmd = e => {
        if (!(e = Object.create(e)).children) e.children = [];
        return Object.defineProperty(e, "exports", {
            enumerable: !0,
            set: () => {
                throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id)
            }
        }), e
    }, c.o = (e, r) => Object.prototype.hasOwnProperty.call(e, r), n = {}, f = "@canva/web:", c.l = (e, r, t, s) => {
        if (!n[e]) {
            var i, a;
            if (void 0 !== t)
                for (var d = document.getElementsByTagName("script"), u = 0; u < d.length; u++) {
                    var o = d[u];
                    if (o.getAttribute("src") == e || o.getAttribute("data-webpack") == f + t) {
                        i = o;
                        break
                    }
                }
            if (!i) {
                if (a = !0, (i = document.createElement("script")).charset = "utf-8", i.timeout = 120, c.nc) i.setAttribute("nonce", c.nc);
                i.setAttribute("data-webpack", f + t), i.src = e
            }
            n[e] = [r];
            var l = (r, t) => {
                    i.onerror = i.onload = null, clearTimeout(b);
                    var f = n[e];
                    if (delete n[e], i.parentNode && i.parentNode.removeChild(i), f && f.forEach((e => e(t))), r) return r(t)
                },
                b = setTimeout(l.bind(null, void 0, {
                    type: "timeout",
                    target: i
                }), 12e4);
            i.onerror = l.bind(null, i.onerror), i.onload = l.bind(null, i.onload), a && document.head.appendChild(i)
        } else n[e].push(r)
    }, c.r = e => {
        if ("undefined" != typeof Symbol && Symbol.toStringTag) Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        });
        Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, c.nmd = e => {
        if (e.paths = [], !e.children) e.children = [];
        return e
    }, (() => {
        const e = c.e,
            r = function e(r, t, n) {
                return r().catch((function(f) {
                    return 0 === n ? Promise.reject(f) : (s = t, new Promise((function(e) {
                        setTimeout(e, s)
                    }))).then((function() {
                        return e(r, t, n - 1)
                    }));
                    var s
                }))
            };
        c.e = function(t) {
            return r((function() {
                return e(t)
            }), 1e3, 5)
        }
    })(), c.p = "", (() => {
        if (self.__batch_chunks__) ! function(e, r, t, n, f, s, i, c, a) {
            const d = e.l;
            let u = [],
                o = [];
            const l = [];
            for (const O of document.head.querySelectorAll('link[rel="prefetch"][href]')) {
                const e = O.getAttribute("href");
                e && l.push(e)
            }
            let b = e => document.head.appendChild(e);
            e.l = function(e, r, f, i) {
                for (let t = 0; t < l.length; t++)
                    if (l[t].endsWith(e)) return l.splice(t, 1), d(e, r, f, i);
                if (t) {
                    if (0 === u.length) Promise.resolve().then((() => {
                        k(u, p), u = [], h = 0
                    }));
                    const r = y(e);
                    if (u.length >= 1 && h + r > s || u.length >= n) k(u, p), u = [], h = 0;
                    h += r
                } else {
                    if (j++ < 10) return d(e, r, f, i);
                    if (0 === u.length) setTimeout((() => w(u, p)), 1)
                }
                u.push({
                    src: e,
                    callback: function(t) {
                        if ("load" === t.type) r(t);
                        else d(e, r, f, i)
                    },
                    originalLoad: () => {
                        d(e, r, f, i)
                    }
                })
            }, e.loadCss = function(e, r) {
                const f = e.getAttribute("href");
                if (b = r || b, t) {
                    if (0 === o.length) Promise.resolve().then((() => {
                        k(o, v), o = [], g = 0
                    }));
                    const e = y(f);
                    if (o.length >= 1 && g + e > s || o.length >= n) k(o, v), o = [], g = 0;
                    g += e
                } else {
                    if (m++ < 15) return r(e);
                    if (0 === o.length) setTimeout((() => w(o, v)), 1)
                }
                o.push({
                    src: f,
                    callback: t => {
                        if ("load" === t.type) e.onload && e.onload(t);
                        else r(e)
                    },
                    originalLoad: () => {
                        r(e)
                    }
                })
            };
            let j = 0,
                h = 0;

            function p(e, t) {
                const n = document.createElement("script");
                let f;
                const s = e => {
                    n.onerror = n.onload = null, clearTimeout(f), n.parentNode && n.parentNode.removeChild(n), t("string" == typeof e ? {
                        type: "error",
                        target: {}
                    } : e)
                };
                n.onload = n.onerror = s, n.src = e, n.async = !1, f = setTimeout((() => s({
                    type: "timeout",
                    target: n
                })), r), document.head.appendChild(n)
            }
            let m = 0,
                g = 0;

            function v(e, r) {
                const t = document.createElement("link");
                t.onload = t.onerror = e => r(e), t.href = e, t.rel = "stylesheet", b(t)
            }

            function y(e) {
                const r = f(),
                    t = e.substring(r.length);
                return t ? i[t] || 0 : 0
            }

            function _() {
                const e = f(),
                    r = new URL(window.location.href);
                if (null == e ? void 0 : e.startsWith("http")) {
                    const {
                        protocol: r,
                        host: t
                    } = new URL(e);
                    return `${r}//chunk-composing.${t.split(".").slice(-2).join(".")}`
                } else if (["localhost", "127.0.0.1"].includes(r.hostname) && r.searchParams.get("pageLoadWorkerUrl")) return r.searchParams.get("pageLoadWorkerUrl");
                else return r.origin
            }
            async function w(e, r) {
                const t = f();
                let d, u = 0,
                    o = [];
                try {
                    d = self.navigator.serviceWorker
                } catch {}
                const l = c && (null == d ? void 0 : d.controller) ? await async function(e) {
                    const r = await caches.open(a),
                        t = [];
                    for (const n of e)
                        if (await r.match(n.src)) n.originalLoad();
                        else t.push(n);
                    return t
                }(e) : e;
                for (const f of l) {
                    const e = f.src.substring(t.length),
                        r = e ? i[e] || 0 : 0;
                    if (o.length >= 1 && u + r > s || o.length >= n) b(o), o = [], u = 0;
                    o.push(f), u += r
                }

                function b(e) {
                    if (1 === e.length) return void e[0].originalLoad();
                    const n = _(),
                        f = e.map((({
                            src: e
                        }) => e.substring(t.length))).join("+");
                    r(`${n}/chunk-batch/${f}`, (r => {
                        for (const {
                                callback: t,
                                src: n
                            } of e) t({
                            type: r.type,
                            target: {
                                src: n,
                                href: n
                            }
                        })
                    }))
                }
                o.length && b(o), e.length = 0
            }

            function k(e, r) {
                if (0 === e.length) return;
                const t = f();
                if (1 !== e.length) r(`${_()}/chunk-batch/${e.map((({src:e})=>e.substring(t.length))).join("+")}`, (r => {
                    for (const {
                            callback: t,
                            src: n
                        } of e) t({
                        type: r.type,
                        target: {
                            src: n,
                            href: n
                        }
                    })
                }));
                else e[0].originalLoad()
            }
        }(c, 12e4, self.__sync_batch_chunks__, 40, (() => c.p), 10485760, {
            "49d9a8e2f7bd6808.ltr.css": 449976,
            "630a8f16d487d067.js": 13298252,
            "06955deed45986f6.rtl.css": 449988,
            "f32fb0f8f2749ee5.runtime.js": 71600,
            "a0684b0780c739e9.vendor.ltr.css": 15361,
            "649092012afd1cc2.vendor.js": 2247748,
            "8e54262212aed57f.vendor.rtl.css": 15361,
            "411de7fe679f1413.5a9ync.vendor.js": 85008,
            "aaa08f5161a956c7.i3d79q.vendor.js": 704145,
            "d47fa7f5e61148d4.ltr.css": 7483,
            "cc5180c4fc1d7ad4.js": 36630,
            "4f05c1b2bf63d608.rtl.css": 7483,
            "048252aca513298a.vendor.js": 158490,
            "68f927d4d76307b6.vendor.js": 125594,
            "7ade644b161ae32b.js": 121022,
            "638e8938c76a575e.ltr.css": 412,
            "3bc1edfcb7dc450b.js": 170228,
            "1e246b15020f607d.rtl.css": 414,
            "f54b1a73272d81d8.js": 304598,
            "6f5b84faf4db8472.js": 81266,
            "1645c9d0830a89cb.js": 13577,
            "92ecdd8efbf27346.js": 258971,
            "5583ca9d40d88002.js": 106004,
            "033478e1ac51ecea.js": 12247,
            "7ee4f8a424e5c794.js": 40241,
            "074585094a20250d.js": 29682,
            "5f26f08a2a1a45a1.vendor.js": 167628,
            "e71066744fca056b.ltr.css": 3310,
            "f82a3872a01f6382.js": 1764804,
            "b53e0b8f14174717.rtl.css": 3310,
            "eee6dc3439d31d8b.js": 7482,
            "6c75dacba2fca984.js": 102808,
            "98f8ecb84d76dada.js": 9298,
            "7a5676f9866c7bfd.js": 1315,
            "6df1d2c6337283a1.js": 112866,
            "5199d6b78c716de4.js": 231097,
            "92b8a6b0215b5622.js": 43283,
            "7d238f0789edddd9.js": 40289,
            "48ba787d618dcdff.js": 137432,
            "f6e522ba1b73f662.ltr.css": 322,
            "eaf1f407acf32a8a.js": 73595,
            "1991a15a9b55f670.rtl.css": 322,
            "2285afdcf56090f0.js": 1779,
            "54b5d501be88e5ab.js": 192320,
            "aada5ae3bc7a3882.js": 872,
            "a349eab20e85fc02.js": 5251,
            "dcd09bb3c5d52abf.js": 18077,
            "572732def9f27ea0.js": 78343,
            "db08178f79ba9fdb.js": 23631,
            "7d457f28ac1cd58b.js": 64243,
            "e418b21f61116cf6.js": 13382,
            "92d55f7e40df9d5d.js": 6031,
            "5f1d4839e07de62c.ltr.css": 2196,
            "d344e60c138388e4.js": 24544,
            "b4bd268b7e5afaa4.rtl.css": 2196,
            "983d866b72961030.js": 105878,
            "3690248450484a85.js": 19475,
            "c5a7d0f2069bca72.js": 21590,
            "ddbe22175e457eaf.js": 1648,
            "f9da6c888b9bdb4c.js": 1680,
            "ef8a30a084dea3c2.js": 1449,
            "a175473ae3db03d3.js": 1448,
            "359130f910ec7b77.js": 1447,
            "015f4923752ca510.js": 1445,
            "b513093d6cf9637a.js": 1445,
            "44f0a274639f30df.js": 1561,
            "cd71918460438b51.js": 1650,
            "e7914451306e9b90.js": 1448,
            "8e4251d73e04191f.js": 1447,
            "e474bf09b4343549.js": 1458,
            "a4f266a7fbf1ba2a.js": 1448,
            "772f109f8259547a.js": 1450,
            "41c82a5007502c25.js": 1554,
            "4c2c9d8e6acaa3d3.js": 1552,
            "5c1c3023fdbe62fe.js": 1537,
            "33f90cbc32a16656.js": 1453,
            "a4c17b7ededc0ace.js": 1627,
            "4d25f7156aedcd0c.js": 1728,
            "6fc4a6a18e75fbc9.js": 1440,
            "b84e516b81d2c1fa.js": 1539,
            "891f853e397162e2.js": 1586,
            "b5fe4de42e1333ec.js": 1674,
            "af094adcc39cf6f8.js": 1674,
            "ee49fdad65e08155.js": 1684,
            "67cc0b7cae5971a3.js": 1585,
            "e54c6946eb36e039.js": 1781,
            "04e3076fcf1eb386.js": 1570,
            "50cb16ca51c1ca10.js": 1671,
            "77ddca8a58d2ff4a.js": 1626,
            "bdc94144972627f2.js": 1627,
            "9dc362b47c539587.js": 186569,
            "71dec1f5d11e3f66.ltr.css": 360,
            "00e163f890ad8570.js": 426849,
            "7cf7805937173758.rtl.css": 360,
            "cb138cee8d5ae653.js": 245118,
            "9160fff556b146a5.js": 530364,
            "efa5b33a91503571.js": 84986,
            "a6aa08e076aed6c6.js": 23985,
            "95d2164694e9d713.js": 170077,
            "55928f75d0a4d070.js": 2185,
            "69bd28984a4b1988.js": 6218,
            "743097edb27da183.js": 10118,
            "53c6a5bdb6f981c3.js": 30017,
            "7ca0c51198af91f8.js": 5761,
            "b7831a4dcc1d02a1.js": 10906,
            "a7e095ea68d7bde6.js": 116049,
            "c39ed23425048f54.js": 1091,
            "1a6f0801356056bf.js": 23329,
            "3c977f30d0287ae9.js": 148037,
            "2259d9df0c79004d.js": 298153,
            "05624d166fe81780.ltr.css": 698,
            "bb005baa5e92cb7e.js": 3846,
            "5e44a47af6e0da97.rtl.css": 698,
            "8ecf585060a775b5.js": 327036,
            "21924b11f447cc79.js": 8299,
            "06ed2e81522e8340.js": 8324,
            "f8678f5d2a496896.ltr.css": 355,
            "97f3cfde3df022ea.js": 278416,
            "29bdbb1d75c8c7a3.rtl.css": 355,
            "92bd099f8f280327.js": 80367,
            "aed61a49fdfc513b.ltr.css": 355,
            "afc8cd3ab342fcf1.js": 299206,
            "7dac84e36568326f.rtl.css": 355,
            "ca10385ab7f3657c.ltr.css": 354,
            "f7f4923df2ab05cb.js": 68685,
            "be92cdc2c813e15f.rtl.css": 354,
            "a0277a18683f9cee.js": 3520,
            "f6e4d3fbc4cd81f5.js": 207788,
            "e49518b0eab699fb.vendor.js": 12754,
            "2b48f39ef3d88294.vendor.js": 18823,
            "8be9f6fc3c9fdacf.js": 209694,
            "7cdcd7b0a429cbae.vendor.js": 13455,
            "ee0411bbf5bdf21f.js": 375321,
            "5b2241d885919c07.ltr.css": 360,
            "ea30c6af6b3f4687.js": 184095,
            "3759df5a77daebac.rtl.css": 360,
            "6bb7df1aefe2bbed.js": 250647,
            "8e9a6a90983b6b5f.js": 78007,
            "9abc6146f4633109.ltr.css": 11620,
            "1103cc9922559a78.js": 753211,
            "7358c135fc748141.rtl.css": 11620,
            "2e4739bc1307d0b5.js": 40947,
            "5b7fe8f909b06739.ltr.css": 913,
            "7ca18cee227e6676.js": 173675,
            "b197b394e4f55ce1.rtl.css": 913,
            "c98064e9889c02b9.vendor.js": 648073,
            "9094dc9ec76e31ae.ltr.css": 446,
            "4449a15712070741.js": 20518,
            "918171a1aa694966.rtl.css": 446,
            "ca28da7c6c3ed930.js": 19139,
            "924c43291449318d.ltr.css": 263,
            "21e8899554a99b5a.js": 10752,
            "d41a1c13df702638.rtl.css": 263,
            "259c7a4a345df707.js": 464080,
            "ee8b17ce4967cfe1.ltr.css": 8805,
            "e1eaeef01833c457.js": 290842,
            "272adea3752f60f0.rtl.css": 8805,
            "8e2babe484d380d7.js": 541647,
            "b484cc66462541b5.js": 35916,
            "79eccd82a0c43ede.js": 85412,
            "daf2ad5e0e50df9b.js": 728,
            "0ce359a439fdb6f9.js": 4789,
            "99ed2a56a27b5af7.js": 40070,
            "2b2beda052670ebf.js": 191940,
            "4db41390bd8ff12f.js": 6493,
            "db1dbdb80a696349.js": 38624
        }, self.__check_cache_batch_chunks__, "assets-2")
    })(), (() => {
        const e = JSON.parse('{"2650":58899,"10588":35672,"16139":45699,"26307":61433,"26759":39927,"33714":33581,"38844":19827,"46989":49210,"77732":50463,"78999":57399,"82986":28646,"83888":49392,"88780":32915,"100606":38660,"103478":38734,"110247":63891,"126802":99925,"144616":68772,"150721":70665,"150778":30203,"201268":14433,"217517":56782,"223244":26271,"227900":42283,"229894":97751,"250851":46384,"254588":91969,"261760":52595,"266055":4450,"292270":48376,"314854":38207,"317158":21877,"335146":12894,"340693":50869,"345045":11298,"356430":89840,"428405":47523,"432521":83126,"456572":14955,"460541":24459,"465530":90063,"467611":49350,"469546":53256,"482919":49235,"490896":50634,"502437":4450,"519561":20520,"520679":25360,"521746":10188,"535189":13073,"545058":80978,"555434":73539,"556151":52358,"563026":70038,"567764":39314,"571038":67587,"572534":14902,"582389":61442,"594403":63299,"605338":10316,"617807":52356,"621071":34449,"636287":61372,"647312":19326,"652365":44374,"652535":50971,"658506":71059,"678201":68255,"700123":21829,"730337":49830,"733653":87246,"738083":76301,"741114":37438,"744620":61454,"777985":39412,"796735":1794,"807817":45749,"819178":10785,"846915":14408,"870064":42617,"877501":63963,"905923":84151,"933618":67896,"938629":15816,"959820":83785,"978457":98384,"988209":80117,"990570":5925,"994944":60205}'),
            r = JSON.parse('{"1794":[45085,85225],"2906":[61316],"2956":[59981],"3465":[],"4450":[2906],"5925":[],"6151":[],"10188":[],"10242":[],"10316":[13794,89303],"10412":[29046,61442],"10785":[],"11298":[30270,84437],"12894":[],"12942":[],"13073":[],"13794":[],"14408":[47798,96826],"14433":[],"14902":[45749],"14955":[],"15816":[],"19289":[],"19326":[],"19750":[],"19827":[10242,20284,22221,32255,38423,57257,65133,67810,69774,87669],"20284":[29046,58911],"20520":[10242,19750,20284,22221,25119,32255,38423,57257,67810,79101],"21389":[],"21829":[35011,38423,45366,49350,83191,92815],"21877":[],"22221":[29046],"24459":[12942],"25119":[83296,99137],"25360":[],"25436":[],"26271":[28338],"27172":[29046],"28338":[22221,32255,38423,57257,67810,77367,79101,83296,87669,97412,99137],"28646":[30270],"29046":[61615],"30203":[],"30270":[],"32255":[29046,3465,47604,6151,83191],"32915":[30270,84437],"33581":[10412,32255],"34449":[],"35011":[46492,85140,89840],"35672":[],"37438":[],"38207":[],"38423":[],"38660":[19750,32255,38423,57257,83296,99137],"38734":[],"39314":[],"39412":[],"39927":[],"42283":[],"42617":[],"44374":[],"45085":[],"45366":[59981],"45699":[2956,35011,38423,49350,83191,92815],"45749":[],"46384":[],"46492":[58911],"47523":[19289,61316],"47604":[],"47798":[],"48376":[],"49210":[],"49235":[22221,38423,97412,99137],"49350":[],"49392":[45085,52356,85225],"49830":[12942],"50463":[],"50634":[32255,38423,57257,58911,67810,77367,79101,83296],"50869":[],"50971":[],"52356":[52358],"52358":[61615],"52595":[],"53256":[2906],"56782":[20284,27172,46492,47604,57257,69774,77367,83296,92815],"57257":[10412],"57399":[89303],"58899":[],"58911":[],"59981":[],"60205":[19289],"61316":[13794],"61372":[],"61433":[28338],"61442":[],"61454":[],"61615":[],"63299":[],"63891":[48376],"63963":[],"65133":[19750,77367,83296],"67587":[],"67810":[],"67896":[],"68255":[],"68772":[],"69588":[],"69774":[],"70038":[],"70665":[],"71059":[],"73539":[3465],"76301":[],"77367":[],"79101":[],"80117":[10242,19750,20284,22221,25119,32255,38423,57257,67810,79101],"80978":[],"81623":[],"83126":[],"83191":[],"83296":[85140],"83785":[],"84151":[],"84437":[],"85140":[29046,81623],"85225":[],"87246":[20284,22221,25119,3465,38423,47604,6151,65133,83191],"87669":[85140],"89303":[],"89840":[],"90063":[],"91969":[47798,96826],"92815":[],"95433":[],"96826":[],"97412":[20284,27172,46492,6151,85140],"97751":[81623],"98384":[],"99137":[69774,85140],"99925":[]}'),
            t = (e, n, f) => {
                if (!f.has(e)) return f.add(e), r[e].forEach((e => t(e, n, f))), n.push(e), n
            };
        c.me = function(r) {
            const n = e[r];
            if (null == n) return Promise.resolve(c(r));
            const f = t(n, [], new Set);
            return Promise.all(f.map((e => c.e(e)))).then((() => c(r)))
        }
    })(), (() => {
        const e = {};
        c.f.locale = function(r, t) {
            ! function(e, r, t) {
                if (null == r[e]) {
                    const t = self.cmsg;
                    if (!t || !t.assets) return;
                    const n = t.loaded,
                        f = t.locale || "en";
                    if (n && n[e + "_" + f]) return;
                    const s = t.assets[f] && t.assets[f][e] && t.assets[f][e].js;
                    if (!s) return;
                    r[e] = Promise.all(s.map((t => new Promise(((n, f) => {
                        const s = c.p + t;
                        c.l(s, (s => {
                            if ("load" === s.type) r[e] = 0, n();
                            else delete r[e], f(new Error(`Fail to load message files@${t}`))
                        }), "ensure-locale-" + e, e)
                    })))))
                }
                const n = r[e];
                if (n) t.push(n)
            }(r, e, t)
        }
    })(), (() => {
        let e = "undefined" != typeof self && void 0 !== self.document ? self.document.body.parentElement.getAttribute("dir") : "ltr";
        if ("ltr" !== e && "rtl" !== e) console.warn("Could not determine the direction of text, please check that the dir attribute is set on the html tag"), e = "ltr";
        if ("rtl" === e) c.miniCssF = c.miniCssFRtl
    })(), (() => {
        if ("undefined" != typeof document) {
            var e = e => new Promise(((r, t) => {
                    var n = c.miniCssF(e),
                        f = c.p + n;
                    if (((e, r) => {
                            for (var t = document.getElementsByTagName("link"), n = 0; n < t.length; n++) {
                                var f = (i = t[n]).getAttribute("data-href") || i.getAttribute("href");
                                if ("stylesheet" === i.rel && (f === e || f === r)) return i
                            }
                            var s = document.getElementsByTagName("style");
                            for (n = 0; n < s.length; n++) {
                                var i;
                                if ((f = (i = s[n]).getAttribute("data-href")) === e || f === r) return i
                            }
                        })(n, f)) return r();
                    ((e, r, t, n, f) => {
                        var s = document.createElement("link");
                        s.rel = "stylesheet", s.type = "text/css", s.onerror = s.onload = t => {
                                if (s.onerror = s.onload = null, "load" === t.type) n();
                                else {
                                    var i = t && ("load" === t.type ? "missing" : t.type),
                                        c = t && t.target && t.target.href || r,
                                        a = new Error("Loading CSS chunk " + e + " failed.\n(" + c + ")");
                                    if (a.code = "CSS_CHUNK_LOAD_FAILED", a.type = i, a.request = c, s.parentNode) s.parentNode.removeChild(s);
                                    f(a)
                                }
                            }, s.href = r,
                            function(e) {
                                const r = e => {
                                    document.head.appendChild(e)
                                };
                                if (c.loadCss) c.loadCss(e, r);
                                else r(e)
                            }(s)
                    })(e, f, 0, r, t)
                })),
                r = {
                    98581: 0
                };
            c.f.miniCss = (t, n) => {
                if (r[t]) n.push(r[t]);
                else if (0 !== r[t] && {
                        1794: 1,
                        14408: 1,
                        20520: 1,
                        28338: 1,
                        29046: 1,
                        35011: 1,
                        49210: 1,
                        49392: 1,
                        50634: 1,
                        50869: 1,
                        50971: 1,
                        60205: 1,
                        65133: 1,
                        76301: 1,
                        80117: 1,
                        91969: 1
                    }[t]) n.push(r[t] = e(t).then((() => {
                    r[t] = 0
                }), (e => {
                    throw delete r[t], e
                })))
            }
        }
    })(), (() => {
        var e = {
            98581: 0
        };
        c.f.j = (r, t) => {
            var n = c.o(e, r) ? e[r] : void 0;
            if (0 !== n)
                if (n) t.push(n[2]);
                else if (98581 != r) {
                var f = new Promise(((t, f) => n = e[r] = [t, f]));
                t.push(n[2] = f);
                var s = c.p + c.u(r),
                    i = new Error;
                c.l(s, (t => {
                    if (c.o(e, r)) {
                        if (0 !== (n = e[r])) e[r] = void 0;
                        if (n) {
                            var f = t && ("load" === t.type ? "missing" : t.type),
                                s = t && t.target && t.target.src;
                            i.message = "Loading chunk " + r + " failed.\n(" + f + ": " + s + ")", i.name = "ChunkLoadError", i.type = f, i.request = s, n[1](i)
                        }
                    }
                }), "chunk-" + r, r)
            } else e[r] = 0
        }, c.O.j = r => 0 === e[r];
        var r = (r, t) => {
                var n, f, [s, i, a] = t,
                    d = 0;
                if (s.some((r => 0 !== e[r]))) {
                    for (n in i)
                        if (c.o(i, n)) c.m[n] = i[n];
                    if (a) var u = a(c)
                }
                if (r) r(t);
                for (; d < s.length; d++) {
                    if (f = s[d], c.o(e, f) && e[f]) e[f][0]();
                    e[f] = 0
                }
                return c.O(u)
            },
            t = self.webpackChunk_canva_web = self.webpackChunk_canva_web || [];
        t.forEach(r.bind(null, 0)), t.push = r.bind(null, t.push.bind(t))
    })()
})();
//# sourceMappingURL=sourcemaps/f32fb0f8f2749ee5.runtime.js.map