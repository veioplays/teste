(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [28646], {

        /***/
        82986: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(914242);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var FO = __c.FO;
                var X = __c.X;
                var M = __c.M;
                var Ga = __c.Ga;
                var iBb = function() {
                        return new __c.B0({
                            id: "w:demo-blueprint",
                            HF: gBb,
                            At: ({
                                data: a
                            }) => {
                                var b = hBb.get(a.G6);
                                if (!b) throw Error(`Blueprint ${a.G6} not found`);
                                b = b.tbb.find(c => c.jia === a.jia);
                                if (!b) throw Error(`Variant ${a.jia} not found for blueprint ${a.G6}`);
                                return {
                                    gb: b.gb
                                }
                            }
                        })
                    },
                    lBb = function(a, b) {
                        var c = jBb,
                            d = kBb;
                        a.handle("SET_CONFIG", async e => {
                            if (e === void 0) throw new e7({
                                code: "internal_error",
                                message: "SET_CONFIG: request cannot be undefined."
                            });
                            e = c.deserialize(e);
                            e = await b(e);
                            if (d) return d.serialize(e)
                        })
                    },
                    oBb = async function(a, b) {
                        a = await a.bna.request("RENDER_ELEMENT", mBb.serialize(b));
                        if (!a.ok) throw Error(`Encountered an error while sending ${"RENDER_ELEMENT"} request: ${a.error}`);
                        if (a.value == null) throw Error("RENDER_ELEMENT: Result cannot be empty");
                        return nBb.deserialize(a.value)
                    },
                    pBb = function(a) {
                        lBb(a.bna, b => a.handler.qNa(b))
                    },
                    rBb = async function(a, b) {
                        const c = b.requestId,
                            d = b.path;
                        b = b.payload;
                        const e = a.requestHandler.get(d);
                        if (e) {
                            a.uS.WO.send({
                                type: "ack",
                                requestId: c
                            });
                            var f = setInterval(() => a.uS.WO.send({
                                type: "ack",
                                requestId: c
                            }), 9E3);
                            try {
                                var g = await e(b);
                                clearInterval(f);
                                a.uS.WO.send({
                                    type: "response",
                                    requestId: c,
                                    payload: g
                                })
                            } catch (k) {
                                clearInterval(f);
                                g = "internal_error";
                                b = "Something went wrong on our end, if this issue persists please contact us.";
                                if (k instanceof e7) {
                                    var h = k;
                                    k.code === "internal_error" ? a.L.Gb(k, {
                                        Te: "Internal error in comms handler",
                                        tags: new Map([
                                            ["type", "request"],
                                            ["path", d]
                                        ])
                                    }) : (g = k.code, b = k.KTa)
                                } else a.eUa ? a.L.Gb(k, {
                                    Te: "Unexpected error type thrown from comms handler",
                                    tags: new Map([
                                        ["type", "request"],
                                        ["path", d]
                                    ])
                                }) : a.yJa.error(k);
                                g = qBb(a.uS, c, g, b);
                                g.ok || a.L.zP(g.error, {
                                    Te: "unable to send error response",
                                    tags: new Map([
                                        ["type", "request"],
                                        ["path", d]
                                    ])
                                })
                            }
                            if (h != null)
                                for (const k of a.MKa) try {
                                    k(h)
                                } catch (l) {
                                    a.L.jV(l, {
                                        Te: "Error executing errorObserver"
                                    })
                                }
                        } else h = qBb(a.uS, c, "internal_error", `No request handler configured for path: "${d}".`), h.ok || a.L.zP(h.error, {
                            Te: "unable to send error response",
                            tags: new Map([
                                ["type", "request"],
                                ["path", d]
                            ])
                        })
                    },
                    qBb = function(a, b, c, d) {
                        return a.WO.send({
                            type: "error",
                            requestId: b,
                            code: c,
                            message: d
                        })
                    },
                    tBb = function({
                        src: a,
                        srcdoc: b,
                        sandbox: c
                    }) {
                        if (b.length !== 0 || !c.contains("allow-same-origin")) return sBb;
                        a = (new URL(a)).origin;
                        return a === "null" ? sBb : {
                            fia: a,
                            dza: a
                        }
                    },
                    wBb = async function(a, b, c, {
                        addEventListener: d,
                        removeEventListener: e
                    } = window) {
                        const f = new uBb(6E4),
                            g = tBb(c),
                            h = c.contentWindow;
                        if (!h) throw new e7({
                            code: "internal_error",
                            message: "contentWindow is missing from iFrame"
                        });
                        c = ({
                            data: k,
                            source: l,
                            origin: m
                        }) => {
                            var n;
                            (k === null || k === void 0 ? 0 : (n = k.source) === null || n === void 0 ? 0 : n.startsWith("react-")) ||
                            (m !== g.fia ? vBb(m) || b.info("received message event from an unexpected origin", {
                                extra: new Map([
                                    ["expected", g.fia],
                                    ["actual", m]
                                ])
                            }) : l !== h ? l !== window && b.info("source and content window do not match", {
                                extra: new Map([
                                    ["data.source", k === null || k === void 0 ? void 0 : k.source]
                                ])
                            }) : (l = k ? k.source ? k.source !== "iframe" ? Ga("invalid source") : (0, __c.Fa)() : Ga("'source' is missing in MessageEvent data object") : Ga("missing 'data' field in MessageEvent"), l.ok ? (h.postMessage({
                                    source: "parent"
                                }, g.dza, [a]), f.resolve(void 0)) :
                                b.r4(l.error, {
                                    extra: new Map([
                                        ["data.source", k === null || k === void 0 ? void 0 : k.source]
                                    ])
                                })))
                        };
                        d("message", c);
                        try {
                            await f.promise()
                        } finally {
                            e("message", c)
                        }
                    },
                    vBb = function(a) {
                        return xBb.some(b => a.endsWith(b))
                    },
                    CBb = async function(a, b, c) {
                        const {
                            port1: d,
                            port2: e
                        } = new MessageChannel;
                        var f = new yBb(d, a.L);
                        await wBb(e, a.L, b, window);
                        const g = new zBb(f, {
                            qNa: h => {
                                f7(() => {
                                    const k = h.width,
                                        l = h.height;
                                    c.t$.Kf.set("config", {
                                        type: "string",
                                        value: h.config
                                    });
                                    ABb(c, {
                                        width: k,
                                        height: l
                                    })
                                });
                                return new kBb
                            }
                        });
                        f = BBb(() => c.t$.Kf.get("config"),
                            async h => {
                                let k;
                                h && (__c.A(h.type === "string"), k = h.value);
                                const {
                                    width: l,
                                    height: m
                                } = await oBb(g, {
                                    config: k
                                });
                                f7(() => {
                                    ABb(c, {
                                        width: l,
                                        height: m
                                    })
                                })
                            }, {
                                fireImmediately: !0
                            });
                        a.It.set(b, f)
                    },
                    ABb = function(a, b) {
                        const c = a.dKa,
                            d = a.t$,
                            e = b.width,
                            f = b.height;
                        if (!(e < 0 || f < 0)) {
                            var g = d.height,
                                h = e / f * g;
                            f7(() => {
                                c.width = h;
                                c.height = g;
                                c.N = e;
                                c.Y = f;
                                d.width = h;
                                d.N = h;
                                d.Y = g
                            })
                        }
                    },
                    FBb = function({
                        U8: a,
                        L: b
                    }) {
                        const c = new DBb(b);
                        a && (a.Zw = async (d, {
                            element: e,
                            container: f
                        }) => {
                            (f === null || f === void 0 ? void 0 : f.type) === "group-element" && __c.jj(f.group) &&
                                f.group.qe.app.id === "w:codelet" && (__c.A((e === null || e === void 0 ? void 0 : e.type) === "embed"), CBb(c, d, {
                                    dKa: e,
                                    t$: f.group
                                }))
                        }, a.dM = d => {
                            var e;
                            (e = c.It.get(d)) === null || e === void 0 || e();
                            c.It.delete(d)
                        });
                        return EBb
                    },
                    KBb = function() {
                        return new __c.B0({
                            id: "w:demo-form",
                            HF: GBb,
                            Component: HBb(({
                                data: a
                            }) => IBb(JBb, {
                                state: a
                            }))
                        })
                    };
                __c.wd.prototype.zP = __c.ca(3, function(a, b) {
                    this.console.error(...__c.Xc(this, "critical", a, b))
                });
                __c.xd.prototype.zP = __c.ca(2, function(a, b) {
                    __c.vd(this, "fatal", a, b)
                });
                var g7 = __webpack_require__(519427),
                    LBb = g7.ObservableMap,
                    BBb = g7.reaction,
                    f7 = g7.runInAction;
                var IBb = __webpack_require__(443763).jsx;
                var MBb = __webpack_require__(875604).memo;
                var HBb = __webpack_require__(446474).Pi;
                var hBb = new LBb,
                    gBb = {
                        G6: __c.A0("blueprintId", 0),
                        jia: __c.A0("variantId", 0)
                    };
                var e7 = class extends Error {
                    constructor(a) {
                        a.code = a.code;
                        const b = a.message.endsWith(".") ? "" : ".";
                        super(`[${a.code}]:  ${a.message}${b}`.trim());
                        this.code = a.code;
                        this.name = "CanvaError";
                        this.KTa = a.message;
                        Object.setPrototypeOf(this, e7.prototype)
                    }
                };
                var mBb = M(() => ({
                    config: __c.Z(1)
                }));
                var NBb = M(() => ({
                    color: X(1)
                }));
                var OBb = M(() => ({
                    type: __c.H("A?", 1, "RECOLORABLE"),
                    id: X(1),
                    value: __c.Pa(2, NBb)
                }));
                var PBb = M(() => ({
                    borderRadius: FO(1),
                    borderWidth: FO(2)
                }));
                var QBb = M(() => ({
                    type: __c.H("A?", 2, "BORDERABLE"),
                    id: X(1),
                    value: __c.Pa(2, PBb)
                }));
                var nBb = M(() => ({
                    config: X(1),
                    width: FO(2),
                    height: FO(3),
                    AM: __c.Qa(4, OBb),
                    VGa: __c.Qa(5, QBb)
                }));
                var jBb = M(() => ({
                    config: X(1),
                    width: FO(2),
                    height: FO(3),
                    AM: __c.Qa(4, OBb),
                    VGa: __c.Qa(5, QBb)
                }));
                var kBb = M(() => ({}));
                var zBb = class {
                    constructor(a, b) {
                        this.bna = a;
                        this.handler = b;
                        pBb(this)
                    }
                };
                var RBb = class {
                    constructor(a, b, c) {
                        this.handler = a;
                        this.port = b;
                        this.L = c;
                        this.send = d => {
                            try {
                                return this.port.postMessage(d), (0, __c.Fa)()
                            } catch (e) {
                                return this.L.Gb(e), Ga(e)
                            }
                        };
                        this.jSa = d => {
                            this.L.Gb(d)
                        };
                        this.iSa = ({
                            data: d
                        }) => {
                            if (d) try {
                                this.handler.receive(d)
                            } catch (e) {
                                this.L.Gb(e)
                            } else this.L.error(new e7({
                                code: "internal_error",
                                message: "missing data in 'MessageEvent'"
                            }))
                        };
                        this.port.onmessage = this.iSa;
                        this.port.onmessageerror = this.jSa
                    }
                };
                var h7 = new e7({
                        code: "internal_error",
                        message: "Comms promise timed out."
                    }),
                    uBb = class {
                        reset(a) {
                            a && (this.timeoutMs = a);
                            this.setTimeout()
                        }
                        resolve(a) {
                            clearTimeout(this.If);
                            this.iUa(a)
                        }
                        reject(a) {
                            clearTimeout(this.If);
                            this.Wxa(a)
                        }
                        promise() {
                            return this.p
                        }
                        setTimeout() {
                            clearTimeout(this.If);
                            this.If = setTimeout(() => {
                                this.Wxa(h7)
                            }, this.timeoutMs)
                        }
                        constructor(a) {
                            this.timeoutMs = a;
                            this.p = new Promise((b, c) => {
                                this.iUa = b;
                                this.Wxa = c
                            });
                            this.setTimeout()
                        }
                    };
                var SBb = class {
                    request(a, b) {
                        const c = this.Rwa,
                            d = new uBb(5E3),
                            e = this.fUa(),
                            f = async function() {
                                c.set(e, d);
                                try {
                                    const g = await d.promise();
                                    return (0, __c.Fa)(g)
                                } catch (g) {
                                    return g === h7 ? Ga(new e7({
                                        code: h7.code,
                                        message: `Comms promise timed out (${a}).`
                                    })) : Ga(g)
                                } finally {
                                    c.delete(e)
                                }
                            }();
                        b = this.send(e, a, b);
                        b.ok || (this.L.Gb(b.error, {
                            Te: "unable to send request",
                            tags: new Map([
                                ["type", "request"],
                                ["path", a]
                            ])
                        }), d.reject(b.error));
                        return f
                    }
                    constructor(a, b) {
                        this.send = a;
                        this.L = b;
                        this.fUa = __c.Yc;
                        this.Rwa = new Map
                    }
                };
                var TBb = class {
                    handle(a, b) {
                        if (this.requestHandler.has(a)) throw new e7({
                            code: "internal_error",
                            message: `Handler for '${a}' is already defined.`
                        });
                        this.requestHandler.set(a, b)
                    }
                    constructor(a, b) {
                        var c = console;
                        this.uS = a;
                        this.L = b;
                        this.eUa = !0;
                        this.yJa = c;
                        this.requestHandler = new Map;
                        this.MKa = new Set
                    }
                };
                var yBb = class {
                        constructor(a, b) {
                            this.request = (c, d) => this.client.request(c, d);
                            this.handle = (c, d) => this.requestHandler.handle(c, d);
                            a = new UBb(c => {
                                switch (c.type) {
                                    case "ack":
                                    case "error":
                                    case "response":
                                        var d = this.client;
                                        const e = c.requestId,
                                            f = c.type,
                                            g = d.Rwa.get(e);
                                        if (g) switch (f) {
                                            case "response":
                                                g.resolve(c.payload);
                                                break;
                                            case "ack":
                                                g.reset(2E4);
                                                break;
                                            case "error":
                                                g.reject(new e7({
                                                    code: c.code,
                                                    message: c.message
                                                }));
                                                break;
                                            default:
                                                throw new __c.E(c);
                                        } else f !== "ack" && d.L.error("request has already been handled and resolved or was not sent from this client", {
                                            tags: new Map([
                                                ["type", f],
                                                ["requestId", `${e}`]
                                            ])
                                        });
                                        break;
                                    case "request":
                                        rBb(this.requestHandler, c);
                                        break;
                                    default:
                                        throw new __c.E(c);
                                }
                            }, a, b.Vl("bus"));
                            this.client = new SBb(a.OA, b.Vl("client"));
                            this.requestHandler = new TBb(a, b.Vl("requestHandler"))
                        }
                    },
                    UBb = class {
                        constructor(a, b, c) {
                            this.vZ = a;
                            this.OA = (d, e, f) => this.WO.send({
                                type: "request",
                                requestId: d,
                                path: e,
                                payload: f
                            });
                            this.qSa = d => {
                                switch (d.type) {
                                    case "ack":
                                        this.vZ({
                                            type: "ack",
                                            requestId: d.requestId
                                        });
                                        break;
                                    case "error":
                                        this.vZ({
                                            type: "error",
                                            requestId: d.requestId,
                                            code: d.code,
                                            message: d.message
                                        });
                                        break;
                                    case "response":
                                        this.vZ({
                                            type: "response",
                                            requestId: d.requestId,
                                            payload: d.payload
                                        });
                                        break;
                                    case "request":
                                        this.vZ({
                                            type: "request",
                                            requestId: d.requestId,
                                            path: d.path,
                                            payload: d.payload
                                        });
                                        break;
                                    default:
                                        throw new __c.E(d);
                                }
                            };
                            this.WO = new RBb({
                                receive: this.qSa
                            }, b, c)
                        }
                    };
                var sBb = {
                    fia: "null",
                    dza: "*"
                };
                var xBb = "canva-dev.com canva-dev.cn canva-staging.com canva-staging.cn canva.com canva.cn canva-apps.com canva-apps.cn canva-apps-dev.com canva-apps-dev.cn canva-apps-staging.com canva-apps-staging.cn".split(" ");
                var DBb = class {
                    constructor(a) {
                        this.L = a;
                        this.It = new Map
                    }
                };
                var EBb = new __c.B0({
                    id: "w:codelet",
                    HF: {
                        url: __c.A0("url", 0),
                        config: __c.A0("config", 1)
                    },
                    At: ({
                        data: a
                    }) => ({
                        gb: __c.cS.create([{ ...__c.TPa,
                            top: 0,
                            left: 0,
                            width: 510,
                            height: 191.25,
                            N: 800,
                            Y: 300,
                            url: a.url
                        }])
                    })
                });
                var JBb = MBb(function() {
                    return IBb("div", {
                        style: {
                            width: "100%",
                            height: "100%",
                            display: "flex",
                            backgroundColor: "#fFfFfF",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: "FORM V2 Widget"
                    })
                });
                var GBb = {};
                __c.Wza = {
                    EOa: function({
                        lV: a,
                        U8: b,
                        L: c,
                        kKa: d
                    }) {
                        [FBb({
                            U8: b,
                            L: c
                        }), KBb(), iBb()].forEach(e => a.Wra(e));
                        d && __webpack_require__.me(345045).then(() => __c.fBb).then(({
                            rJa: e
                        }) => {
                            e.forEach(f => a.Wra(f))
                        })
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/92ecdd8efbf27346.js.map