(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [71981], {

        /***/
        536633: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(476834);
            self._5c0f058b2d917619b177d32cbc4c572b = self._5c0f058b2d917619b177d32cbc4c572b || {};
            (function(__c) {
                var Sh, Y, Th, Uh, Z;
                __c.Xb = async function(a) {
                    Y == null && await Sh();
                    var b = new ArrayBuffer(8),
                        c = new DataView(b);
                    c.setUint32(0, 0, !0);
                    c.setUint32(4, 0, !0);
                    Th.set(new Uint8Array(b));
                    Z.Pd(null);
                    for (b = 0; b < a.length;) c = a.subarray(b, b + 16384), b += c.length, Th.set(c), Z.Qd(c.length);
                    Z.Nd(null);
                    a = new Uint8Array(16);
                    b = Th;
                    c = 0;
                    for (let d = 0; d < 8; d++) {
                        let e = b[d] >>> 4;
                        a[c++] = e > 9 ? e + 87 : e + 48;
                        e = b[d] & 15;
                        a[c++] = e > 9 ? e + 87 : e + 48
                    }
                    return String.fromCharCode(...a)
                };
                Sh = async function() {
                    if (Uh) await Uh;
                    else {
                        var a;
                        Uh = new Promise(d => a = d);
                        if (typeof WebAssembly === "undefined") throw Error("WebAssembly isn't supported");
                        var b = new Uint8Array(atob("AGFzbQEAAAABDANgAAF/YAAAYAF/AAMHBgABAgEAAQUEAQECAgYOAn8BQdCJBQt/AEGACAsHcAgGbWVtb3J5AgAOSGFzaF9HZXRCdWZmZXIAAAlIYXNoX0luaXQAAQtIYXNoX1VwZGF0ZQACCkhhc2hfRmluYWwAAw1IYXNoX0dldFN0YXRlAAQOSGFzaF9DYWxjdWxhdGUABQpTVEFURV9TSVpFAwEK9A8GBQBBgAkLYwEBfkEAQgA3A8iJAUEAQQApA4AJIgA3A5CJAUEAIABC+erQ0OfJoeThAHw3A5iJAUEAIABCz9bTvtLHq9lCfDcDiIkBQQAgAELW64Lu6v2J9eAAfDcDgIkBQQBBADYCwIkBC70IAwV/BH4CfwJAIABFDQBBAEEAKQPIiQEgAK18NwPIiQECQEEAKALAiQEiASAAakEfSw0AAkACQCAAQQNxIgINAEGACSEDIAAhAQwBCyAAQXxxIQFBgAkhAwNAQQBBACgCwIkBIgRBAWo2AsCJASAEQaCJAWogAy0AADoAACADQQFqIQMgAkF/aiICDQALCyAAQQRJDQEDQEEAQQAoAsCJASICQQFqNgLAiQEgAkGgiQFqIAMtAAA6AAAgA0EBai0AACECQQBBACgCwIkBIgRBAWo2AsCJASAEQaCJAWogAjoAACADQQJqLQAAIQJBAEEAKALAiQEiBEEBajYCwIkBIARBoIkBaiACOgAAIANBA2otAAAhAkEAQQAoAsCJASIEQQFqNgLAiQEgBEGgiQFqIAI6AAAgA0EEaiEDIAFBfGoiAQ0ADAILCyAAQeAIaiEFAkACQCABDQBBACkDmIkBIQZBACkDkIkBIQdBACkDiIkBIQhBACkDgIkBIQlBgAkhAwwBC0GACSEDAkAgAUEfSw0AQYAJIQMCQAJAQQAgAWtBA3EiBA0AIAEhAgwBCyABIQIDQCACQaCJAWogAy0AADoAACACQQFqIQIgA0EBaiEDIARBf2oiBA0ACwsgAUFjakEDSQ0AQSAgAmshCkEAIQQDQCACIARqIgFBoIkBaiADIARqIgstAAA6AAAgAUGhiQFqIAtBAWotAAA6AAAgAUGiiQFqIAtBAmotAAA6AAAgAUGjiQFqIAtBA2otAAA6AAAgCiAEQQRqIgRHDQALIAMgBGohAwtBAEEAKQOgiQFCz9bTvtLHq9lCfkEAKQOAiQF8Qh+JQoeVr6+Ytt6bnn9+Igk3A4CJAUEAQQApA6iJAULP1tO+0ser2UJ+QQApA4iJAXxCH4lCh5Wvr5i23puef34iCDcDiIkBQQBBACkDsIkBQs/W077Sx6vZQn5BACkDkIkBfEIfiUKHla+vmLbem55/fiIHNwOQiQFBAEEAKQO4iQFCz9bTvtLHq9lCfkEAKQOYiQF8Qh+JQoeVr6+Ytt6bnn9+IgY3A5iJAQsgAEGACWohAgJAIAMgBUsNAANAIAMpAwBCz9bTvtLHq9lCfiAJfEIfiUKHla+vmLbem55/fiEJIANBGGopAwBCz9bTvtLHq9lCfiAGfEIfiUKHla+vmLbem55/fiEGIANBEGopAwBCz9bTvtLHq9lCfiAHfEIfiUKHla+vmLbem55/fiEHIANBCGopAwBCz9bTvtLHq9lCfiAIfEIfiUKHla+vmLbem55/fiEIIANBIGoiAyAFTQ0ACwtBACAGNwOYiQFBACAHNwOQiQFBACAINwOIiQFBACAJNwOAiQFBACACIANrNgLAiQEgAiADRg0AQQAhAgNAIAJBoIkBaiADIAJqLQAAOgAAIAJBAWoiAkEAKALAiQFJDQALCwu+BgIFfgV/AkACQEEAKQPIiQEiAEIgVA0AQQApA4iJASIBQgeJQQApA4CJASICQgGJfEEAKQOQiQEiA0IMiXxBACkDmIkBIgRCEol8IAJCz9bTvtLHq9lCfkIfiUKHla+vmLbem55/foVCh5Wvr5i23puef35C49zKlfzO8vWFf3wgAULP1tO+0ser2UJ+Qh+JQoeVr6+Ytt6bnn9+hUKHla+vmLbem55/fkLj3MqV/M7y9YV/fCADQs/W077Sx6vZQn5CH4lCh5Wvr5i23puef36FQoeVr6+Ytt6bnn9+QuPcypX8zvL1hX98IARCz9bTvtLHq9lCfkIfiUKHla+vmLbem55/foVCh5Wvr5i23puef35C49zKlfzO8vWFf3whAQwBC0EAKQOQiQFCxc/ZsvHluuonfCEBCyABIAB8IQBBoIkBIQUCQEEAKALAiQEiBkGgiQFqIgdBqIkBSQ0AQaCJASEIA0AgCCkDAELP1tO+0ser2UJ+Qh+JQoeVr6+Ytt6bnn9+IACFQhuJQoeVr6+Ytt6bnn9+QuPcypX8zvL1hX98IQAgCEEQaiEJIAhBCGoiBSEIIAkgB00NAAsLAkACQCAFQQRqIgkgB00NACAFIQkMAQsgBTUCAEKHla+vmLbem55/fiAAhUIXiULP1tO+0ser2UJ+Qvnz3fGZ9pmrFnwhAAsCQCAJIAdGDQAgBkGfiQFqIQUCQAJAIAYgCWtBAXENACAJIQgMAQsgCUEBaiEIIAkxAABCxc/ZsvHluuonfiAAhUILiUKHla+vmLbem55/fiEACyAFIAlGDQADQCAIQQFqMQAAQsXP2bLx5brqJ34gCDEAAELFz9my8eW66id+IACFQguJQoeVr6+Ytt6bnn9+hUILiUKHla+vmLbem55/fiEAIAhBAmoiCCAHRw0ACwtBACAAQiGIIACFQs/W077Sx6vZQn4iAEIdiCAAhUL5893xmfaZqxZ+IgBCIIggAIUiAUI4hiABQoD+A4NCKIaEIAFCgID8B4NCGIYgAUKAgID4D4NCCIaEhCAAQgiIQoCAgPgPgyAAQhiIQoCA/AeDhCAAQiiIQoD+A4MgAEI4iISEhDcDgAkLBgBBgIkBCwIACwsLAQBBgAgLBFAAAAA=").split("").map(d =>
                            d.charCodeAt(0)));
                        b = await WebAssembly.compile(b);
                        Y = await WebAssembly.instantiate(b);
                        Z = {
                            Nd: Y.exports.Hash_Final,
                            Od: Y.exports.Hash_GetBuffer,
                            Pd: Y.exports.Hash_Init,
                            Qd: Y.exports.Hash_Update,
                            memory: Y.exports.memory
                        };
                        var c = Z.Od;
                        b = Z.memory;
                        c = c();
                        Th = new Uint8Array(b.buffer, c, 16384);
                        a();
                        Uh = void 0
                    }
                };
            }).call(self, self._5c0f058b2d917619b177d32cbc4c572b);
        }

    }
])
//# sourceMappingURL=sourcemaps/3dfe69d4f9182d9c.js.map