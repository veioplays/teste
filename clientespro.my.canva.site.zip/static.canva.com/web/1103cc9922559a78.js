(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [76301], {

        /***/
        738083: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var YM = __c.YM;
                var yc = __c.yc;
                var P = __c.P;
                var Il = __c.Il;
                var CC = __c.CC;
                var O = __c.O;
                var jl = __c.jl;
                var B = __c.B;
                var E = __c.E;
                var V5 = function(a, b) {
                        switch (b.reference.type) {
                            case 0:
                                const c = a.iK(b.reference.Ig);
                                a = a.FM(b.reference.Og);
                                return c != null && a != null;
                            case 1:
                                return a.iK(b.reference.Ig) != null;
                            case 2:
                                return a.FM(b.reference.Og) != null;
                            case 3:
                                return !1;
                            default:
                                throw new E(b.reference);
                        }
                    },
                    iyb = function(a, b, c) {
                        switch (c.type) {
                            case "invalid":
                                return !1;
                            case "canonical":
                                if (c.S.length > 0) return !1;
                                a = a.pA(c.YO.slice(1).trim());
                                return a.result !== "success" ? !1 : __c.pI(new __c.tI, a.kC).filter(d => {
                                    switch (d.type) {
                                        case 0:
                                            return V5(b, d);
                                        case 1:
                                            return V5(b,
                                                d.start) && V5(b, d.end);
                                        default:
                                            throw new E(d);
                                    }
                                }).length > 0;
                            default:
                                throw new E(c);
                        }
                    },
                    jyb = function(a, b, c, d) {
                        const e = [];
                        for (const k of c)
                            for (const l of d) {
                                c = k.la;
                                var f = l.column,
                                    g = a.layout.cells.get(c, f);
                                if (!g || (k.boundary === "start" ? g.span.Fb === c : g.span.wc === c))
                                    if (c = b.get(`${f.id}:${c.id}`), c = k.boundary === "start" ? c === null || c === void 0 ? void 0 : c.va : c === null || c === void 0 ? void 0 : c.Ka) {
                                        g = e[e.length - 1];
                                        f = (f = a.layout.cols.next(f)) ? {
                                            column: f,
                                            boundary: "start"
                                        } : {
                                            column: B(a.layout.cols.last()),
                                            boundary: "end"
                                        };
                                        var h;
                                        if (h = g) h = g.e9, h = h.column === l.column && h.boundary === l.boundary;
                                        h && (h = g.Aya, h = h.la === k.la && h.boundary === k.boundary);
                                        h && g.color === c.color && g.weight === c.weight && g.Rb === c.Rb && g.Rb === 0 ? g.e9 = f : e.push({
                                            Aya: k,
                                            $Va: l,
                                            e9: f,
                                            color: c.color,
                                            weight: c.weight,
                                            Rb: c.Rb
                                        })
                                    }
                            }
                        return e
                    },
                    kyb = function(a, b, c, d, e) {
                        const f = [];
                        for (const l of d)
                            for (const m of c) {
                                var g = m.la,
                                    h = l.column;
                                d = a.layout.cells.get(g, h);
                                if (!d || (l.boundary === "start" ? d.span.Bb === h : d.span.$b === h))
                                    if (d = b.get(`${h.id}:${g.id}`), (d = l.boundary === "start" ? d === null ||
                                            d === void 0 ? void 0 : d.qa : d === null || d === void 0 ? void 0 : d.Ma) && (l.boundary !== "start" || e(g, h) !== 1)) {
                                        h = f[f.length - 1];
                                        g = (g = a.layout.rows.next(g)) ? {
                                            la: g,
                                            boundary: "start"
                                        } : {
                                            la: B(a.layout.rows.last()),
                                            boundary: "end"
                                        };
                                        var k;
                                        if (k = h) k = h.Rma, k = k.column === l.column && k.boundary === l.boundary;
                                        k && (k = h.i9, k = k.la === m.la && k.boundary === m.boundary);
                                        k && h.color === d.color && h.weight === d.weight && h.Rb === d.Rb && h.Rb === 0 ? h.i9 = g : f.push({
                                            Rma: l,
                                            jWa: m,
                                            i9: g,
                                            color: d.color,
                                            weight: d.weight,
                                            Rb: d.Rb
                                        })
                                    }
                            }
                        return f
                    },
                    lyb = function(a, b, c, d, e) {
                        const f =
                            a.Yza.tIa(c, b.layout.rows.last(), b.layout.cols.last());
                        a = (q, r) => {
                            const t = f.get(q) || 0,
                                v = f.get(r) || 0;
                            return t <= v ? q : r
                        };
                        const g = new Map;
                        if (d.length === 0 || e.length === 0) return g;
                        var h = [],
                            k = b.layout.cols.Qc(e[0].column);
                        k && h.push({
                            column: k,
                            boundary: "start"
                        });
                        h.push(...e);
                        (e = b.layout.cols.next(e[e.length - 1].column)) && h.push({
                            column: e,
                            boundary: "start"
                        });
                        e = [];
                        (k = b.layout.rows.Qc(d[0].la)) && e.push({
                            la: k,
                            boundary: "start"
                        });
                        e.push(...d);
                        (d = b.layout.rows.next(d[d.length - 1].la)) && e.push({
                            la: d,
                            boundary: "start"
                        });
                        for (const q of h) {
                            h = (d = q.boundary === "start" ? q.column : void 0) ? b.layout.cols.Qc(d) : b.layout.cols.last();
                            for (const r of e) {
                                var l = r.boundary === "start" ? r.la : void 0;
                                k = l ? b.layout.rows.Qc(l) : b.layout.rows.last();
                                var m = d && l && c.get(`${d.id}:${l.id}`),
                                    n = d && k && c.get(`${d.id}:${k.id}`);
                                l = h && l && c.get(`${h.id}:${l.id}`);
                                var p = h && k && c.get(`${h.id}:${k.id}`);
                                k = q.boundary === "end" ? l === null || l === void 0 ? void 0 : l.Ma : m === null || m === void 0 ? void 0 : m.qa;
                                m = r.boundary === "end" ? n === null || n === void 0 ? void 0 : n.Ka : m === null || m === void 0 ?
                                    void 0 : m.va;
                                n = q.boundary === "end" ? p === null || p === void 0 ? void 0 : p.Ma : n === null || n === void 0 ? void 0 : n.qa;
                                l = r.boundary === "end" ? p === null || p === void 0 ? void 0 : p.Ka : l === null || l === void 0 ? void 0 : l.va;
                                p = __c.bl({
                                    va: n,
                                    Ka: k,
                                    qa: l,
                                    Ma: m
                                }, a);
                                let t;
                                switch (p) {
                                    case "blockStart":
                                        t = n;
                                        break;
                                    case "blockEnd":
                                        t = k;
                                        break;
                                    case "inlineStart":
                                        t = l;
                                        break;
                                    case "inlineEnd":
                                        t = m;
                                        break;
                                    default:
                                        t = void 0
                                }
                                const {
                                    height: v,
                                    width: u
                                } = (t === null || t === void 0 ? void 0 : t.Rb) === 1 ? {
                                    height: t.weight,
                                    width: t.weight
                                } : {
                                    height: Math.max((l === null || l === void 0 ? void 0 :
                                        l.weight) || 0, (m === null || m === void 0 ? void 0 : m.weight) || 0),
                                    width: Math.max((n === null || n === void 0 ? void 0 : n.weight) || 0, (k === null || k === void 0 ? void 0 : k.weight) || 0)
                                };
                                g.set(W5(q, r), __c.Zk(p, v / 2, u / 2))
                            }
                        }
                        return g
                    },
                    myb = function(a, b, c, d, e, f) {
                        if (d.length === 0 || e.length === 0) return [];
                        const g = jyb(b, c, d, e);
                        f = kyb(b, c, d, e, f);
                        const h = lyb(a, b, c, d, e),
                            k = a.TMa(b),
                            l = a.tMa(b),
                            m = b.direction === "rtl";
                        a = g.map(n => {
                            var p, q, r = n.$Va,
                                t = n.e9,
                                v = n.Aya;
                            const u = n.color,
                                x = n.weight;
                            n = n.Rb;
                            const y = m ? -1 : 1,
                                z = (p = h.get(W5(r, v))) === null || p === void 0 ?
                                void 0 : p.Ma;
                            p = (q = h.get(W5(t, v))) === null || q === void 0 ? void 0 : q.qa;
                            if (z != null && p != null) {
                                q = B(k.get(v.la));
                                var C = B(l.get(r.column));
                                r = B(l.get(t.column));
                                v = v.boundary === "start" ? q.start : q.end;
                                q = C.start;
                                t = t.boundary === "start" ? r.start : r.end;
                                return {
                                    color: u,
                                    weight: x,
                                    Rb: n,
                                    p1: new jl(q + z * y, v),
                                    p2: new jl(t + p * y, v),
                                    ...__c.el((t - q) * y, n * x, z)
                                }
                            }
                        }).filter(__c.qb);
                        return [...f.map(n => {
                            var p, q, r = n.Rma,
                                t = n.jWa,
                                v = n.i9;
                            const u = n.color,
                                x = n.weight;
                            n = n.Rb;
                            const y = (p = h.get(W5(r, t))) === null || p === void 0 ? void 0 : p.Ka;
                            p = (q = h.get(W5(r,
                                v))) === null || q === void 0 ? void 0 : q.va;
                            if (y != null && p != null) {
                                q = B(l.get(r.column));
                                var z = B(k.get(t.la));
                                t = B(k.get(v.la));
                                r = r.boundary === "start" ? q.start : q.end;
                                q = z.start;
                                v = v.boundary === "start" ? t.start : t.end;
                                return {
                                    color: u,
                                    weight: x,
                                    Rb: n,
                                    p1: new jl(r, q + y),
                                    p2: new jl(r, v + p),
                                    ...__c.el(v - q, n * x, y)
                                }
                            }
                        }).filter(__c.qb), ...a]
                    },
                    nyb = function(a) {
                        const b = [];
                        a = a.filter(c => c.weight !== 0 && c.color != null);
                        a = __c.Id(a, c => c.weight);
                        a = Array.from(a.entries()).sort(([c], [d]) => c - d);
                        for (const [c, d] of a) {
                            a = __c.Id(d, e => `${e.zi}_${e.Ai}`);
                            for (const [, e] of a) {
                                const {
                                    Ai: f,
                                    zi: g
                                } = e[0];
                                a = __c.Id(e, h => h.color);
                                for (const [h, k] of a) b.push({
                                    weight: c,
                                    color: h,
                                    lines: k,
                                    zi: g,
                                    Ai: f
                                })
                            }
                        }
                        return b
                    },
                    oyb = function(a, b, c, d) {
                        var e = __c.C7a;
                        const f = b.get().flatMap(k => a.layout.rows.last() === k ? [{
                                la: k,
                                boundary: "start"
                            }, {
                                la: k,
                                boundary: "end"
                            }] : [{
                                la: k,
                                boundary: "start"
                            }]),
                            g = c.get().flatMap(k => a.layout.cols.last() === k ? [{
                                column: k,
                                boundary: "start"
                            }, {
                                column: k,
                                boundary: "end"
                            }] : [{
                                column: k,
                                boundary: "start"
                            }]),
                            h = new Map;
                        for (const k of b.get())
                            for (const l of c.get()) b = l && k ?
                                e.Yza.hUa(a, l, k) : void 0, b && h.set(`${l.id}:${k.id}`, b);
                        c = myb(e, a, h, f, g, d);
                        return nyb(c)
                    },
                    pyb = function(a) {
                        switch (a) {
                            case 2:
                                return O("ibdecg");
                            case 7:
                                return O("446quA");
                            case 5:
                                return O("j1fbqg");
                            case 1:
                                return O("O5i4AQ");
                            case 6:
                                return O("C0VHsg");
                            case 4:
                                return O("9ND0kg");
                            case -1:
                                return O("RWqnLA");
                            case 9:
                                return O("nQR/7w");
                            case -2:
                                return O("P23rtA");
                            case 3:
                                return O("+IXmVg");
                            default:
                                throw new E(a);
                        }
                    },
                    X5 = function() {
                        const [a] = (0, __c.Vb)(() => CC());
                        return a
                    },
                    qyb = function(a, b, c) {
                        const d = [a];
                        for (; a != null &&
                            a !== b;)(a = c.next(a)) && d.push(a);
                        return d
                    },
                    ryb = function(a) {
                        const b = a.direction === "rtl" ? -(0, __c.F7a)(a) / 2 : -(0, __c.D7a)(a) / 2,
                            c = -(0, __c.E7a)(a) / 2,
                            d = a.width + (0, __c.D7a)(a) / 2 + (0, __c.F7a)(a) / 2;
                        a = a.height + (0, __c.E7a)(a) / 2 + (0, __c.G7a)(a) / 2;
                        return Il({
                            top: 0,
                            left: 0,
                            width: d,
                            height: a,
                            rotation: 0
                        }).translate(b, c)
                    },
                    syb = function(a) {
                        return b => ({
                            type: "react",
                            node: (0, __c.N)(a, { ...b
                            })
                        })
                    },
                    vyb = function(a) {
                        var b;
                        const c = a.QA;
                        var d = a.content;
                        const e = a.context;
                        a = a.xm;
                        __c.A((d === null || d === void 0 ? void 0 : (b = d.lf) === null || b ===
                            void 0 ? void 0 : b.type) === "formula");
                        b = d.Fi;
                        const f = {
                            type: "dom",
                            render: h => h.innerText = ""
                        };
                        switch (b.type) {
                            case 9:
                                d = f;
                                break;
                            case 6:
                                var g;
                                d = (g = c.r5) === null || g === void 0 ? void 0 : g.call(c, {
                                    content: __c.re(__c.MKa, { ...__c.DPa,
                                        value: b.value
                                    }),
                                    context: e,
                                    xm: a
                                });
                                break;
                            case 1:
                            case 3:
                            case 4:
                            case 2:
                            case 7:
                            case 8:
                                d = tyb(c, e, d.Sv, d.Fi.type);
                                break;
                            case 0:
                                d = {
                                    type: "react",
                                    node: Y5(__c.aT, {
                                        label: pyb(b.error),
                                        children: Y5(__c.Dk, {
                                            width: "full",
                                            display: "flex",
                                            justifyContent: "center",
                                            children: Y5(uyb, {
                                                tone: "critical"
                                            })
                                        })
                                    })
                                };
                                break;
                            default:
                                throw new E(b);
                        }
                        return d !== null && d !== void 0 ? d : f
                    },
                    tyb = function(a, b, c, d) {
                        var e;
                        return (e = a.u5) === null || e === void 0 ? void 0 : e.call(a, {
                            context: b,
                            value: c,
                            valueType: d
                        })
                    },
                    yyb = function(a) {
                        const b = a.QA,
                            c = a.hg,
                            d = a.FWa,
                            e = a.ib;
                        b.u5 = f => __c.Twa({ ...f,
                            ib: e
                        });
                        b.bka = f => vyb({ ...f,
                            QA: b
                        });
                        b.r5 = syb(wyb({
                            hg: c,
                            tJ: void 0
                        }));
                        b.dka = xyb(d, e);
                        b.eka = syb(f => Y5(Z5, { ...f,
                            ib: e
                        }))
                    },
                    zyb = function({
                        label: a,
                        Hv: b,
                        width: c,
                        height: d,
                        scale: e,
                        Yma: f
                    }) {
                        return Y5("div", {
                            style: {
                                width: c,
                                height: d,
                                transform: `scale(${e})`
                            },
                            className: "bx74uQ",
                            children: $5(__c.Ak, {
                                className: a6("ivlMMQ", b6(f)),
                                size: "small",
                                alignment: "center",
                                children: [b && Y5(b, {
                                    size: "small"
                                }), a]
                            })
                        })
                    },
                    b6 = function(a) {
                        return {
                            _2BX0vg: a === "primary-default",
                            JfW_Cg: a === "primary-low",
                            isMgNg: a === "primary-active",
                            xwWDeQ: a === "secondary-default",
                            w0EyUQ: a === "secondary-low",
                            _8p5AIA: a === "secondary-active"
                        }
                    },
                    Byb = function({
                        kj: a,
                        tra: b,
                        scale: c,
                        $l: d,
                        dm: e,
                        yDa: f
                    }) {
                        const g = c6(() => {
                                const m = d === null || d === void 0 ? void 0 : d.get();
                                if (m != null && m.length !== 0) return new __c.bJ(m)
                            }, [d]),
                            h = e(1),
                            k = e(c),
                            l = {
                                ssE9Tg: !a,
                                OkifGQ: a
                            };
                        return Y5(__c.Bk, {
                            xn: "light",
                            light: "light",
                            Sp: "light",
                            dark: "light",
                            children: m => Y5("div", {
                                className: a6("ze9QCQ", l, m.className),
                                style: {
                                    width: k,
                                    height: k
                                },
                                children: Y5("div", {
                                    style: {
                                        width: h,
                                        height: h,
                                        transform: `scale(${c})`
                                    },
                                    className: a6("N7J3UA", l),
                                    ref: g === null || g === void 0 ? void 0 : g.up,
                                    children: Y5(__c.eT, {
                                        className: a6("m8CFdg", l, {
                                            G6wL4w: f,
                                            W_E0wA: b
                                        }),
                                        ariaLabel: O("ruWN9A"),
                                        children: Y5(Ayb, {
                                            size: "tiny"
                                        })
                                    })
                                })
                            })
                        })
                    },
                    Dyb = function() {
                        const a = new Cyb,
                            b = new __c.nU,
                            c = d6(f => {
                                const {
                                    scale: g = 1,
                                    pra: h,
                                    size: k =
                                        "small",
                                    yDa: l = !0
                                } = f, m = e6(n => a.dm({
                                    scale: n,
                                    size: k,
                                    wba: h
                                }), [k, h]);
                                return Y5(Byb, { ...f,
                                    scale: h ? Math.max(g, h) : g,
                                    kj: f.sheet.direction === "rtl",
                                    tra: f.selection != null && a.pPa(f.sheet, f.selection),
                                    dm: m,
                                    yDa: l
                                })
                            }),
                            d = d6(f => {
                                const {
                                    scale: g = 1,
                                    pra: h,
                                    size: k = "small",
                                    sheet: l,
                                    selection: m,
                                    IUa: n
                                } = f, p = e6(u => a.dm({
                                    scale: u,
                                    size: k,
                                    wba: h
                                }), [k, h]), q = h ? Math.max(g, h) : g, r = e6(u => m != null && a.dea(m).has(u), [m]), t = e6(u => m != null && a.CNa(l, m).has(u), [l, m]), v = e6(u => {
                                    const x = n != null && l.layout.cols.Qd(u, n.Bb) >= 0 && l.layout.cols.Qd(u, n.$b) <=
                                        0;
                                    return r(u) ? x ? "secondary-active" : "primary-active" : t(u) ? x ? "secondary-low" : "primary-low" : x ? "secondary-default" : "primary-default"
                                }, [l, n, t, r]);
                                return Y5(f6, { ...f,
                                    Kd: g,
                                    le: q,
                                    dm: p,
                                    nz: v,
                                    aA: b
                                })
                            }),
                            e = d6(f => {
                                const {
                                    scale: g = 1,
                                    pra: h,
                                    size: k = "small",
                                    sheet: l,
                                    selection: m,
                                    IUa: n
                                } = f, p = e6(u => a.dm({
                                    scale: u,
                                    size: k,
                                    wba: h
                                }), [k, h]), q = h ? Math.max(g, h) : g, r = e6(u => m != null && a.fea(m).has(u), [m]), t = e6(u => m != null && a.DNa(l, m).has(u), [l, m]), v = e6(u => {
                                    const x = n != null && l.layout.rows.Qd(u, n.Fb) >= 0 && l.layout.rows.Qd(u, n.wc) <= 0;
                                    return r(u) ?
                                        x ? "secondary-active" : "primary-active" : t(u) ? x ? "secondary-low" : "primary-low" : x ? "secondary-default" : "primary-default"
                                }, [l, n, t, r]);
                                return Y5(g6, { ...f,
                                    Kd: q,
                                    le: g,
                                    dm: p,
                                    nz: v,
                                    aA: b
                                })
                            });
                        return {
                            TDa: c,
                            SDa: d,
                            UDa: e
                        }
                    },
                    Eyb = function(a) {
                        const b = a.Wm,
                            c = () => null;
                        return __c.PC(d => Y5(h6, { ...d,
                            Wm: b,
                            gg: c
                        }))
                    },
                    Fyb = function({
                        sheet: a,
                        O: b,
                        range: c,
                        xi: d
                    }) {
                        i6(() => j6(() => {
                            if (d.current != null) {
                                var e, f = (e = b === null || b === void 0 ? void 0 : b.get()) !== null && e !== void 0 ? e : 1;
                                e = a.direction === "rtl";
                                e = c ? a.qa(c.Bb) * f * (e ? 1 : -1) : 0;
                                var g = c ? -a.va(c.Fb) *
                                    f : 0;
                                d.current.style.transform = `translate(${e}px, ${g}px)`;
                                d.current.style.width = `${a.width*f}px`;
                                d.current.style.height = `${a.height*f}px`
                            }
                        }), [a, c, d, b])
                    },
                    Iyb = function({
                        onScroll: a
                    }) {
                        const b = new Gyb(a);
                        return {
                            xx: b,
                            f5: d6(c => Y5(Hyb, {
                                sheet: c.sheet,
                                xx: b,
                                children: c.children
                            }))
                        }
                    },
                    Lyb = function(a) {
                        const b = a.Wm,
                            c = a.Cf,
                            d = a.Zza,
                            e = ({
                                children: k
                            }) => k,
                            {
                                xx: f,
                                f5: g
                            } = Iyb({
                                onScroll: a.onScroll
                            });
                        class h extends Jyb {
                            get RE() {
                                const k = this.props.aa.Ft;
                                switch (k) {
                                    case "screen":
                                        return g;
                                    case "print":
                                        return e;
                                    default:
                                        throw new E(k);
                                }
                            }
                            componentDidMount() {
                                d.Mza(this.props.item, {
                                    Cb: this.props.Cb,
                                    aa: this.props.aa
                                })
                            }
                            componentWillUnmount() {
                                d.AHa(this.props.item, {
                                    Cb: this.props.Cb,
                                    aa: this.props.aa
                                })
                            }
                            render() {
                                d.Mza(this.props.item, {
                                    Cb: this.props.Cb,
                                    aa: this.props.aa
                                });
                                return Y5(Kyb, { ...this.props,
                                    O: this.O,
                                    Wm: b,
                                    RE: this.RE,
                                    gg: this.gg,
                                    Zza: d,
                                    xx: f
                                })
                            }
                            constructor(...k) {
                                super(...k);
                                this.O = k6(() => {
                                    const l = this.props.item;
                                    var m = this.props.aa,
                                        n = m.Ft;
                                    m = m.zoom;
                                    switch (n) {
                                        case "screen":
                                            return m;
                                        case "print":
                                            n = d.YMa(l);
                                            if (!n) return 1;
                                            ({
                                                width: n
                                            } = new __c.xm(l,
                                                n.Cb, {
                                                    zoom: m
                                                }));
                                            return n / l.config.width;
                                        default:
                                            throw new E(n);
                                    }
                                });
                                this.gg = d6(l => Y5("div", {
                                    className: "wKvivQ",
                                    children: Y5(__c.axa, { ...this.props,
                                        ...l,
                                        Cf: c
                                    })
                                }))
                            }
                        }
                        return {
                            TEa: h,
                            xx: f
                        }
                    },
                    Myb = function(a, b) {
                        if (b != null && b.Bb != null && b.Fb != null && b.$b != null && b.wc != null) {
                            var c = a.qa(b.Bb),
                                d = a.va(b.Fb),
                                e = a.qa(b.$b) + b.$b.width - c;
                            a = a.va(b.wc) + b.wc.height - d;
                            return Il({
                                top: d,
                                left: c,
                                width: e,
                                height: a
                            })
                        }
                    },
                    Oyb = function(a) {
                        const b = a.Wm,
                            c = () => null;
                        return d => Y5(Nyb, { ...d,
                            Wm: b,
                            gg: c
                        })
                    },
                    Syb = function(a) {
                        const b = {
                                transform: "translate(-1000px, -1000px) scale(0)"
                            },
                            c = {
                                uma: b,
                                Er: b,
                                Ia: {},
                                Qk: {}
                            },
                            d = l6(() => a.Zu.style || c, h => {
                                var k;
                                Object.assign(a.QW.style, h.uma);
                                Object.assign(a.gF.style, h.Er);
                                Object.assign(a.Iy.style, h.Ia);
                                Object.assign(a.Oy.style, h.Qk);
                                h = h === null || h === void 0 ? void 0 : (k = h.Ia) === null || k === void 0 ? void 0 : k.textDecoration;
                                a.Iy.classList.toggle("OQx3PQ", h === "underline");
                                a.Iy.classList.toggle("_99ezUA", h === "line-through");
                                a.Iy.classList.toggle("kppAqQ", h === "underline line-through")
                            }, {
                                fireImmediately: !0,
                                equals: Pyb
                            }),
                            e = l6(() => a.Eaa, h => {
                                a.Iy.classList.toggle("_84KvRA", !h);
                                a.QW.classList.toggle("_84KvRA", !h);
                                a.gF.classList.toggle("TL_RLA", !h)
                            }, {
                                fireImmediately: !0
                            }),
                            f = l6(() => a.renderer, h => {
                                a.rX && (h === null || h === void 0 ? void 0 : h.type) !== "react" ? (a.rX = void 0, a.iT.remove()) : a.Oy.innerHTML = "";
                                switch (h === null || h === void 0 ? void 0 : h.type) {
                                    case "react":
                                        a.rX = Qyb(h.node, a.iT);
                                        a.Oy.appendChild(a.iT);
                                        break;
                                    case "dom":
                                        h.render(a.Oy);
                                        break;
                                    case void 0:
                                        break;
                                    default:
                                        throw new E(h);
                                }
                                a.Xba()
                            }, {
                                fireImmediately: !0
                            }),
                            g = Ryb ? l6(() => a.A$, h => {
                                a.Iy.classList.toggle("qxD1GA", h)
                            }, {
                                fireImmediately: !0
                            }) :
                            void 0;
                        return () => {
                            d();
                            e();
                            f();
                            g === null || g === void 0 || g()
                        }
                    },
                    Pyb = function(a, b) {
                        return JSON.stringify(a) === JSON.stringify(b)
                    },
                    Uyb = function(a) {
                        const b = a.Uu,
                            c = a.Dx,
                            d = a.Ux,
                            e = a.VCa,
                            f = a.Uo,
                            g = new Tyb(c),
                            h = (k, l) => f ? iyb(f, k, l) : !1;
                        return k => Y5(m6, { ...k,
                            WG: h,
                            Ux: d,
                            Dx: c,
                            Uu: b,
                            laa: g,
                            VCa: e === null || e === void 0 ? void 0 : e.get()
                        })
                    },
                    W5 = (a, b) => `${a.column.id}-${a.boundary}:${b.la.id}-${b.boundary}`,
                    wyb = ({
                        hg: a,
                        tJ: b
                    }) => c => (0, __c.N)(__c.I7a, { ...c,
                        hg: a,
                        tJ: b
                    }),
                    n6 = __webpack_require__(443763),
                    Vyb = n6.Fragment,
                    Y5 = n6.jsx,
                    $5 = n6.jsxs;
                var Wyb = __webpack_require__(358579).Z;
                var Xyb = __webpack_require__,
                    Yyb = Xyb(993864),
                    a6 = Xyb.n_x(Yyb)();
                var d6 = __webpack_require__(446474).Pi;
                var o6 = __webpack_require__(875604),
                    p6 = o6.Component,
                    Jyb = o6.PureComponent,
                    e6 = o6.useCallback,
                    i6 = o6.useEffect,
                    Zyb = o6.useLayoutEffect,
                    c6 = o6.useMemo,
                    q6 = o6.useRef,
                    $yb = o6.useState;
                var r6 = __webpack_require__(635872),
                    s6 = r6.Om,
                    azb = r6.kq,
                    bzb = r6.YN;
                var t6 = __webpack_require__(519427),
                    u6 = t6.action,
                    j6 = t6.autorun,
                    v6 = t6.comparer,
                    k6 = t6.computed,
                    czb = t6.createAtom,
                    w6 = t6.observable,
                    l6 = t6.reaction,
                    dzb = t6.untracked;
                var x6 = __webpack_require__(46239).gn;
                var Qyb = __webpack_require__(36281).createPortal;
                var ezb = d6(a => {
                        var b, c, d = a.sheet.direction === "rtl";
                        d = {
                            H2wykw: !d,
                            UweldA: d
                        };
                        const [e] = $yb(() => CC()), f = {
                            get: e6(() => {
                                var g;
                                const h = e === null || e === void 0 ? void 0 : (g = e.current) === null || g === void 0 ? void 0 : g.getBoundingClientRect();
                                var k, l;
                                g = {
                                    top: 0,
                                    left: 0,
                                    width: (k = h === null || h === void 0 ? void 0 : h.width) !== null && k !== void 0 ? k : 0,
                                    height: (l = h === null || h === void 0 ? void 0 : h.height) !== null && l !== void 0 ? l : 0
                                };
                                return Il(g)
                            }, [e])
                        };
                        return $5("div", {
                            className: a6("nMvVqA", d),
                            children: [$5("div", {
                                ref: Wyb(a.xi, e),
                                className: "_0YOFPg",
                                children: [Y5(a.Wm, { ...a,
                                    viewport: f
                                }), Y5("div", {
                                    className: a6("Gdl7fQ", d),
                                    children: (c = a.Dja) === null || c === void 0 ? void 0 : (b = c.get()) === null || b === void 0 ? void 0 : b.map((g, h) => Y5(g, {}, h))
                                })]
                            }), a.f6a === "visible" && $5(Vyb, {
                                children: [Y5("div", {
                                    className: a6("_32sKQw", d),
                                    children: Y5(a.QEa, { ...a
                                    })
                                }), Y5("div", {
                                    className: a6("xdIsTQ", d),
                                    children: Y5(a.UEa, { ...a
                                    })
                                }), Y5("div", {
                                    className: a6("rsTRSA", d),
                                    children: Y5(a.SEa, { ...a
                                    })
                                })]
                            })]
                        })
                    }),
                    fzb = d6(a => {
                        a = a.content;
                        __c.w(a.type === "text2" || a.type === "text3");
                        switch (a.type) {
                            case "text2":
                                return a.value.T;
                            case "text3":
                                return __c.bv.ua(a.value).cells.T();
                            default:
                                throw new E(a);
                        }
                    });
                var gzb = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.996 19.995a8 8 0 1 0 0-16 8 8 0 0 0 0 16ZM13.762 9.17a.75.75 0 0 1 1.06 1.06l-1.766 1.766 1.766 1.767a.75.75 0 0 1-1.06 1.06l-1.766-1.766-1.767 1.766a.75.75 0 0 1-1.06-1.06l1.766-1.767L9.17 10.23a.75.75 0 0 1 1.06-1.06l1.767 1.766 1.766-1.766Z" fill="currentColor"/></svg>';
                var uyb = __c.RS({
                    medium: gzb
                });
                var xyb = (a, b) => __c.Fwa((c, d) => {
                        const e = c.content;
                        c = c.context;
                        if (e.value.isEmpty)
                            for (; d.lastChild;) d.lastChild.remove();
                        else({
                            Of: c
                        } = __c.qg(__c.Xg, c.attrs)), c === "wrap" && (d = d.appendChild(document.createElement("div")), d.className = "dt4Dlg"), a.render({
                            container: d,
                            text: e.value,
                            La: void 0,
                            writingMode: 1,
                            Uc: "start",
                            Bf: hzb(e, c),
                            ib: b
                        })
                    }),
                    hzb = s6((a, b) => {
                        if (b === "wrap") return [];
                        a = a.value.T.split("\n").map(c => c.length + 1);
                        a.pop();
                        return a
                    }, {
                        equals: v6.structural
                    });
                var Z5 = class extends p6 {
                    static A(a) {
                        P(a, {
                            Of: k6
                        })
                    }
                    get Of() {
                        return __c.qg(__c.Xg, this.props.context.attrs).Of
                    }
                    render() {
                        var a = this.props.content;
                        const b = this.props.context;
                        if (a.value.isEmpty) return null;
                        a = Y5(this.props.gg, {
                            content: a,
                            la: b.container.la,
                            col: b.container.column,
                            Of: this.Of
                        });
                        return this.Of === "wrap" ? Y5("div", {
                            className: "dt4Dlg",
                            children: a
                        }) : a
                    }
                    constructor(...a) {
                        super(...a);
                        Z5.A(this)
                    }
                };
                Z5 = x6([yc], Z5);
                var izb = __c.Ek * 5,
                    jzb = __c.Ek * 4;
                var Cyb = class {
                    dm({
                        size: a,
                        scale: b,
                        wba: c
                    }) {
                        b = c ? Math.max(c, b) : b;
                        return a === "large" ? izb * b : jzb * b
                    }
                    constructor() {
                        this.pPa = s6((a, b) => {
                            var c, d;
                            b = b.get();
                            return b != null && a.layout.rows.count() === (((c = b.rows) === null || c === void 0 ? void 0 : c.size) || 0) && a.layout.cols.count() === (((d = b.columns) === null || d === void 0 ? void 0 : d.size) || 0)
                        });
                        this.dea = azb(a => {
                            var b;
                            return new Set(((b = a.get()) === null || b === void 0 ? void 0 : b.columns) || [])
                        }, {
                            equals: __c.Rk
                        });
                        this.fea = azb(a => {
                            var b;
                            return new Set(((b = a.get()) === null || b === void 0 ? void 0 :
                                b.rows) || [])
                        }, {
                            equals: __c.Rk
                        });
                        this.CNa = s6((a, b) => {
                            var {
                                cells: c
                            } = b.get() || {};
                            if (!c) return new Set;
                            if (this.fea(b).size > 0) return new Set(a.layout.cols);
                            b = this.dea(b);
                            const d = new Set;
                            for (const e of c) {
                                c = a.layout.cells.get(e.la, e.column);
                                for (const f of qyb(c ? c.span.Bb : e.column, c ? c.span.$b : e.column, a.layout.cols))(b.size === 0 || b.has(f)) && d.add(f)
                            }
                            return d
                        }, {
                            equals: __c.Rk
                        });
                        this.DNa = s6((a, b) => {
                            var {
                                cells: c
                            } = b.get() || {};
                            if (!c) return new Set;
                            if (this.dea(b).size > 0) return new Set(a.layout.rows);
                            b = this.fea(b);
                            const d = new Set;
                            for (const e of c) {
                                c = a.layout.cells.get(e.la, e.column);
                                for (const f of qyb(c ? c.span.Fb : e.la, c ? c.span.wc : e.la, a.layout.rows))(b.size === 0 || b.has(f)) && d.add(f)
                            }
                            return d
                        }, {
                            equals: __c.Rk
                        })
                    }
                };
                var kzb = parseInt("4px", 10) || 4,
                    f6 = class extends p6 {
                        static A(a) {
                            P(a, {
                                kj: k6,
                                St: k6,
                                jU: k6
                            })
                        }
                        get kj() {
                            return this.props.sheet.direction === "rtl"
                        }
                        get St() {
                            var a;
                            const b = (a = this.props.$l) === null || a === void 0 ? void 0 : a.get();
                            if (b != null && b.length !== 0) return new __c.bJ(b)
                        }
                        get jU() {
                            var a, b, c;
                            return (b = (c = this.props).e$) === null || b === void 0 ? void 0 : (a = b.call(c)) === null || a === void 0 ? void 0 : a.get()
                        }
                        render() {
                            return Y5(__c.Bk, {
                                xn: "light",
                                light: "light",
                                Sp: "light",
                                dark: "light",
                                children: this.MHa
                            })
                        }
                        constructor(...a) {
                            super(...a);
                            this.onMouseMove = (f6.A(this), u6(b => {
                                const {
                                    onMouseMove: c,
                                    sheet: d,
                                    Kd: e = 1
                                } = this.props;
                                c === null || c === void 0 || c(b, d, "column", e)
                            }));
                            this.onMouseLeave = u6(b => {
                                var c, d;
                                (c = (d = this.props).onMouseLeave) === null || c === void 0 || c.call(d, b)
                            });
                            this.Zxa = (b, c, d) => {
                                const {
                                    sheet: e,
                                    dm: f,
                                    nz: g,
                                    o6a: h,
                                    Kd: k = 1,
                                    le: l = 1
                                } = this.props, m = {
                                    jNbTIg: !this.kj,
                                    gtA7Dw: this.kj
                                }, n = (d === null || d === void 0 ? 0 : d.sticky) ? this.kj ? {
                                    right: 0
                                } : {
                                    left: 0
                                } : void 0;
                                var p;
                                const q = (d === null || d === void 0 ? 0 : d.sticky) ? (p = this.jU) !== null && p !== void 0 ? p : n : void 0;
                                let r = -1;
                                return $5("div", {
                                    style: q,
                                    className: a6("Vt2_4w", m, {
                                        Tn3nUw: d === null || d === void 0 ? void 0 : d.sticky
                                    }),
                                    onMouseMove: this.onMouseMove,
                                    onMouseLeave: this.onMouseLeave,
                                    children: [e.layout.cols.map(t => {
                                        var v;
                                        r++;
                                        if (!(b && e.layout.cols.Qd(t, b) < 0 || c && e.layout.cols.Qd(t, c) > 0)) return Y5(lzb, {
                                            col: t,
                                            label: __c.XB(r),
                                            Hv: h === null || h === void 0 ? void 0 : (v = h.get()) === null || v === void 0 ? void 0 : v.get(t),
                                            dm: f,
                                            nz: g,
                                            Kd: k,
                                            le: l
                                        }, t.id)
                                    }), (d === null || d === void 0 ? void 0 : d.sticky) && Y5("div", {
                                        style: {
                                            width: kzb * k
                                        },
                                        className: a6("HBvlug", "ru3tFQ",
                                            m)
                                    })]
                                })
                            };
                            this.MHa = b => {
                                var c;
                                const d = this.props.sheet,
                                    e = d.view.freeze.ZB ? d.layout.qd.get(d.view.freeze.ZB) : void 0,
                                    f = {
                                        jNbTIg: !this.kj,
                                        gtA7Dw: this.kj
                                    };
                                return $5("div", {
                                    ref: (c = this.St) === null || c === void 0 ? void 0 : c.up,
                                    className: a6("xhBZaw", f, b.className),
                                    children: [e && this.Zxa(void 0, e, {
                                        sticky: !0
                                    }), this.Zxa(e ? d.cols.next(e) : void 0)]
                                })
                            }
                        }
                    };
                f6 = x6([yc], f6);
                var g6 = class extends p6 {
                    static A(a) {
                        P(a, {
                            kj: k6,
                            St: k6,
                            jU: k6
                        })
                    }
                    get kj() {
                        return this.props.sheet.direction === "rtl"
                    }
                    get St() {
                        var a;
                        const b = (a = this.props.$l) === null || a === void 0 ? void 0 : a.get();
                        if (b != null && b.length !== 0) return new __c.bJ(b)
                    }
                    get jU() {
                        var a, b, c;
                        return (b = (c = this.props).e$) === null || b === void 0 ? void 0 : (a = b.call(c)) === null || a === void 0 ? void 0 : a.get()
                    }
                    render() {
                        return Y5(__c.Bk, {
                            xn: "light",
                            light: "light",
                            Sp: "light",
                            dark: "light",
                            children: this.xUa
                        })
                    }
                    constructor(...a) {
                        super(...a);
                        this.onMouseMove = (g6.A(this),
                            u6(b => {
                                const {
                                    onMouseMove: c,
                                    sheet: d,
                                    le: e = 1
                                } = this.props;
                                c === null || c === void 0 || c(b, d, "row", e)
                            }));
                        this.onMouseLeave = u6(b => {
                            var c, d;
                            (c = (d = this.props).onMouseLeave) === null || c === void 0 || c.call(d, b)
                        });
                        this.bya = (b, c, d) => {
                            const {
                                sheet: e,
                                dm: f,
                                nz: g,
                                Kd: h = 1,
                                le: k = 1
                            } = this.props, l = {
                                jNbTIg: !this.kj,
                                gtA7Dw: this.kj
                            }, m = (d === null || d === void 0 ? 0 : d.sticky) ? {
                                top: 0
                            } : void 0;
                            var n;
                            const p = (d === null || d === void 0 ? 0 : d.sticky) ? (n = this.jU) !== null && n !== void 0 ? n : m : void 0;
                            let q = -1;
                            return $5("div", {
                                style: p,
                                className: a6("_93roJg", l, {
                                    Tn3nUw: d ===
                                        null || d === void 0 ? void 0 : d.sticky
                                }),
                                onMouseMove: this.onMouseMove,
                                onMouseLeave: this.onMouseLeave,
                                children: [e.rows.map(r => {
                                    q++;
                                    if (!(b && e.rows.Qd(r, b) < 0 || c && e.rows.Qd(r, c) > 0)) return Y5(mzb, {
                                        la: r,
                                        label: `${q+1}`,
                                        nz: g,
                                        dm: f,
                                        Kd: h,
                                        le: k
                                    }, r.id)
                                }), (d === null || d === void 0 ? void 0 : d.sticky) && Y5("div", {
                                    style: {
                                        height: kzb * k
                                    },
                                    className: a6("HBvlug", "koz2Hg")
                                })]
                            })
                        };
                        this.xUa = b => {
                            var c;
                            const d = this.props.sheet,
                                e = d.view.freeze.GM ? d.layout.Ed.get(d.view.freeze.GM) : void 0,
                                f = {
                                    jNbTIg: !this.kj,
                                    gtA7Dw: this.kj
                                };
                            return $5("div", {
                                ref: (c =
                                    this.St) === null || c === void 0 ? void 0 : c.up,
                                className: a6("An9VeA", f, b.className),
                                children: [e && this.bya(void 0, e, {
                                    sticky: !0
                                }), this.bya(e ? d.rows.next(e) : void 0)]
                            })
                        }
                    }
                };
                g6 = x6([yc], g6);
                var lzb = d6(a => {
                        const b = a.label,
                            c = a.Hv,
                            d = a.col,
                            e = a.nz,
                            f = a.dm,
                            g = a.Kd;
                        a = a.le;
                        const h = f(a),
                            k = bzb(() => e(d));
                        return Y5("div", {
                            className: a6("_83Rssw", "d2uLIA", b6(k)),
                            style: {
                                width: d.width * g,
                                height: h
                            },
                            children: Y5(zyb, {
                                label: b,
                                Hv: c,
                                width: d.width,
                                height: f(1),
                                scale: a,
                                Yma: k
                            })
                        })
                    }),
                    mzb = d6(a => {
                        const b = a.label,
                            c = a.la,
                            d = a.dm,
                            e = a.nz,
                            f = a.Kd;
                        a = a.le;
                        const g = d(f),
                            h = bzb(() => e(c));
                        return Y5("div", {
                            className: a6("_83Rssw", "JhBzyw", b6(h)),
                            style: {
                                width: g,
                                height: c.height * a
                            },
                            children: Y5(zyb, {
                                label: b,
                                width: d(1),
                                height: c.height,
                                scale: f,
                                Yma: h
                            })
                        })
                    });
                var nzb = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><circle stroke="currentColor" cx="6" cy="6" r="5.5"/></svg>';
                var ozb = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle stroke="currentColor" cx="12" cy="12" r="9.25" stroke-width="1.5"/></svg>';
                var Ayb = __c.RS({
                    Xq: nzb,
                    medium: ozb
                });
                var h6 = class extends p6 {
                    static A(a) {
                        P(a, {
                            Ad: k6.struct
                        })
                    }
                    render() {
                        const a = this.props.element;
                        return Y5(this.props.Wm, {
                            sheet: a.W.config,
                            container: a,
                            zW: "visible",
                            $l: this.props.$l,
                            lq: this.props.lq,
                            mq: this.props.mq,
                            O: this.props.O,
                            Ad: this.Ad,
                            gg: this.props.gg,
                            CB: void 0
                        })
                    }
                    get Ad() {
                        return __c.iC(this.props.element.W.Oa, this.props.Md)
                    }
                    constructor(...a) {
                        super(...a);
                        h6.A(this)
                    }
                };
                h6 = x6([yc], h6);
                var pzb = class {
                    constructor() {
                        this.f2 = new WeakMap;
                        this.YMa = a => this.f2.get(a);
                        this.Mza = (a, b) => {
                            this.f2.set(a, b)
                        };
                        this.AHa = (a, b) => {
                            const c = this.f2.get(a);
                            c && c.aa === b.aa && c.Cb === b.Cb && this.f2.delete(a)
                        }
                    }
                };
                var y6 = parseInt("4px", 10) || 4,
                    qzb = d6(({
                        sheet: a,
                        O: b,
                        range: c,
                        Qr: d,
                        Rr: e
                    }) => {
                        if (c != null && (d || e)) {
                            var f;
                            b = (f = b === null || b === void 0 ? void 0 : b.get()) !== null && f !== void 0 ? f : 1;
                            f = a.direction === "rtl";
                            var g = {
                                ZJ0G6w: !f,
                                dOI_jA: f
                            };
                            if (d && e) return d = a.va(c.wc) + c.wc.height, a = a.qa(c.$b) + c.$b.width, Y5("div", {
                                style: {
                                    top: d * b,
                                    width: a * b,
                                    height: y6 * b
                                },
                                className: a6("aX8dhQ", "VGcLng")
                            });
                            if (d) return c = a.qa(c.$b) + c.$b.width, Y5("div", {
                                style: {
                                    width: y6 * b,
                                    height: a.height * b,
                                    ...(f ? {
                                        right: c * b
                                    } : {
                                        left: c * b
                                    })
                                },
                                className: a6("aX8dhQ", "gl1RPg",
                                    g)
                            });
                            if (e) return c = a.va(c.wc) + c.wc.height, Y5("div", {
                                style: {
                                    top: c * b,
                                    width: a.width * b,
                                    height: y6 * b
                                },
                                className: a6("aX8dhQ", "VGcLng")
                            })
                        }
                    });
                var z6 = ({
                        sheet: a,
                        range: b,
                        O: c,
                        children: d
                    }) => {
                        const e = X5();
                        Fyb({
                            sheet: a,
                            O: c,
                            range: b,
                            xi: e
                        });
                        return Y5("div", {
                            ref: e,
                            className: a6("nstn2A", a.direction === "rtl" ? "NgnL2Q" : "f8jAGQ"),
                            children: d
                        })
                    },
                    rzb = ({
                        sheet: a,
                        range: b,
                        O: c,
                        children: d
                    }) => {
                        const e = X5();
                        Fyb({
                            sheet: a,
                            O: c,
                            range: b,
                            xi: e
                        });
                        a = a.direction === "rtl" ? "NgnL2Q" : "f8jAGQ";
                        return Y5("div", {
                            className: a6("nstn2A", a, "_9sodyg"),
                            children: Y5("div", {
                                ref: e,
                                className: a6("nstn2A", a),
                                children: d
                            })
                        })
                    };
                var Hyb = d6(({
                        sheet: a,
                        children: b,
                        xx: c
                    }) => {
                        const d = e6(f => {
                                c.qea(a, f)
                            }, [c, a]),
                            e = e6(f => {
                                f != null ? c.yx.set(a, f) : c.yx.delete(a)
                            }, [c, a]);
                        return Y5(__c.T9a, {
                            direction: a.config.direction === "rtl" ? "rtl" : "ltr",
                            onScroll: d,
                            TD: e,
                            children: b
                        })
                    }),
                    Gyb = class {
                        qea(a, b) {
                            this.onScroll && this.onScroll(a);
                            this.HT.set(a, b)
                        }
                        constructor(a) {
                            this.onScroll = a;
                            this.yx = new WeakMap;
                            this.HT = w6.map(new Map, {
                                deep: !1
                            });
                            this.scrollTo = u6((b, c) => {
                                b = this.yx.get(b);
                                b === null || b === void 0 || b.scrollTo({
                                    left: Math.floor(c)
                                })
                            })
                        }
                    };
                var Kyb = d6(a => {
                    const b = a.item,
                        c = a.$l,
                        d = a.We,
                        e = a.measureRef,
                        f = a.O,
                        g = a.Qra,
                        h = a.Cb,
                        k = a.lq,
                        l = a.mq,
                        m = a.Wm,
                        n = a.RE,
                        p = a.gg,
                        q = a.Md,
                        r = a.xx;
                    a = c6(() => __c.iC(b.Oa, q), [b, q]);
                    const t = c6(() => d6(({
                            sheet: y,
                            range: z,
                            Qr: C,
                            Rr: D
                        }) => Y5(z6, {
                            sheet: y,
                            range: z,
                            O: f,
                            children: Y5(qzb, {
                                sheet: y,
                                O: f,
                                range: z,
                                Qr: C,
                                Rr: D
                            })
                        })), [f]),
                        v = ryb(b.config),
                        u = f.get(),
                        x = Math.min(v.width * u, h.width);
                    i6(() => j6(() => {
                        var y = b.config.view.freeze.ZB ? b.config.layout.qd.get(b.config.view.freeze.ZB) : void 0;
                        if (y != null)
                            if (b.config.qa(y) + y.width > x) {
                                if (y = r.yx.get(b)) y.style.overflowX =
                                    "hidden"
                            } else if (y = r.yx.get(b)) y.style.overflowX = "scroll"
                    }), [b, h.width, r, u, x]);
                    return Y5("div", {
                        ref: e,
                        className: "E8r86A",
                        style: {
                            width: x
                        },
                        children: Y5(n, {
                            sheet: b,
                            children: Y5("div", {
                                ref: g,
                                className: "cXTiJA",
                                style: {
                                    width: v.width * u,
                                    height: v.height * u
                                },
                                children: Y5("div", {
                                    className: "W1ir5A",
                                    children: Y5(m, {
                                        container: d.Qh(b),
                                        sheet: b.config,
                                        zW: "visible",
                                        $l: c,
                                        O: f,
                                        lq: k,
                                        mq: l,
                                        Ad: a,
                                        gg: p,
                                        CB: t
                                    })
                                })
                            })
                        })
                    })
                });
                var szb = d6(({
                    page: a,
                    range: b,
                    sx: c
                }) => {
                    const d = Myb(a.sheet, b);
                    return Y5("div", {
                        className: "Gi9pfA",
                        children: a.elements.map((e, f) => d == null ? c(e, f) : __c.Gl(Il(e)).im(d) && c(e, f))
                    })
                });
                var tzb = new __c.nU,
                    A6 = a => izb * a,
                    uzb = () => "primary-default",
                    Nyb = d6(({
                        container: a,
                        $l: b,
                        lq: c,
                        mq: d,
                        MQ: e,
                        O: f,
                        viewport: g,
                        JVa: h,
                        Wm: k,
                        gg: l,
                        sx: m,
                        F1: n,
                        I_a: p,
                        JZa: q,
                        IZa: r
                    }) => {
                        const t = a.page,
                            v = c6(() => d6(({
                                sheet: u,
                                range: x,
                                Qr: y,
                                Rr: z
                            }) => $5(Vyb, {
                                children: [Y5(z6, {
                                    sheet: t.sheet,
                                    range: x,
                                    O: f,
                                    children: Y5(qzb, {
                                        sheet: u,
                                        O: f,
                                        range: x,
                                        Qr: y,
                                        Rr: z
                                    })
                                }), $5(rzb, {
                                    sheet: t.sheet,
                                    range: x,
                                    O: f,
                                    children: [p && Y5(p, {}), m && Y5(szb, {
                                        page: t,
                                        sx: m,
                                        range: x
                                    }), r && Y5(r, {}), n && n()]
                                }), q && x && Y5(z6, {
                                    sheet: t.sheet,
                                    range: x,
                                    O: f,
                                    children: Y5(q, {
                                        range: x
                                    })
                                })]
                            })), [t, f, p, m, r, n, q]);
                        return h ? Y5(vzb, {
                            container: a,
                            viewport: g,
                            O: f,
                            $l: b,
                            lq: c,
                            mq: d,
                            Wm: k,
                            gg: l,
                            CB: v
                        }) : Y5(k, {
                            sheet: t.sheet,
                            container: a,
                            zW: "hidden",
                            $l: b,
                            lq: c,
                            mq: d,
                            MQ: e,
                            O: f,
                            viewport: g,
                            gg: l,
                            CB: v
                        })
                    }),
                    vzb = d6(a => {
                        const b = a.container,
                            c = a.O,
                            d = a.viewport,
                            e = a.$l,
                            f = a.lq,
                            g = a.mq,
                            h = a.Wm,
                            k = a.gg;
                        a = a.CB;
                        const l = b.page,
                            m = l.sheet.direction === "rtl",
                            n = q6(null),
                            p = q6(null),
                            q = q6(null);
                        i6(() => {
                            const y = B6({
                                sheet: l.sheet,
                                O2: !0,
                                P2: !0,
                                O: c,
                                viewport: d
                            });
                            return l6(() => y === null || y === void 0 ? void 0 : y.get(), z => {
                                const C = n.current;
                                if (z && C) {
                                    var D =
                                        l.sheet.direction === "rtl",
                                        F;
                                    C.style.position = (F = z.position) !== null && F !== void 0 ? F : "sticky";
                                    var G;
                                    C.style.top = (G = z.top) !== null && G !== void 0 ? G : "0px";
                                    var I, J;
                                    D ? C.style.right = (I = z.right) !== null && I !== void 0 ? I : "0px" : C.style.left = (J = z.left) !== null && J !== void 0 ? J : "0px";
                                    var L;
                                    C.style.transform = (L = z.transform) !== null && L !== void 0 ? L : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        i6(() => {
                            const y = B6({
                                sheet: l.sheet,
                                O2: !1,
                                P2: !0,
                                O: c,
                                viewport: d
                            });
                            return l6(() => y === null || y === void 0 ? void 0 : y.get(), z => {
                                const C = q.current;
                                if (z && C) {
                                    var D;
                                    C.style.position =
                                        (D = z.position) !== null && D !== void 0 ? D : "sticky";
                                    var F;
                                    C.style.top = (F = z.top) !== null && F !== void 0 ? F : "0px";
                                    var G;
                                    C.style.transform = (G = z.transform) !== null && G !== void 0 ? G : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        i6(() => {
                            const y = B6({
                                sheet: l.sheet,
                                O2: !0,
                                P2: !1,
                                O: c,
                                viewport: d
                            });
                            return l6(() => y === null || y === void 0 ? void 0 : y.get(), z => {
                                const C = p.current;
                                if (z && C) {
                                    var D = l.sheet.direction === "rtl",
                                        F;
                                    C.style.position = (F = z.position) !== null && F !== void 0 ? F : "sticky";
                                    var G, I;
                                    D ? C.style.right = (G = z.right) !== null && G !== void 0 ? G : "0px" : C.style.left = (I =
                                        z.left) !== null && I !== void 0 ? I : "0px";
                                    var J;
                                    C.style.transform = (J = z.transform) !== null && J !== void 0 ? J : ""
                                }
                            })
                        }, [l.sheet, c, d]);
                        const r = e6((y, z, C) => B6({
                                sheet: y,
                                O2: z,
                                P2: C,
                                O: c,
                                viewport: d
                            }), [c, d]),
                            t = c6(() => r ? () => r(l.sheet, !0, !1) : void 0, [r, l.sheet]),
                            v = c6(() => r ? () => r(l.sheet, !1, !0) : void 0, [r, l.sheet]);
                        var u;
                        const x = (u = c === null || c === void 0 ? void 0 : c.get()) !== null && u !== void 0 ? u : 1;
                        return $5("div", {
                            className: a6("OsKKIQ", "cbOp6Q"),
                            children: [Y5("div", {
                                className: "VDFv_A",
                                children: Y5(h, {
                                    sheet: l.sheet,
                                    container: b,
                                    zW: "hidden",
                                    $l: e,
                                    lq: f,
                                    mq: g,
                                    MQ: r,
                                    O: c,
                                    viewport: d,
                                    gg: k,
                                    CB: a
                                })
                            }), Y5("div", {
                                ref: n,
                                className: "_688KWg",
                                children: Y5(Byb, {
                                    kj: m,
                                    tra: !1,
                                    dm: A6,
                                    scale: x
                                })
                            }), Y5("div", {
                                ref: q,
                                className: "m0cT1w",
                                children: Y5(f6, {
                                    sheet: l.sheet,
                                    Kd: x,
                                    le: x,
                                    dm: A6,
                                    nz: uzb,
                                    aA: tzb,
                                    e$: t
                                })
                            }), Y5("div", {
                                ref: p,
                                className: "zm537g",
                                children: Y5(g6, {
                                    sheet: l.sheet,
                                    Kd: x,
                                    le: x,
                                    dm: A6,
                                    nz: uzb,
                                    aA: tzb,
                                    e$: v
                                })
                            })]
                        })
                    }),
                    B6 = ({
                        sheet: a,
                        O2: b,
                        P2: c,
                        O: d,
                        viewport: e
                    }) => k6(() => {
                        var f = e === null || e === void 0 ? void 0 : __c.Ql(e.get()),
                            g;
                        const h = (g = d === null || d === void 0 ? void 0 : d.get()) !== null &&
                            g !== void 0 ? g : 1;
                        if (!f) return {};
                        g = {};
                        f = new jl(f.left, f.top);
                        const k = a.direction === "rtl";
                        g.position = "relative";
                        c && (g.top = "0px");
                        b && (k ? g.right = "0px" : g.left = "0px");
                        g.transform = `translate(${b?f.x*h:0}px, ${c?f.y*h:0}px)`;
                        return g
                    });
                var Tyb = class {
                    constructor(a) {
                        this.Dx = a;
                        this.pHa = __c.fW;
                        this.GMa = s6((b, c, d, e) => {
                            d = d.get();
                            const f = new WeakMap;
                            for (let t = 0; t < d.length; t++) {
                                var g = d[t],
                                    h = this.BMa(b, c, g);
                                if (h) {
                                    switch (h) {
                                        case "start":
                                        case "justify":
                                            var k = d[t + 1];
                                            if (k == null || !YM(b, c, k)) continue;
                                            break;
                                        case "center":
                                            k = d[t + 1];
                                            if (k == null || !YM(b, c, k)) continue;
                                            k = d[t - 1];
                                            if (k == null || !YM(b, c, k)) continue;
                                            break;
                                        case "end":
                                            k = d[t - 1];
                                            if (k == null || !YM(b, c, k)) continue;
                                            break;
                                        default:
                                            throw new E(h);
                                    }
                                    if (k = e(c, g)) {
                                        var l = k.width + (h === "center" ? 0 : this.pHa);
                                        if (!(g.width >
                                                l)) {
                                            switch (h) {
                                                case "start":
                                                case "justify":
                                                    h = b.qa(g);
                                                    k = h + l;
                                                    break;
                                                case "center":
                                                    k = b.qa(g) + g.width / 2;
                                                    h = k - l / 2;
                                                    k += l / 2;
                                                    break;
                                                case "end":
                                                    k = b.qa(g) + g.width;
                                                    h = k - l;
                                                    break;
                                                default:
                                                    throw new E(h);
                                            }
                                            for (l = d.indexOf(g); l >= 0; l--) {
                                                var m = d[l],
                                                    n = l - 1 < 0 || YM(b, c, d[l - 1]),
                                                    p;
                                                if (p = m === g || YM(b, c, m)) {
                                                    p = h;
                                                    var q = k,
                                                        r = b.qa(m);
                                                    p = p < r && r < q
                                                }
                                                if (p && n) f.set(m, 1);
                                                else break
                                            }
                                            for (g = d.indexOf(g) + 1; g < d.length; g++) {
                                                l = d[g];
                                                if (m = YM(b, c, l)) m = h, n = k, p = b.qa(l), m = m < p && p < n;
                                                if (m) f.set(l, 1);
                                                else break
                                            }
                                        }
                                    }
                                }
                            }
                            return f
                        });
                        this.BMa = (b, c, d) => {
                            var e, f;
                            const g =
                                b.layout.cells.get(c, d);
                            if (g && (g.ref.content.ref || g.ref.za.ref) && g.span.Fb === g.span.wc && g.span.Bb === g.span.$b) {
                                var h = this.Dx.Sr(b, c, d);
                                b = this.Dx.a$(b, c, d, __c.Yg({
                                    Of: void 0,
                                    textAlign: void 0
                                }));
                                var {
                                    Of: k,
                                    textAlign: l
                                } = __c.qg(__c.Xg, b);
                                if (k === "overflow") return __c.Gwa(l, (e = g.ref.content.ref) === null || e === void 0 ? void 0 : e.type, (f = g.ref.za.ref) === null || f === void 0 ? void 0 : f.type, h ? () => h.Fi.type : void 0)
                            }
                        }
                    }
                };
                var wzb = d6(function(a) {
                    const b = a.sheet;
                    var c = a.oh;
                    const d = a.zYa,
                        e = a.O,
                        f = a.laa,
                        g = a.rMa;
                    a = a.overflow;
                    const h = X5();
                    Zyb(() => j6(() => {
                        const p = B(h.current);
                        var q;
                        const r = (q = e === null || e === void 0 ? void 0 : e.get()) !== null && q !== void 0 ? q : 1;
                        q = b.height;
                        p.style.width = `${b.width*r}px`;
                        p.style.height = `${q*r}px`
                    }), [h, e, b]);
                    const k = e6(p => f.GMa(b, p, d, g), [f, b, d, g]);
                    var l = e6((p, q) => {
                        var r, t;
                        return (t = (r = k(p)) === null || r === void 0 ? void 0 : r.get(q)) !== null && t !== void 0 ? t : 0
                    }, [k]);
                    c = oyb(b, c, d, l);
                    l = b.width;
                    const m = b.height,
                        n = b.direction ===
                        "rtl";
                    return Y5("svg", {
                        ref: h,
                        role: "presentation",
                        className: a6("c6a1eQ", {
                            H_CtIQ: !n,
                            _8_56PQ: n,
                            _3NnFzw: a === "visible",
                            JMH1ng: a === "hidden"
                        }),
                        viewBox: `0 0 ${l} ${m}`,
                        strokeLinecap: "butt",
                        strokeLinejoin: "miter",
                        children: c.map(({
                            lines: p,
                            color: q,
                            weight: r,
                            zi: t,
                            Ai: v
                        }) => Y5("path", {
                            stroke: q,
                            strokeDasharray: t,
                            strokeDashoffset: v,
                            strokeWidth: r,
                            d: p.map(({
                                p1: u,
                                p2: x
                            }) => `M ${u.x} ${u.y} L ${x.x} ${x.y}`).join(" ")
                        }, `${q}-${r}-${t}-${v}`))
                    })
                });
                var xzb = class {
                    get size() {
                        return this.t2
                    }
                    get([a, b]) {
                        return (a = this.Nz.get(a)) ? a.get(b) : void 0
                    }
                    has([a, b]) {
                        a = this.Nz.get(a);
                        return a == null ? !1 : a.has(b)
                    }
                    set([a, b], c) {
                        let d = this.Nz.get(a);
                        d == null && (d = new Map, this.Nz.set(a, d));
                        d.set(b, c);
                        this.t2++;
                        return this
                    }
                    clear() {
                        this.Nz.clear();
                        this.t2 = 0
                    }
                    delete([a, b]) {
                        const c = this.Nz.get(a);
                        if (c == null || !c.delete(b)) return !1;
                        this.t2--;
                        c.size === 0 && this.Nz.delete(a);
                        return !0
                    }
                    forEach(a) {
                        for (const [b, c] of this.Nz)
                            for (const [d, e] of c) a([b, d], e)
                    }*[Symbol.iterator]() {
                        for (const [a,
                                b
                            ] of this.Nz)
                            for (const [c, d] of b) yield [
                                [a, c], d
                            ]
                    }
                    constructor() {
                        this.t2 = 0;
                        this.Nz = new Map
                    }
                };
                var Ryb = __c.Bz("285688d5", !1),
                    D6 = class extends p6 {
                        render() {
                            const {
                                aZ: a,
                                ...b
                            } = this.props, c = this.props.sheet;
                            return $5("div", {
                                ref: this.aAa,
                                className: a6("ZTz_iA", c.direction === "ltr" ? "TA4X7w" : "WvuqMw"),
                                children: [(a === null || a === void 0 ? void 0 : a.Hla) && Y5(C6, { ...b,
                                    sheet: c,
                                    range: a.Hla.range,
                                    Qr: !0,
                                    Rr: !0,
                                    className: "_0C8M3w"
                                }), (a === null || a === void 0 ? void 0 : a.cDa) && Y5(C6, { ...b,
                                    sheet: c,
                                    range: a.cDa.range,
                                    Qr: !1,
                                    Rr: !0,
                                    className: "_7n44yg"
                                }), (a === null || a === void 0 ? void 0 : a.vra) && Y5(C6, { ...b,
                                    sheet: c,
                                    range: a.vra.range,
                                    Qr: !0,
                                    Rr: !1,
                                    className: "fF5r6w"
                                }), (a === null || a === void 0 ? void 0 : a.dCa) && Y5(C6, { ...b,
                                    sheet: c,
                                    range: a.dCa.range,
                                    Qr: !1,
                                    Rr: !1,
                                    className: "llILYw"
                                })]
                            })
                        }
                        componentDidMount() {
                            const a = j6(() => {
                                var b = this.props,
                                    c = b.O;
                                b = b.sheet;
                                const d = this.aAa.current;
                                d && (c = c ? c.get() : 1, d.style.width = `${b.width*c}px`, d.style.height = `${b.height*c}px`)
                            });
                            __c.jc(this, [a])
                        }
                        constructor(...a) {
                            super(...a);
                            this.aAa = CC()
                        }
                    };
                D6 = x6([yc], D6);
                var C6 = class extends p6 {
                    static A(a) {
                        P(a, {
                            yea: k6,
                            bounds: k6
                        })
                    }
                    get yea() {
                        const a = this.props.viewport,
                            b = this.props.Qr,
                            c = this.props.Rr;
                        return a == null || !b && !c ? a : k6(() => {
                            const d = __c.Ql(a.get());
                            return Il({
                                top: c ? 0 : d.top,
                                left: b ? 0 : d.left,
                                width: d.width,
                                height: d.height
                            })
                        })
                    }
                    render() {
                        const a = this.props.WG,
                            b = this.props.sheet,
                            c = this.props.container,
                            d = this.props.range,
                            e = this.props.CB,
                            f = this.props.Qr,
                            g = this.props.Rr;
                        return $5("div", {
                            ref: this.Cca,
                            className: a6("i0YQww", this.props.className),
                            children: [Y5("div", {
                                ref: this.Fwa,
                                className: "vUKoKg",
                                children: Y5("div", {
                                    ref: this.Gwa,
                                    children: Y5(E6, {
                                        WG: a,
                                        sheet: b,
                                        container: c,
                                        bounds: d,
                                        $l: this.props.$l,
                                        Ux: this.props.Ux,
                                        gg: this.props.gg,
                                        wP: this.props.wP,
                                        O: this.props.O,
                                        oh: this.oh,
                                        hV: this.hV,
                                        sK: this.sK
                                    })
                                })
                            }), Y5(this.i5, {}), e && Y5(e, {
                                sheet: b,
                                range: d,
                                Qr: f,
                                Rr: g
                            })]
                        })
                    }
                    componentDidMount() {
                        const a = j6(() => {
                                var g = this.props,
                                    h = g.O,
                                    k = g.sheet;
                                const l = g.range;
                                var m = this.Cca.current;
                                const n = this.Fwa.current;
                                g = this.Gwa.current;
                                h = h ? h.get() : 1;
                                const p = l ? k.qa(l.$b) + l.$b.width - k.qa(l.Bb) : k.width,
                                    q = l ? k.va(l.wc) +
                                    l.wc.height - k.va(l.Fb) : k.height;
                                m && (m.style.width = `${p*h}px`, m.style.height = `${q*h}px`);
                                n && (n.style.width = `${p*h}px`, n.style.height = `${q*h}px`);
                                m = k.direction === "rtl";
                                m = l ? k.qa(l.Bb) * h * (m ? 1 : -1) : 0;
                                k = l ? -k.va(l.Fb) * h : 0;
                                g && (g.style.transform = `translate(${m}px, ${k}px)`)
                            }),
                            b = this.props.sheet;
                        var c = this.props.MQ;
                        const d = this.props.Qr,
                            e = this.props.Rr,
                            f = d || e ? c === null || c === void 0 ? void 0 : c(b, d, e) : void 0;
                        c = j6(() => {
                            const g = this.Cca.current;
                            if (g != null) {
                                var h = d || e ? "sticky" : "relative",
                                    k = e ? "0px" : "unset",
                                    l = d ? "0px" :
                                    "unset",
                                    m = d ? "0px" : "unset",
                                    n = b.direction === "rtl";
                                if (f == null) g.style.position = h, g.style.top = k, g.style.left = n ? "unset" : l, g.style.right = n ? m : "unset";
                                else {
                                    const u = f.get();
                                    var p;
                                    g.style.position = (p = u.position) !== null && p !== void 0 ? p : h;
                                    var q;
                                    g.style.top = (q = u.top) !== null && q !== void 0 ? q : k;
                                    var r;
                                    g.style.left = n ? "unset" : (r = u.left) !== null && r !== void 0 ? r : l;
                                    var t;
                                    g.style.right = n ? (t = u.right) !== null && t !== void 0 ? t : m : "unset";
                                    var v;
                                    g.style.transform = (v = u.transform) !== null && v !== void 0 ? v : "unset"
                                }
                            }
                        });
                        __c.jc(this, [a, c])
                    }
                    get bounds() {
                        const a =
                            this.props.sheet,
                            b = this.props.range;
                        if (a.layout.cols.empty || a.layout.rows.empty) return {
                            Bb: void 0,
                            $b: void 0,
                            Fb: void 0,
                            wc: void 0
                        };
                        var c, d, e, f;
                        return {
                            Bb: (c = b === null || b === void 0 ? void 0 : b.Bb) !== null && c !== void 0 ? c : a.layout.cols.first(),
                            $b: (d = b === null || b === void 0 ? void 0 : b.$b) !== null && d !== void 0 ? d : a.layout.cols.last(),
                            Fb: (e = b === null || b === void 0 ? void 0 : b.Fb) !== null && e !== void 0 ? e : a.layout.rows.first(),
                            wc: (f = b === null || b === void 0 ? void 0 : b.wc) !== null && f !== void 0 ? f : a.layout.rows.last()
                        }
                    }
                    constructor(...a) {
                        super(...a);
                        this.Cca = (C6.A(this), CC());
                        this.Fwa = CC();
                        this.Gwa = CC();
                        this.sK = new yzb;
                        this.AYa = k6(() => [...this.oh.get().keys()].sort((b, c) => this.props.sheet.layout.rows.Qd(b, c)), {
                            equals: __c.Uk()
                        });
                        this.yYa = k6(() => [...this.hV.get().keys()].sort((b, c) => this.props.sheet.layout.cols.Qd(b, c)), {
                            equals: __c.Uk()
                        });
                        this.i5 = d6(() => Y5(this.props.PEa, {
                            oh: this.AYa,
                            zYa: this.yYa,
                            rMa: this.sK.zMa,
                            range: this.props.range
                        }));
                        this.oh = k6(() => {
                            var b;
                            const c = this.props.sheet;
                            var d = this.props.O,
                                e = (b = this.yea) === null || b === void 0 ? void 0 :
                                b.get();
                            if (e && (e.height <= 0 || e.width <= 0)) return new Map;
                            b = this.bounds;
                            d = d.get();
                            var f = 50 * d;
                            const g = e ? e.tl.y - f : b.Fb ? c.va(b.Fb) : 0;
                            e = e ? e.br.y + f : b.wc ? c.va(b.wc) + b.wc.height : 0;
                            f = new Map;
                            for (let h = b.Fb; h != null && b.wc != null && c.layout.rows.Qd(h, b.wc) <= 0; h = c.layout.rows.next(h)) {
                                const k = c.va(h);
                                if (!(k + h.height < g)) {
                                    if (k > e) break;
                                    f.set(h, k * d)
                                }
                            }
                            return f
                        }, {
                            equals: v6.shallow
                        });
                        this.hV = k6(() => {
                            var b;
                            const c = this.props.sheet;
                            var d = this.props.O,
                                e = (b = this.yea) === null || b === void 0 ? void 0 : b.get();
                            if (e && (e.height <= 0 || e.width <=
                                    0)) return new Map;
                            b = this.bounds;
                            d = d.get();
                            var f = 50 * d;
                            const g = e ? e.tl.x - f : b.Bb ? c.qa(b.Bb) : 0;
                            e = e ? e.br.x + f : b.$b ? c.qa(b.$b) + b.$b.width : 0;
                            f = new Map;
                            for (let h = b.Bb; h != null && b.$b != null && c.layout.cols.Qd(h, b.$b) <= 0; h = c.layout.cols.next(h)) {
                                const k = c.qa(h);
                                if (!(k + h.width < g)) {
                                    if (k > e) break;
                                    f.set(h, k * d)
                                }
                            }
                            return f
                        }, {
                            equals: v6.shallow
                        })
                    }
                };
                C6 = x6([yc], C6);
                var yzb = class {
                        constructor() {
                            this.cells = new xzb;
                            this.wda = (a, b, c) => {
                                let d = this.cells.get([a, b]);
                                d == null && (d = w6.box(void 0, {
                                    deep: !1
                                }), this.cells.set([a, b], d));
                                d.set(c);
                                return () => {
                                    const e = this.cells.get([a, b]);
                                    e === d && (e.set(void 0), this.cells.delete([a, b]))
                                }
                            };
                            this.zMa = (a, b) => {
                                var c;
                                let d = this.cells.get([a, b]);
                                d == null && (d = w6.box(void 0, {
                                    deep: !1
                                }), this.cells.set([a, b], d));
                                return (c = d.get()) === null || c === void 0 ? void 0 : c.sna
                            }
                        }
                    },
                    E6 = class extends p6 {
                        static A(a) {
                            P(a, {
                                CE: w6.shallow,
                                St: k6,
                                nla: u6,
                                EX: u6.bound
                            })
                        }
                        get St() {
                            var a;
                            const b = (a = this.props.$l) === null || a === void 0 ? void 0 : a.get();
                            if (b != null && b.length !== 0) return new __c.bJ(b)
                        }
                        render() {
                            var a;
                            return $5("div", {
                                ref: Wyb(this.xi, (a = this.St) === null || a === void 0 ? void 0 : a.up),
                                children: [Y5("div", {
                                    ref: this.Z6,
                                    className: "_5YlOqQ"
                                }), Y5("div", {
                                    ref: this.b7,
                                    className: "_XCmKw"
                                }), this.CE.map(b => b.uTa)]
                            })
                        }
                        componentDidMount() {
                            const a = l6(() => [this.props.sheet, this.props.hV.get(), this.props.oh.get()], ([d, e, f], g) => {
                                    [g] = g || [];
                                    d !== g && (d = B(this.Z6.current), g = B(this.b7.current), d.innerHTML = "",
                                        g.innerHTML = "", this.ria.length = 0, this.CE.length = 0);
                                    this.nla(e, f)
                                }, {
                                    fireImmediately: !0
                                }),
                                b = j6(() => {
                                    var d = this.props,
                                        e = d.O;
                                    d = d.sheet;
                                    const f = this.xi.current;
                                    f && (e = e ? e.get() : 1, f.style.width = `${d.width*e}px`, f.style.height = `${d.height*e}px`)
                                }),
                                c = this.CE.map(d => Syb(d));
                            __c.jc(this, [b, a, ...c])
                        }
                        nla(a, b) {
                            const c = B(this.Z6.current),
                                d = B(this.b7.current),
                                e = [],
                                f = new Map;
                            for (const g of this.ria) b.has(g.la) ? f.set(g.la, g) : e.push(g);
                            for (const [g, h] of b) b = f.get(g) || e.pop(), b || (b = new zzb(this.EX, g), c.appendChild(b.RW),
                                d.appendChild(b.TW), this.ria.push(b)), b.update(h, g, a);
                            for (const g of e) g.hide()
                        }
                        EX(a, b) {
                            const c = this.props.wP,
                                d = this.props.sheet,
                                e = this.props.container,
                                f = this.props.sK;
                            a = new Azb(this.props.WG, this.props.Ux, this.props.gg, c(a, b), d, a, b, e, f.wda, this.oZ, this.nZ);
                            __c.jc(this, Syb(a));
                            this.CE.push(a);
                            return a
                        }
                        constructor(...a) {
                            super(...a);
                            this.xi = (E6.A(this), CC());
                            this.Z6 = CC();
                            this.b7 = CC();
                            this.ria = [];
                            this.CE = [];
                            this.oZ = s6(b => {
                                const c = this.props.oh.get();
                                return b === "first" ? c.keys().next().value : [...c.keys()].pop()
                            });
                            this.nZ = s6(b => {
                                const c = this.props.hV.get();
                                return b === "first" ? c.keys().next().value : [...c.keys()].pop()
                            })
                        }
                    };
                E6 = x6([yc], E6);
                var zzb = class {
                        static A(a) {
                            P(a, {
                                update: u6
                            })
                        }
                        update(a, b, c) {
                            [this.RW, this.TW].forEach(d => {
                                d.style.transform = `translateY(${a}px)`;
                                d.classList.add("FPpqvg")
                            });
                            this.la = b;
                            for (const [d] of c) c = this.CE.get(d), c || (c = this.EX(d, b), this.CE.set(d, c), this.RW.appendChild(c.QW), this.TW.appendChild(c.gF)), c.update(b)
                        }
                        hide() {
                            [this.RW, this.TW].forEach(a => {
                                a.style.transform = "translate(-1000px, -1000px) scale(0)"
                            })
                        }
                        constructor(a, b) {
                            this.EX = a;
                            this.la = b;
                            this.RW = (zzb.A(this), document.createElement("div"));
                            this.TW = document.createElement("div");
                            this.CE = new Map
                        }
                    },
                    Azb = class {
                        static A(a) {
                            P(a, {
                                rX: w6.ref,
                                la: w6.ref,
                                A$: k6,
                                update: u6,
                                Rp: k6,
                                attrs: k6.struct,
                                Eaa: k6,
                                Er: k6,
                                renderer: k6,
                                sna: k6.struct
                            })
                        }
                        get A$() {
                            if (!Ryb) return !1;
                            const a = this.Rp;
                            return a == null || a.content.ref == null || a.content.ref.type !== "formula" ? !1 : this.WG(this.sheet, a.content.ref.value)
                        }
                        update(a) {
                            a !== this.la && (this.la = a, this.Zu.la = a, this.A8 && this.A8(), this.A8 = this.wda(this.la, this.col, this))
                        }
                        get uTa() {
                            return this.rX
                        }
                        get Rp() {
                            const a = this.sheet.layout.cells.get(this.la, this.col);
                            return a ?
                                a.ref : void 0
                        }
                        get attrs() {
                            const a = this.Zu.attrs;
                            return {
                                Of: a === null || a === void 0 ? void 0 : a.Of,
                                textAlign: a === null || a === void 0 ? void 0 : a.textAlign,
                                direction: a === null || a === void 0 ? void 0 : a.direction,
                                link: a === null || a === void 0 ? void 0 : a.link
                            }
                        }
                        get Eaa() {
                            var a = this.Zu.span;
                            if (!a) return !1;
                            if (a.Fb === a.wc && a.Bb === a.$b) return !0;
                            var b = this.oZ("first");
                            const c = this.oZ("last"),
                                d = this.nZ("first"),
                                e = this.nZ("last");
                            if (!(b && c && d && e)) return !1;
                            b = this.sheet.layout.rows.Qd(a.Fb, b) >= 0 && this.sheet.layout.rows.Qd(a.Fb, c) <= 0 ? a.Fb :
                                b;
                            a = this.sheet.layout.cols.Qd(a.Bb, d) >= 0 && this.sheet.layout.cols.Qd(a.Bb, e) <= 0 ? a.Bb : d;
                            return b === this.la && a === this.col
                        }
                        get Er() {
                            const a = this.sheet,
                                b = this.la,
                                c = this.col;
                            if (!this.container) return {
                                type: void 0,
                                sheet: a,
                                la: b,
                                column: c
                            };
                            switch (this.container.type) {
                                case "fixed-page":
                                    return this.container.USa.Oc(c, b);
                                case "sheet-item":
                                    return this.container.xea.Oc(c, b);
                                case "sheet-element":
                                    return this.container.BVa.Oc(c, b);
                                default:
                                    throw new E(this.container);
                            }
                        }
                        get renderer() {
                            const a = this.Rp;
                            if (a && this.Eaa &&
                                (a.content.ref || a.za.ref)) return this.Ux({
                                context: {
                                    container: this.Er,
                                    attrs: this.attrs
                                },
                                xm: this.Xba,
                                gg: this.gg
                            })
                        }
                        get sna() {
                            this.tna.reportObserved();
                            var a = dzb(() => this.renderer);
                            if (a && (a = a.type === "react" ? this.iT : this.Oy, a.childNodes.length !== 0 && (a = a.childNodes[0], a instanceof HTMLElement))) return {
                                width: a.clientWidth,
                                height: a.clientHeight
                            }
                        }
                        constructor(a, b, c, d, e, f, g, h, k, l, m) {
                            var n, p, q, r, t, v;
                            this.WG = a;
                            this.Ux = b;
                            this.Zu = d;
                            this.sheet = e;
                            this.col = f;
                            this.container = h;
                            this.wda = k;
                            this.oZ = l;
                            this.nZ = m;
                            this.QW =
                                (Azb.A(this), document.createElement("div"));
                            this.gF = document.createElement("div");
                            this.Iy = document.createElement("div");
                            this.Oy = document.createElement("div");
                            this.iT = document.createElement("div");
                            this.tna = czb("content size atom");
                            this.Xba = u6(() => this.tna.reportChanged());
                            this.la = g;
                            this.QW.className = "_2JFriw";
                            this.gF.className = "imy9ug";
                            this.Iy.className = a6("pDMp7w", {
                                _0yZ6Qg: ((p = this.Rp) === null || p === void 0 ? void 0 : (n = p.content.ref) === null || n === void 0 ? void 0 : n.type) !== "text3",
                                qhF5uA: ((r = this.Rp) === null ||
                                    r === void 0 ? void 0 : (q = r.content.ref) === null || q === void 0 ? void 0 : q.type) !== "text3" && ((v = this.Rp) === null || v === void 0 ? void 0 : (t = v.content.ref) === null || t === void 0 ? void 0 : t.type) !== "text2",
                                qxD1GA: this.A$
                            });
                            this.Oy.className = "_30B9pw";
                            this.Iy.appendChild(this.Oy);
                            this.gF.appendChild(this.Iy);
                            this.iT.className = "G7zH2w";
                            this.A8 = k(this.la, this.col, this);
                            this.gg = u => Y5(c, { ...u,
                                xm: this.Xba
                            })
                        }
                    };
                var m6 = class extends p6 {
                    static A(a) {
                        P(a, {
                            aZ: k6
                        })
                    }
                    render() {
                        const {
                            WG: a,
                            sheet: b,
                            container: c,
                            $l: d,
                            MQ: e,
                            Ux: f,
                            Ad: g,
                            gg: h,
                            viewport: k,
                            CB: l,
                            VCa: m = !1
                        } = this.props;
                        if (!b.layout.cols.empty && !b.layout.rows.empty) return Y5("div", {
                            className: a6("SNkrHw", b.direction === "ltr" ? "TA4X7w" : "WvuqMw", {
                                RaA0Nw: m
                            }),
                            ...g,
                            children: Y5(D6, {
                                WG: a,
                                Ux: f,
                                gg: h,
                                PEa: this.i5,
                                wP: this.wP,
                                sheet: b,
                                container: c,
                                $l: d,
                                MQ: e,
                                O: this.O,
                                viewport: k,
                                CB: l,
                                aZ: this.aZ
                            })
                        })
                    }
                    get aZ() {
                        var a = this.props.sheet;
                        const b = {},
                            c = a.view.freeze.GM ? a.layout.Ed.get(a.view.freeze.GM) :
                            void 0,
                            d = a.view.freeze.ZB ? a.layout.qd.get(a.view.freeze.ZB) : void 0,
                            e = a.layout.rows.first(),
                            f = a.layout.rows.last(),
                            g = a.layout.cols.first(),
                            h = a.layout.cols.last();
                        if (e != null && f != null && g != null && h != null) {
                            var k = d ? a.layout.cols.next(d) : g;
                            a = c ? a.layout.rows.next(c) : e;
                            c && d && (b.Hla = {
                                range: {
                                    Bb: g,
                                    Fb: e,
                                    $b: d,
                                    wc: c
                                }
                            });
                            c && k && (b.cDa = {
                                range: {
                                    Bb: k,
                                    Fb: e,
                                    $b: h,
                                    wc: c
                                }
                            });
                            d && a && (b.vra = {
                                range: {
                                    Bb: g,
                                    Fb: a,
                                    $b: d,
                                    wc: f
                                }
                            });
                            a && k && (b.dCa = {
                                range: {
                                    Bb: k,
                                    Fb: a,
                                    $b: h,
                                    wc: f
                                }
                            });
                            return b
                        }
                    }
                    get O() {
                        return this.props.O ? this.props.O : k6(() => 1)
                    }
                    constructor(...a) {
                        super(...a);
                        this.i5 = (m6.A(this), d6(b => {
                            const {
                                sheet: c,
                                laa: d,
                                O: e,
                                zW: f = "hidden"
                            } = this.props;
                            return Y5(z6, {
                                sheet: c,
                                range: b.range,
                                O: e,
                                children: Y5(wzb, { ...b,
                                    sheet: c,
                                    O: this.O,
                                    laa: d,
                                    overflow: f
                                })
                            })
                        }));
                        this.wP = (b, c) => new __c.Zwa(this.props.Dx, this.props.Uu, this.props.sheet, b, c, this.O, this.lq, this.mq);
                        this.lq = (b, c) => {
                            var d, e;
                            return (d = (e = this.props).lq) === null || d === void 0 ? void 0 : d.call(e, this.props.sheet, b, c)
                        };
                        this.mq = (b, c) => {
                            var d, e;
                            return (d = (e = this.props).mq) === null || d === void 0 ? void 0 : d.call(e, this.props.sheet, b, c)
                        }
                    }
                };
                m6 = x6([yc], m6);
                __c.fxa = {
                    BOa: function(a) {
                        const b = a.Gn,
                            c = a.nf,
                            d = a.Oe,
                            e = a.pp,
                            f = a.Dx,
                            g = a.Uu,
                            h = a.aO;
                        yyb({
                            QA: a.QA,
                            hg: a.hg,
                            FWa: a.zT,
                            ib: a.ib
                        });
                        const k = Uyb({
                            Ux: h,
                            Dx: f,
                            Uu: g,
                            Uo: void 0
                        });
                        b.y5 = Oyb({
                            Wm: k
                        });
                        c.j5 = Eyb({
                            Wm: k
                        });
                        ({
                            TEa: a
                        } = Lyb({
                            Wm: k,
                            Cf: e(),
                            Zza: new pzb
                        }));
                        d.hn.x5 = a;
                        const {
                            TDa: l,
                            UDa: m,
                            SDa: n
                        } = Dyb();
                        return {
                            Sja: d6(p => Y5(ezb, { ...p,
                                container: void 0,
                                Wm: k,
                                SEa: l,
                                UEa: m,
                                QEa: n,
                                gg: fzb
                            }))
                        }
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/1103cc9922559a78.js.map