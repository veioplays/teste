(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [24459], {

        /***/
        460541: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(900337);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var Bzb, Ezb, Dzb, Czb;
                Bzb = function(a, {
                    Nc: b,
                    endTime: c,
                    fill: d,
                    file: e,
                    url: f,
                    XUa: g,
                    span: h
                }) {
                    ({
                        fk: c
                    } = h.end(b ? "ok" : "error", c));
                    a.Eg.track(__c.mkb, {
                        source: "editor",
                        Nc: b,
                        pya: d.video,
                        resourceType: g,
                        url: f,
                        height: e.height,
                        width: e.width,
                        quality: e.quality,
                        ph: e.ph,
                        cg: c()
                    })
                };
                Ezb = class {
                    mWa({
                        fill: a,
                        startTime: b,
                        file: c
                    }) {
                        var d, e;
                        if (!this.d4.has(a) && !this.MBa.has(a)) {
                            var f = ((d = c.url) === null || d === void 0 ? 0 : d.startsWith("data:")) || ((e = c.url) === null || e === void 0 ? 0 : e.startsWith("blob:")) ? void 0 : c.url,
                                g = c.container && Czb(c.container),
                                h = this.yd.Js("load_video", {
                                    startTime: b,
                                    attrs: new Map([
                                        ["id", a.video],
                                        ["url", Dzb(f)],
                                        ["height", c.height],
                                        ["width", c.width],
                                        ["quality", c.quality],
                                        ["container", g],
                                        ["watermarked", c.ph]
                                    ])
                                });
                            this.d4.set(a, {
                                end: (k, l) => Bzb(this, {
                                    Nc: k,
                                    endTime: l,
                                    fill: a,
                                    file: c,
                                    url: f,
                                    XUa: g,
                                    span: h
                                })
                            })
                        }
                    }
                    rpa({
                        Nc: a,
                        fill: b,
                        endTime: c
                    }) {
                        const d = this.d4.get(b);
                        d && (d.end(a, c), this.d4.delete(b), this.MBa.add(b))
                    }
                    constructor(a, b) {
                        this.Eg = a;
                        this.yd = b;
                        this.d4 = new WeakMap;
                        this.MBa = new WeakSet
                    }
                };
                Dzb = a => {
                    if (!a) return a;
                    let b;
                    try {
                        b = new URL(a)
                    } catch (c) {
                        return a
                    }
                    b.search = "";
                    return b.toString()
                };
                Czb = a => {
                    switch (a) {
                        case 1:
                            return "MP4";
                        case 2:
                            return "GIF";
                        case 4:
                            return "LOTTIE";
                        case 3:
                            return "WEBM";
                        default:
                            throw new __c.E(a);
                    }
                };
                __c.Lya = {};
                __c.Lya.aFa = Ezb;
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/2e4739bc1307d0b5.js.map