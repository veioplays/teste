(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [84437], {

        /***/
        878415: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var sdb, tdb;
                sdb = function(a) {
                    return (b, c) => ({
                        kind: 2,
                        name: a,
                        bGa: b,
                        cGa: c
                    })
                };
                tdb = function(a) {
                    return b => ({
                        kind: 3,
                        name: a,
                        args: b
                    })
                };
                __c.udb = sdb(1);
                __c.lY = sdb(3);
                __c.vdb = tdb(5);
                __c.wdb = tdb(0);
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/1645c9d0830a89cb.js.map