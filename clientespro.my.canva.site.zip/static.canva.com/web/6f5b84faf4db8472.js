(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [30270], {

        /***/
        914242: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                __c.A0 = function(a, b, c) {
                    return {
                        key: a,
                        fxa: b,
                        type: "string",
                        LD: c,
                        ava: 0
                    }
                };
                __c.B0 = class {
                    get id() {
                        return this.config.id
                    }
                    map(a) {
                        return a(this.config)
                    }
                    constructor(a) {
                        this.config = { ...a
                        }
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/6f5b84faf4db8472.js.map