(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([
    [60205], {

        /***/
        994944: function(_, __, __webpack_require__) {
            __webpack_require__.n_x = __webpack_require__.n;
            const __web_req__ = __webpack_require__;
            __web_req__(813110);
            __web_req__(981587);
            self._c68b74ff4d61aaeea4f241f0854f5b1a = self._c68b74ff4d61aaeea4f241f0854f5b1a || {};
            (function(__c) {
                var E = __c.E;
                var P = __c.P;
                var Swb = function(a, b) {
                        class c {
                            static A(d) {
                                P(d, {
                                    Jd: G5,
                                    Y5: G5
                                })
                            }
                            get Jd() {
                                switch (this.Y5) {
                                    case "date":
                                        return new Nwb(this.Qk, b.language || "en-AU");
                                    case "select":
                                        return new Owb(this.Qk);
                                    case "mention":
                                        return new Pwb(this.Qk);
                                    case "embed":
                                        return new Qwb(this.Qk);
                                    case "plain_number":
                                    case "currency":
                                    case "percentage":
                                    case void 0:
                                        break;
                                    default:
                                        throw new E(this.Y5);
                                }
                            }
                            get Y5() {
                                var d;
                                return (d = this.Qk.Dn) === null || d === void 0 ? void 0 : d.type
                            }
                            constructor(d) {
                                this.context = d;
                                this.Qk = (c.A(this), void 0);
                                this.Qk = __c.B(a.Sr(d.sheet,
                                    d.la, d.column))
                            }
                        }
                        return Rwb(d => (new c(d)).Jd)
                    },
                    Twb = function(a) {
                        var b = ["rgb(255, 255, 255)", "rgb(13, 18, 22)"];
                        try {
                            const c = __c.oD(a),
                                d = c instanceof __c.pD ? c.nE() : c;
                            return __c.rw(b, e => {
                                e = __c.oD(e);
                                e = e instanceof __c.pD ? __c.FL(e, d) : e;
                                return Math.abs(__c.IL(e, d))
                            })
                        } catch (c) {
                            if (c instanceof Error && c.message === `unrecognized color: ${b[0]}`) return b[0];
                            throw c;
                        }
                    },
                    Uwb = function(a) {
                        return a.trim().split(/\s+/, 2).map(b => __c.jx(b)[0]).join("")
                    },
                    Xwb = function(a = "") {
                        a = Vwb(a);
                        a = Math.floor(a() * Wwb.length);
                        return Wwb[a]
                    },
                    Zwb = function(a, b = "medium") {
                        if (a !== null && a !== void 0 && a.length) {
                            var c = window.devicePixelRatio || 1,
                                d = (typeof b === "number" ? b : Ywb(b)) * c;
                            return [...a].sort((e, f) => {
                                e = e.width;
                                f = f.width;
                                return e > d && f < d ? -1 : e < d && f > d ? 1 : Math.abs(e - d) - Math.abs(f - d)
                            })[0].url
                        }
                    },
                    axb = function() {
                        const a = H5(() => new Map, []);
                        return {
                            RMa: b => {
                                if (a.has(b)) return __c.B(a.get(b));
                                const c = $wb();
                                a.set(b, c);
                                return c
                            }
                        }
                    },
                    bxb = function(a, b) {
                        return H5(() => {
                                const c = new Map;
                                return d => {
                                    if (c.has(d)) return __c.B(c.get(d));
                                    const e = a(d);
                                    c.set(d, e);
                                    return e
                                }
                            },
                            b)
                    },
                    ixb = function({
                        children: a,
                        keyFrame: b,
                        wAa: c,
                        ariaLive: d,
                        Ksa: e = !1,
                        RFa: f,
                        L7: g,
                        $Ja: h,
                        o3a: k,
                        ona: l,
                        Soa: m,
                        m3a: n,
                        nXa: p
                    }) {
                        const {
                            RMa: q
                        } = axb(), {
                            $La: r,
                            VTa: t
                        } = cxb(b, a), v = bxb(u => () => {
                            (e === !1 || typeof e === "function" && !e(u)) && t(u)
                        }, [t, e]);
                        return I5("div", {
                            className: J5(g, "_9GxJfQ", {
                                KwB0XQ: l === "hidden",
                                WV1Mmw: c === "fill-height",
                                _2uSJxw: c === "flex-grow"
                            }),
                            children: I5("div", {
                                className: J5("m2VaAA", h),
                                "aria-live": d,
                                style: k,
                                role: "region",
                                children: [...r.map(({
                                    key: u,
                                    element: x
                                }) => I5(dxb, { in: u === b,
                                    timeout: f,
                                    classNames: p,
                                    mountOnEnter: !0,
                                    unmountOnExit: !e,
                                    nodeRef: q(u),
                                    onExited: v(u),
                                    children: y => I5(exb.Provider, {
                                        value: y,
                                        children: I5("div", {
                                            className: J5("KxXR9g", n, {
                                                KwB0XQ: m === "hidden"
                                            }),
                                            ref: q(u),
                                            "aria-hidden": y === fxb || y === gxb || y === hxb,
                                            children: u === b ? a : x
                                        })
                                    })
                                }, u)), r.every(u => u.key !== b) && I5(dxb, { in: !1,
                                    timeout: f,
                                    classNames: p,
                                    mountOnEnter: !0,
                                    unmountOnExit: !e,
                                    nodeRef: q(b),
                                    onExited: e ? void 0 : v(b),
                                    children: u => I5(exb.Provider, {
                                        value: u,
                                        children: I5("div", {
                                            className: J5("KxXR9g", n),
                                            ref: q(b),
                                            "aria-hidden": u === fxb || u === gxb || u === hxb,
                                            children: a
                                        })
                                    })
                                }, b)]
                            })
                        })
                    },
                    cxb = function(a, b) {
                        const [c, d] = jxb(() => [{
                            key: a,
                            element: b
                        }]);
                        kxb(() => {
                            d(f => f.every(g => g.key !== a) ? f.concat({
                                key: a,
                                element: b
                            }) : f.map(g => g.key === a ? {
                                key: a,
                                element: b
                            } : g))
                        }, [a, b]);
                        const e = K5(f => {
                            d(g => g.filter(h => h.key !== f))
                        }, []);
                        return {
                            $La: c,
                            VTa: e
                        }
                    },
                    lxb = function(a) {
                        switch (a.type) {
                            case "mention":
                                return "bCAtqw";
                            case "embed":
                                return "BTcT3w";
                            case "date":
                                return "McKQgg";
                            case "select":
                                return "V2E5nQ";
                            default:
                                throw new E(a);
                        }
                    },
                    pxb = function(a, b) {
                        switch (a.type) {
                            case "mention":
                                return I5(mxb, {
                                    Gq: a.user ? b.CQ(a.user) : void 0,
                                    text: a.text,
                                    backgroundColor: a.user ? b.pMa(a.user).background : void 0
                                });
                            case "embed":
                                const c = !a.url;
                                a = b.Voa.YP.get(a.url);
                                return I5(nxb, {
                                    icon: a,
                                    jPa: c
                                });
                            case "date":
                                return a.text ? void 0 : I5(oxb, {});
                            case "select":
                                break;
                            default:
                                throw new E(a);
                        }
                    },
                    rxb = function(a, b) {
                        switch (a.type) {
                            case "mention":
                            case "embed":
                            case "date":
                                break;
                            case "select":
                                return I5(qxb, {
                                    selected: !!b.yya
                                });
                            default:
                                throw new E(a);
                        }
                    },
                    L5 = function(a) {
                        return (/Mac/.test(navigator.platform) ? a.metaKey : a.ctrlKey) ? !0 : a instanceof KeyboardEvent ? a.key ===
                            "Meta" || ["91", "224"].includes(a.code) : !1
                    },
                    sxb = function(a) {
                        __c.w(!0, "chunkLength must be positive");
                        const b = [];
                        for (let c = 0; c < a.length; c += 50) b.push(a.slice(c, c + 50));
                        return b
                    },
                    txb = function(a, b, c) {
                        if (c) {
                            var d = Zwb(c.images, "medium"),
                                e = Zwb(c.images, "xxxlarge");
                            if (d && e) {
                                c = new Image;
                                c.src = d;
                                var f = new Image;
                                f.src = e;
                                f.onload = M5(() => a.ZU.set(b, e));
                                f.onerror = M5(() => a.ZU.set(b, void 0));
                                !f.complete && c.complete ? a.ZU.set(b, d) : c.src = ""
                            }
                        } else a.ZU.set(b, void 0)
                    },
                    vxb = function(a, {
                        url: b,
                        id: c,
                        extension: d
                    }) {
                        if (!a.promises.has(b)) {
                            const e =
                                new Promise(f => {
                                    a.yh ? a.yh.I5a(new uxb({
                                        id: c,
                                        extension: d
                                    })).then(({
                                        document: g
                                    }) => {
                                        const h = g.hk.content.title;
                                        h ? (N5(() => a.pBa.set(b, {
                                            status: 1,
                                            title: h
                                        })), f(h)) : f(void 0)
                                    }).catch(() => {
                                        N5(() => a.pBa.set(b, {
                                            status: 2
                                        }));
                                        f(void 0)
                                    }) : f(void 0)
                                });
                            a.promises.set(b, e)
                        }
                        return a.promises.get(b)
                    },
                    O5 = __webpack_require__(519427),
                    M5 = O5.action,
                    wxb = O5.comparer,
                    G5 = O5.computed,
                    xxb = O5.observable,
                    P5 = O5.ObservableMap,
                    N5 = O5.runInAction;
                var Rwb = __webpack_require__(635872).Om;
                var Q5 = __webpack_require__(875604),
                    yxb = Q5.createContext,
                    $wb = Q5.createRef,
                    R5 = Q5.memo,
                    K5 = Q5.useCallback,
                    kxb = Q5.useEffect,
                    zxb = Q5.useId,
                    Axb = Q5.useLayoutEffect,
                    H5 = Q5.useMemo,
                    jxb = Q5.useState;
                var Vwb = __webpack_require__(503216);
                var Bxb = __webpack_require__(443763),
                    I5 = Bxb.jsx,
                    S5 = Bxb.jsxs;
                var Cxb = __webpack_require__,
                    Dxb = Cxb(993864),
                    J5 = Cxb.n_x(Dxb)();
                var dxb = __webpack_require__(460876).Z;
                var T5 = __webpack_require__(223826),
                    hxb = T5.Wj,
                    fxb = T5.Ix,
                    gxb = T5.$r;
                var U5 = __webpack_require__(446474).Pi;
                var Exb = class {
                        static A(a) {
                            P(a, {
                                text: G5,
                                user: G5,
                                brand: G5
                            })
                        }
                        get text() {
                            return this.Jd.text
                        }
                        get user() {
                            return this.Jd.user
                        }
                        get brand() {
                            return this.Jd.brand
                        }
                        constructor(a) {
                            this.Jd = a;
                            this.type = (Exb.A(this), "mention")
                        }
                    },
                    Fxb = class {
                        static A(a) {
                            P(a, {
                                text: G5,
                                url: G5
                            })
                        }
                        get text() {
                            return this.Jd.text
                        }
                        get url() {
                            return this.Jd.url
                        }
                        constructor(a) {
                            this.Jd = a;
                            this.type = (Fxb.A(this), "embed")
                        }
                    },
                    Gxb = class {
                        static A(a) {
                            P(a, {
                                text: G5,
                                language: G5,
                                style: G5,
                                date: G5
                            })
                        }
                        get text() {
                            return this.Jd.text
                        }
                        get language() {
                            return this.Jd.language
                        }
                        get style() {
                            return this.Jd.style
                        }
                        get date() {
                            return this.Jd.date
                        }
                        constructor(a) {
                            this.Jd =
                                a;
                            this.type = (Gxb.A(this), "date")
                        }
                    },
                    Hxb = class {
                        static A(a) {
                            P(a, {
                                text: G5,
                                options: G5,
                                Ld: G5,
                                lK: G5
                            })
                        }
                        get text() {
                            return this.Jd.text
                        }
                        get options() {
                            return this.Jd.options.map(a => a)
                        }
                        get Ld() {
                            return this.Jd.Ld
                        }
                        get lK() {
                            var a;
                            return (a = this.Jd.options.first(b => b.id === this.Jd.Ld)) === null || a === void 0 ? void 0 : a.fill.color
                        }
                        constructor(a) {
                            this.Jd = a;
                            this.type = (Hxb.A(this), "select")
                        }
                    },
                    Ixb = Rwb(a => {
                        switch (a.type) {
                            case "mention":
                                return new Exb(a);
                            case "embed":
                                return new Fxb(a);
                            case "date":
                                return new Gxb(a);
                            case "select":
                                return new Hxb(a);
                            default:
                                throw new E(a);
                        }
                    });
                var Nwb = class {
                        static A(a) {
                            P(a, {
                                style: G5,
                                date: G5,
                                text: G5
                            })
                        }
                        get style() {
                            return 2
                        }
                        get date() {
                            var a;
                            (a = this.Kl.Fi.type === 2 ? this.Kl.Fi.date : void 0) || (a = new Date, a = __c.yA(a), a = {
                                year: a.getFullYear(),
                                month: a.getMonth() + 1,
                                day: a.getDate(),
                                GNa: a.getHours(),
                                tRa: a.getMinutes()
                            });
                            return a
                        }
                        get text() {
                            return this.Kl.Sv
                        }
                        constructor(a, b) {
                            this.Kl = a;
                            this.language = b;
                            this.type = (Nwb.A(this), "date")
                        }
                    },
                    Jxb = class {
                        get label() {
                            return this.option.label
                        }
                        get fill() {
                            return this.option.fill
                        }
                        constructor(a, b) {
                            this.option = a;
                            this.id =
                                b
                        }
                    },
                    Owb = class {
                        static A(a) {
                            P(a, {
                                options: G5,
                                Ld: G5,
                                lK: G5,
                                text: G5,
                                sqa: G5({
                                    equals: wxb.shallow
                                })
                            })
                        }
                        get options() {
                            return this.sqa.map((a, b) => new Jxb(a, b))
                        }
                        get Ld() {
                            var a;
                            return (a = this.options.find(b => b.label === this.text)) === null || a === void 0 ? void 0 : a.id
                        }
                        get lK() {
                            var a;
                            return (a = this.options.find(b => b.id === this.Ld)) === null || a === void 0 ? void 0 : a.fill.color
                        }
                        get text() {
                            return this.Kl.Sv
                        }
                        get sqa() {
                            var a, b;
                            __c.A(((a = this.Kl.Dn) === null || a === void 0 ? void 0 : a.type) === "select");
                            return (b = this.Kl.Dn) === null || b === void 0 ?
                                void 0 : b.options
                        }
                        constructor(a) {
                            this.Kl = a;
                            this.type = (Owb.A(this), "select")
                        }
                    },
                    Pwb = class {
                        static A(a) {
                            P(a, {
                                dG: G5
                            })
                        }
                        get text() {
                            return this.dG ? this.dG.text : ""
                        }
                        get user() {
                            return this.dG ? this.dG.user : ""
                        }
                        get brand() {
                            return this.dG ? this.dG.brand : ""
                        }
                        get dG() {
                            if (this.Kl.Fi.type !== 9) return __c.A(this.Kl.Fi.type === 7), this.Kl.Fi ? this.Kl.Fi.value[0] : void 0
                        }
                        constructor(a) {
                            this.Kl = a;
                            this.type = (Pwb.A(this), "mention")
                        }
                    },
                    Qwb = class {
                        static A(a) {
                            P(a, {
                                mQ: G5
                            })
                        }
                        get text() {
                            return this.mQ ? this.mQ.embed.text : ""
                        }
                        get url() {
                            return this.mQ ?
                                this.mQ.embed.url : ""
                        }
                        get mQ() {
                            if (this.Kl.Fi.type !== 9) return __c.A(this.Kl.Fi.type === 8), this.Kl.Fi ? this.Kl.Fi.value[0] : void 0
                        }
                        constructor(a) {
                            this.Kl = a;
                            this.type = (Qwb.A(this), "embed")
                        }
                    };
                var Kxb = class {
                    u9(a) {
                        this.y6.u9(a)
                    }
                    TT(a, b) {
                        this.y6.TT(a, b)
                    }
                    CQ(a) {
                        return this.y6.CQ(a)
                    }
                    s9(a) {
                        this.Voa.s9(a)
                    }
                    constructor(a, b, c, d) {
                        this.y6 = a;
                        this.Voa = b;
                        this.ib = c;
                        this.TF = d;
                        this.cia = new __c.w9a;
                        this.pMa = e => __c.kwa(this.cia, e)
                    }
                };
                var Lxb = {
                    xxsmall: 2,
                    xsmall: 3,
                    small: 4,
                    medium: 5,
                    large: 6,
                    xlarge: 8,
                    xxlarge: 10,
                    xxxlarge: 20
                };
                var Wwb = ["rgb(0, 126, 182)", "rgb(248, 72, 86)", "rgb(251, 190, 40)", "rgb(68, 133, 25)", "rgb(125, 42, 232)"].map(a => {
                        try {
                            return __c.eD(__c.jD(a))
                        } catch (b) {
                            return "#8e8e8e"
                        }
                    }),
                    Ywb = a => a.endsWith("rem") ? parseFloat(a) * 10 : __c.Ek * Lxb[a];
                var Mxb = R5(a => {
                    const {
                        name: b,
                        borderColor: c,
                        backgroundColor: d,
                        Bla: e,
                        role: f,
                        ariaLabel: g,
                        className: h,
                        style: k,
                        shape: l = "circle",
                        ...m
                    } = a;
                    if (d) {
                        a = __c.oD(d);
                        var n = a instanceof __c.pD ? __c.rD(a) : __c.eD(a)
                    } else n = e ? Xwb(e) : "#8e8e8e";
                    var p = zxb();
                    switch (l) {
                        case "circle":
                            a = I5("defs", {
                                children: I5("clipPath", {
                                    id: p,
                                    children: I5("circle", {
                                        id: `${p}-path`,
                                        cx: "50%",
                                        cy: "50%",
                                        r: "50%"
                                    })
                                })
                            });
                            break;
                        case "square":
                            a = I5("defs", {
                                children: I5("clipPath", {
                                    id: p,
                                    children: I5("rect", {
                                        id: `${p}-path`,
                                        width: "100%",
                                        height: "100%"
                                    })
                                })
                            });
                            break;
                        default:
                            throw new E(l);
                    }
                    switch (l) {
                        case "circle":
                            p = I5("circle", {
                                cx: "50%",
                                cy: "50%",
                                fill: n,
                                shapeRendering: "geometricPrecision",
                                clipPath: `url(#${p})`,
                                stroke: c,
                                className: J5("yCT70Q", {
                                    _2LVP_g: c
                                })
                            });
                            break;
                        case "square":
                            p = I5("rect", {
                                width: "100%",
                                height: "100%",
                                fill: n,
                                shapeRendering: "geometricPrecision",
                                clipPath: `url(#${p})`,
                                stroke: c,
                                className: J5("cUFFRA", {
                                    _2LVP_g: c
                                })
                            });
                            break;
                        default:
                            throw new E(l);
                    }
                    n = Twb(n);
                    return I5("span", {
                        role: f,
                        "aria-label": g,
                        className: J5("VaW8_A", {
                            cUFFRA: l === "square"
                        }),
                        style: {
                            "--pDK9Gw": n
                        },
                        ...m,
                        children: S5("svg", {
                            className: h,
                            style: k,
                            children: [a, p, I5("text", {
                                x: "50%",
                                y: "50%",
                                "aria-hidden": "true",
                                textAnchor: "middle",
                                fill: n,
                                fontWeight: "500",
                                fontSize: "50%",
                                dominantBaseline: "central",
                                letterSpacing: "0.01rem",
                                dy: "-0.04em",
                                children: Uwb(b).toUpperCase()
                            })]
                        })
                    })
                });
                var Nxb = __webpack_require__.p + "images/5c0e58707f218438bf0f73d47db2ce50.svg";
                var Oxb = ({
                    borderColor: a,
                    Zwa: b,
                    ariaLabel: c,
                    className: d,
                    style: e,
                    role: f,
                    ...g
                }) => I5("span", {
                    className: J5(d, {
                        JwH6AA: a,
                        QJpRHw: !a
                    }),
                    style: {
                        backgroundImage: `url(${b})`,
                        borderColor: a && `${a}`,
                        ...e
                    },
                    role: f,
                    "aria-label": f === "img" ? c : void 0,
                    ...g
                });
                var Pxb = ({
                    name: a,
                    y0a: b,
                    ariaLabel: c,
                    Bla: d,
                    backgroundColor: e,
                    borderColor: f,
                    Gq: g,
                    className: h,
                    style: k,
                    shape: l = "circle",
                    ...m
                }) => {
                    h = J5("n8XGZg", "f4qJng fs-hide", h, {
                        P3N3Pw: l === "square"
                    });
                    b = b || "presentation";
                    return g ? I5(Oxb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        Zwa: g,
                        ariaLabel: c,
                        role: b,
                        ...m
                    }) : a ? I5(Mxb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        name: a,
                        shape: l,
                        Bla: d,
                        backgroundColor: e,
                        role: b,
                        ariaLabel: c,
                        ...m
                    }) : I5(Oxb, {
                        className: h,
                        style: k,
                        borderColor: f,
                        Zwa: Nxb,
                        ariaLabel: c,
                        role: b,
                        ...m
                    })
                };
                var Qxb = '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none"><path fill="currentColor" fill-rule="evenodd" d="M8.116 12.366a1.25 1.25 0 0 1 1.768 0l5.586 5.586a.75.75 0 0 0 1.06 0l5.586-5.586a1.25 1.25 0 0 1 1.768 1.768l-5.586 5.586a3.25 3.25 0 0 1-4.596 0l-5.586-5.586a1.25 1.25 0 0 1 0-1.768" clip-rule="evenodd"/></svg>';
                var Rxb = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path fill="currentColor" d="M10.964 5.972 8.177 8.759a.25.25 0 0 1-.354 0L5.036 5.972a.75.75 0 1 0-1.06 1.06L6.762 9.82a1.75 1.75 0 0 0 2.475 0l2.787-2.788a.75.75 0 1 0-1.06-1.06"/></svg>';
                var Sxb = '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none"><path stroke="currentColor" stroke-linecap="round" stroke-width="1.25" d="M3.17 5 5.3 7.12a1 1 0 0 0 1.42 0L8.83 5"/></svg>';
                var Txb = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path fill="currentColor" d="m16.384 9.225-4.207 4.207a.25.25 0 0 1-.353 0L7.623 9.224a.75.75 0 0 0-1.059.002.75.75 0 0 0-.002 1.059l4.201 4.21c.681.68 1.787.678 2.47-.005l4.207-4.207a.75.75 0 0 0 .002-1.059.75.75 0 0 0-1.058.002"/></svg>';
                var Uxb = __c.RS({
                    Xq: Sxb,
                    small: Rxb,
                    medium: Txb,
                    XC: Qxb
                });
                var exb = yxb(void 0);
                var Vxb = Number.parseInt("300ms", 10),
                    Wxb = {
                        enter: "_QukmA",
                        enterActive: "_5_06KQ",
                        enterDone: void 0,
                        exitActive: "a952jg",
                        exitDone: "orZOEA"
                    },
                    Xxb = R5(function({
                        JF: a = !1,
                        children: b,
                        keyFrame: c,
                        wAa: d,
                        ona: e = "hidden",
                        Soa: f = "hidden",
                        ariaLive: g,
                        Ksa: h,
                        j6a: k = "none"
                    }) {
                        a = __c.nb().Wc && !a;
                        return ixb({
                            children: b,
                            keyFrame: c,
                            wAa: d,
                            ariaLive: g,
                            ona: e,
                            Soa: f,
                            Ksa: h,
                            RFa: a ? Vxb : 0,
                            $Ja: J5({
                                _1niDPQ: a,
                                Q6kGbg: k === "none",
                                _9j7ODw: k === "layout"
                            }),
                            nXa: Wxb
                        })
                    });
                var Yxb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.25 3.5a.75.75 0 0 0-1.5 0V5H7a4 4 0 0 0-4 4v8a4 4 0 0 0 4 4h10a4 4 0 0 0 4-4V9a4 4 0 0 0-4-4h-.75V3.5a.75.75 0 0 0-1.5 0V5h-5.5V3.5Zm5.5 4v-1h-5.5v1a.75.75 0 0 1-1.5 0v-1H7A2.5 2.5 0 0 0 4.5 9v1h15V9A2.5 2.5 0 0 0 17 6.5h-.75v1a.75.75 0 0 1-1.5 0Zm4.75 4h-15V17A2.5 2.5 0 0 0 7 19.5h10a2.5 2.5 0 0 0 2.5-2.5v-5.5Z" fill="currentColor"/></svg>';
                var Zxb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-1.288-.244-2.52-.687-3.65v-.1h-.04A10.003 10.003 0 0 0 12 2C6.477 2 2 6.477 2 12Zm12.653-8.078A8.526 8.526 0 0 1 19.63 8.25h-3.457c-.317-1.74-.848-3.236-1.52-4.328ZM20.2 9.75h-3.813c.075.723.114 1.476.114 2.25s-.04 1.527-.114 2.25h3.813A8.51 8.51 0 0 0 20.5 12a8.51 8.51 0 0 0-.301-2.25Zm-.569 6h-3.457c-.317 1.74-.848 3.236-1.52 4.328a8.526 8.526 0 0 0 4.977-4.328Zm-4.755-1.5a20.109 20.109 0 0 0 0-4.5h-5.75a20.116 20.116 0 0 0 0 4.5h5.75Zm-5.519 1.5h5.288C14.08 18.593 12.953 20.5 12 20.5c-.953 0-2.081-1.907-2.644-4.75Zm-1.529 0c.317 1.74.848 3.236 1.52 4.328A8.526 8.526 0 0 1 4.37 15.75h3.457Zm-.213-1.5H3.801A8.51 8.51 0 0 1 3.5 12c0-.779.105-1.533.301-2.25h3.813A21.9 21.9 0 0 0 7.5 12c0 .774.04 1.527.114 2.25ZM12 3.5c.953 0 2.081 1.907 2.644 4.75H9.356C9.92 5.407 11.047 3.5 12 3.5ZM4.37 8.25h3.457c.317-1.74.848-3.236 1.52-4.328A8.525 8.525 0 0 0 4.37 8.25Z" fill="currentColor"/></svg>';
                var $xb = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M8.64 16.5a4.87 4.87 0 0 0 4.11 2.25h4.5a4.88 4.88 0 0 0 0-9.75h-4.5a4.88 4.88 0 0 0-4.5 3h1.7c.6-.9 1.63-1.5 2.8-1.5h4.5a3.38 3.38 0 0 1 0 6.75h-4.5c-.8 0-1.54-.28-2.12-.75H8.64zm7.1-9a4.87 4.87 0 0 0-4.12-2.25h-4.5a4.87 4.87 0 1 0 0 9.75h4.5a4.88 4.88 0 0 0 4.5-3h-1.69c-.6.9-1.63 1.5-2.8 1.5h-4.5a3.38 3.38 0 0 1 0-6.75h4.5c.8 0 1.54.28 2.12.75h1.98z"/></svg>';
                var ayb = '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.374 7.572A3.5 3.5 0 1 0 5.6 7.548a5.365 5.365 0 0 0-2.928 3.968 1.5 1.5 0 0 0 .592 1.441 7.9 7.9 0 0 0 4.7 1.543 7.9 7.9 0 0 0 4.698-1.542 1.5 1.5 0 0 0 .592-1.442 5.364 5.364 0 0 0-2.88-3.944ZM10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm-5.847 6.75a3.858 3.858 0 0 1 7.62 0A6.4 6.4 0 0 1 7.963 13a6.4 6.4 0 0 1-3.81-1.25Z" fill="currentColor"/></svg>';
                var byb = R5(a => {
                        const b = a.link,
                            c = a.className,
                            d = a.ariaLabel,
                            e = a.lK,
                            f = a.zJa,
                            g = a.IEa,
                            h = a.XEa,
                            k = a.measureRef,
                            l = a.onPointerDown,
                            m = a.onMouseEnter,
                            n = a.onMouseLeave,
                            p = J5({
                                EdewNw: !!g,
                                _6ZpPrw: !!h,
                                pzXyUA: a.text.length > 0
                            });
                        a = a.text.length > 0 ? a.text : "\ufeff";
                        return S5("span", {
                            className: J5(c, "FedJ0Q"),
                            "aria-label": d || a,
                            children: [I5("span", {
                                className: J5("_2Lr6pQ", p),
                                children: I5("span", {
                                    className: "Z_WvzQ",
                                    children: a
                                })
                            }), S5("span", {
                                className: J5("XemTdQ", p),
                                ref: k,
                                style: e ? {
                                    color: e
                                } : void 0,
                                onPointerDown: l,
                                onMouseEnter: m,
                                onMouseLeave: n,
                                children: [g, I5("span", {
                                    className: J5("U_QH_A", {
                                        C9XL8g: !f
                                    }),
                                    children: b ? I5("a", {
                                        className: "vgTP5Q",
                                        ...b,
                                        children: a
                                    }) : a
                                }), h]
                            })]
                        })
                    }),
                    mxb = R5(a => {
                        const b = a.backgroundColor,
                            c = a.Gq;
                        a = a.text;
                        const d = {
                            width: "0.9em",
                            height: "0.9em"
                        };
                        return I5(Xxb, {
                            keyFrame: c ? "show" : "hide",
                            children: a ? I5(Pxb, {
                                name: a,
                                style: d,
                                backgroundColor: b,
                                Gq: c,
                                borderColor: c ? void 0 : b
                            }) : I5("span", {
                                "aria-hidden": "true",
                                className: "_tFJqA",
                                dangerouslySetInnerHTML: {
                                    __html: ayb
                                }
                            })
                        })
                    }),
                    nxb = R5(a => {
                        const b = a.icon;
                        a = a.jPa;
                        return I5(Xxb, {
                            keyFrame: b ?
                                "favicon" : "placeholder",
                            children: b ? I5("span", {
                                className: "_tFJqA",
                                children: I5("img", {
                                    src: b,
                                    className: "qpbYdw"
                                })
                            }) : I5("span", {
                                "aria-hidden": "true",
                                className: "_tFJqA",
                                dangerouslySetInnerHTML: {
                                    __html: a ? $xb : Zxb
                                }
                            })
                        })
                    }),
                    oxb = R5(() => I5("span", {
                        "aria-hidden": "true",
                        className: "_tFJqA",
                        dangerouslySetInnerHTML: {
                            __html: Yxb
                        }
                    })),
                    qxb = R5(({
                        selected: a
                    }) => I5("div", {
                        className: J5("whph4A", {
                            zgzjww: a
                        }),
                        children: I5(Uxb, {
                            size: "medium",
                            style: {
                                width: "0.9em",
                                height: "0.9em"
                            },
                            className: "_tFJqA"
                        })
                    })),
                    cyb = U5(a => {
                        const {
                            Jd: b,
                            yya: c,
                            Lca: d,
                            mode: e = "viewable",
                            measureRef: f,
                            xm: g,
                            onPointerDown: h
                        } = a;
                        a = b.text || "\u00a0".repeat(16);
                        const k = b.type === "embed" ? d.ib(b.url) : void 0,
                            [l, m] = jxb(!1),
                            n = K5(t => m(L5(t)), [m]),
                            p = K5(t => m(!L5(t)), [m]),
                            q = K5(t => {
                                m(L5(t.nativeEvent));
                                document.addEventListener("keydown", n);
                                document.addEventListener("keyup", p)
                            }, [m, n, p]),
                            r = K5(() => {
                                m(!1);
                                document.removeEventListener("keydown", n);
                                document.removeEventListener("keyup", p)
                            }, [m, n, p]);
                        kxb(() => {
                            N5(() => {
                                switch (b.type) {
                                    case "mention":
                                        b.user && d.u9(b.user);
                                        break;
                                    case "embed":
                                        d.s9(b.url)
                                }
                            })
                        }, [b, d]);
                        Axb(() => {
                            g === null || g === void 0 || g()
                        }, [b.type, a, g]);
                        return I5(byb, {
                            text: a,
                            link: e === "viewable" || l ? k : void 0,
                            zJa: b.text.length === 0,
                            ariaLabel: b.text || "",
                            className: lxb(b),
                            lK: b.lK,
                            IEa: pxb(b, d),
                            XEa: rxb(b, {
                                yya: c
                            }),
                            measureRef: f,
                            onPointerDown: h,
                            onMouseEnter: b.type === "embed" && e === "editable" ? q : void 0,
                            onMouseLeave: b.type === "embed" && e === "editable" ? r : void 0
                        })
                    });
                var dyb = __c.M(() => ({
                    K6a: __c.NO(11),
                    mode: __c.H("A?", 1, "BY_USER_IDS"),
                    hYa: __c.MO(1)
                }));
                var eyb = class {
                        static A(a) {
                            P(a, {
                                VI: xxb.shallow,
                                Ipa: M5
                            })
                        }
                        CQ(a) {
                            return this.xla.CQ(a)
                        }
                        u9(a) {
                            this.bia.has(a) || this.VI.has(a) || (this.VI.add(a), this.gJa())
                        }
                        TT(a, b) {
                            this.bia.has(a) || (this.bia.set(a, b), this.VI.delete(a), txb(this.xla, a, b))
                        }
                        async Ipa() {
                            if (this.VI.size !== 0) {
                                var a = [...this.VI.values()];
                                this.VI.clear();
                                if (this.zla) {
                                    var b = await this.zla;
                                    await Promise.all(sxb(a).map(async c => {
                                        const d = new dyb({
                                                hYa: c
                                            }),
                                            {
                                                Q0a: e
                                            } = await b.r5a(d);
                                        N5(() => c.forEach(f => this.TT(f, e.get(f))))
                                    }))
                                } else a.forEach(c => this.TT(c))
                            }
                        }
                        constructor(a,
                            b) {
                            this.zla = a;
                            this.bia = (eyb.A(this), new P5);
                            this.VI = new Set;
                            this.xla = new fyb;
                            this.gJa = __c.Ec(() => this.Ipa(), 200);
                            N5(() => {
                                b === null || b === void 0 || b.forEach((c, d) => this.TT(d, c))
                            })
                        }
                    },
                    fyb = class {
                        CQ(a) {
                            return this.ZU.get(a)
                        }
                        constructor() {
                            this.ZU = new P5
                        }
                    };
                var uxb = __c.M(() => ({
                    id: __c.X("id", 1),
                    extension: __c.Z("extension", 3),
                    rya: __c.IO("revision", 5),
                    version: __c.IO("version", 2),
                    q6a: __c.IO("imagesetsLimit", 6)
                }));
                var gyb = class {
                    static A(a) {
                        P(a, {
                            hLa: M5
                        })
                    }
                    async hLa(a) {
                        if (this.yh) {
                            var b = (new URL(a)).pathname; {
                                const c = /design\/(D[a-zA-Z0-9_-]{10})\/?([a-zA-Z0-9_-]+)?/g.exec(b);
                                c == null || c.length < 2 ? b = void 0 : (b = c[2], (new Set(["edit", "remix", "view", "watch"])).has(c[2]) && (b = void 0), b = {
                                    id: c[1],
                                    extension: b
                                })
                            }
                            if (b) return await vxb(this, {
                                url: a,
                                ...b
                            })
                        }
                    }
                    constructor(a) {
                        this.yh = a;
                        this.pBa = (gyb.A(this), new P5);
                        this.promises = new Map
                    }
                };
                var hyb = class {
                    static A(a) {
                        P(a, {
                            YP: xxb.shallow
                        })
                    }
                    async s9(a) {
                        const b = new Image;
                        let c;
                        try {
                            var d;
                            const e = await ((d = this.TF) === null || d === void 0 ? void 0 : d.bW(a));
                            c = e === null || e === void 0 ? void 0 : e.gLa
                        } catch (e) {}
                        c ? (b.src = c, b.onload = M5(() => this.YP.set(a, c)), b.onerror = M5(() => this.YP.set(a, void 0))) : N5(() => this.YP.set(a, void 0))
                    }
                    constructor(a) {
                        this.TF = a;
                        this.YP = (hyb.A(this), new Map)
                    }
                };
                __c.Esa = {
                    zOa: function(a) {
                        const b = a.document,
                            c = a.yh,
                            d = a.ib,
                            e = a.TF;
                        var f = a.yla;
                        const g = a.Oe,
                            h = a.QA,
                            k = a.i4;
                        a = a.E6a;
                        f = new eyb(a === null || a === void 0 ? void 0 : a(), f);
                        a = new hyb(e);
                        new gyb(c);
                        const l = new Kxb(f, a, d, e),
                            m = Swb(k, b);
                        g.hn.t5 = U5(({
                            item: p,
                            measureRef: q
                        }) => {
                            const r = H5(() => Ixb(p.Jd), [p.Jd]);
                            return I5(cyb, {
                                Jd: r,
                                Lca: l,
                                measureRef: q
                            })
                        });
                        const n = U5(({
                            context: p,
                            xm: q
                        }) => {
                            const r = H5(() => __c.B(m(p.container)), [p]);
                            Axb(q, [q, p.container.column.width]);
                            return I5(cyb, {
                                Jd: r,
                                Lca: l,
                                xm: q
                            })
                        });
                        h.cka = ({
                                context: p,
                                xm: q
                            }) =>
                            ({
                                type: "react",
                                node: I5(n, {
                                    context: p,
                                    xm: q
                                })
                            });
                        return {
                            Lca: l
                        }
                    }
                };
            }).call(self, self._c68b74ff4d61aaeea4f241f0854f5b1a);
        }

    }
])
//# sourceMappingURL=sourcemaps/e1eaeef01833c457.js.map