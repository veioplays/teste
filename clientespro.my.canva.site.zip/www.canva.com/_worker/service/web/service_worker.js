self['__canva_public_path__'] = 'https:\/\/static.canva.com\/web/';
self['bootstrap'] = JSON.parse('{"page":{"A?":"B","A":{"A?":"C","b":"https://dfe5e84dbc214418801081ab37e58da5@o13855.ingest.sentry.io/5546683","c":0.2,"f":false,"g":"A","i":[],"j":{"A":true},"k":{"A":false,"B":100,"C":30,"D":10},"l":[],"m":0.1},"H":"A","K":"O","L":"O","G":"A","n":"N","o":"N","l":true,"m":false,"R":30000,"T":true,"e":false,"U":false,"V":"20250506-22-b23e52a","Z":{"A?":"A","E":false,"F":5000,"G":20,"H":2,"I":false,"J":0.0,"K":0.01,"M":"web","P":false,"S":false,"T":false,"U":false,"V":false,"W":[],"a":"service_worker","b":"https://telemetry.canva.com/v1/traces","c":"20250506-22-b23e52a","e":"prod","i":"web"},"j":1.0E-4,"k":30000,"d":false,"i":{"A":"Chrome","B":135},"a":"https://static.canva.com/web"}}');
importScripts("https:\/\/static.canva.com\/static\/lib\/sentry\/7.16.0.min.js");
Sentry.init({
    "dsn": "https:\u002F\u002Fdfe5e84dbc214418801081ab37e58da5@o13855.ingest.sentry.io\u002F5546683",
    "release": "20250506-22-b23e52a",
    "environment": "prod"
});
Sentry.setTag("initLocation", "html");
importScripts('https://static.canva.com/web/b7613728fdc32653.runtime.js', 'https://static.canva.com/web/411de7fe679f1413.5a9ync.vendor.js', 'https://static.canva.com/web/hjfept.68a94a08990c44d5.js', 'https://static.canva.com/web/3dfe69d4f9182d9c.js');